#!/usr/bin/env python3
"""Quét thư mục assets/music/ và ghi lại assets/music/playlist.js.
Bài chính Multifandom_Dancin.mp3 luôn là nhạc nền mặc định; các file khác xuất hiện trong Cài đặt để chọn."""
import json, os
ROOT = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(ROOT, 'assets', 'music')
os.makedirs(D, exist_ok=True)
exts = {'.mp3', '.ogg', '.wav', '.m4a', '.aac', '.flac'}
files = sorted(n for n in os.listdir(D) if os.path.splitext(n)[1].lower() in exts)
main = 'Multifandom_Dancin.mp3'
files.sort(key=lambda n: (n != main, n.lower()))      # bài chính luôn đứng đầu
with open(os.path.join(D, 'playlist.js'), 'w', encoding='utf-8') as f:
    f.write("// Tạo tự động bởi update_lists\nwindow.USER_PLAYLIST = [\n" + ",\n".join("  " + json.dumps('assets/music/' + n, ensure_ascii=False) for n in files) + "\n];\n")
print(f"Đã cập nhật danh sách: {len(files)} bài nhạc.")
