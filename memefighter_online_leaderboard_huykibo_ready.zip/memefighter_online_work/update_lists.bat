@echo off
chcp 65001 >nul
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel%==0 ( python update_lists.py & goto done )
where py >nul 2>nul
if %errorlevel%==0 ( py update_lists.py & goto done )
echo Khong tim thay Python, dung PowerShell...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$f=@(Get-ChildItem 'assets/music' -File | Where-Object { $_.Extension -match '^\.(mp3|ogg|wav|m4a|aac|flac)$' } | Sort-Object { $_.Name -ne 'Multifandom_Dancin.mp3' }, Name | ForEach-Object { '  \"assets/music/' + $_.Name + '\"' }); Set-Content -Encoding UTF8 'assets/music/playlist.js' ('window.USER_PLAYLIST = [' + [Environment]::NewLine + ($f -join (',' + [Environment]::NewLine)) + [Environment]::NewLine + '];')"
:done
echo.
echo Da cap nhat danh sach nhac. Mo lai game (nhan F5) de thay doi.
pause
