/* MEMEFIGHTER online guest profiles + Supabase leaderboard. */
(() => {
    'use strict';
    const PROFILE_KEY = 'memefighter_guest_profile_v1';
    const CONFIG = window.MEMEFIGHTER_SUPABASE_CONFIG || {};
    const state = { client: null, profile: null, run: null, submitted: false, readyCallback: null, overlay: null };
    const $ = (tag, attrs = {}, text = '') => {
        const el = document.createElement(tag);
        Object.entries(attrs).forEach(([key, value]) => {
            if (key === 'class') el.className = value;
            else if (key === 'html') el.innerHTML = value;
            else if (key.startsWith('on') && typeof value === 'function') el.addEventListener(key.slice(2).toLowerCase(), value);
            else el.setAttribute(key, value);
        });
        if (text) el.textContent = text;
        return el;
    };
    const configured = () => !!(window.supabase && CONFIG.url && CONFIG.anonKey && !String(CONFIG.url).includes('YOUR_') && !String(CONFIG.anonKey).includes('YOUR_'));
    const getClient = () => {
        if (!configured()) return null;
        if (!state.client) state.client = window.supabase.createClient(CONFIG.url, CONFIG.anonKey, {
            auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }
        });
        return state.client;
    };
    const loadProfile = () => {
        try {
            const saved = JSON.parse(localStorage.getItem(PROFILE_KEY) || 'null');
            if (saved && saved.id && saved.nickname) state.profile = saved;
        } catch (_) { /* ignore invalid local profile */ }
        return state.profile;
    };
    const cleanNickname = value => String(value || '').trim().replace(/\s+/g, ' ').slice(0, 16);
    const ensureOverlay = () => {
        if (state.overlay) return state.overlay;
        const root = document.getElementById('online-ui');
        if (!root) return null;
        state.overlay = root;
        return root;
    };
    const showModal = (title, body) => {
        const root = ensureOverlay(); if (!root) return;
        root.innerHTML = '';
        const panel = $('section', { class: 'mf-panel', role: 'dialog', 'aria-modal': 'true', 'aria-label': title });
        panel.append($('div', { class: 'mf-eyebrow' }, 'MEMEFIGHTER // HUYKIBO'));
        panel.append($('h2', {}, title));
        panel.append(body);
        root.append(panel); root.classList.add('is-open');
    };
    const closeModal = () => {
        const root = ensureOverlay(); if (root) { root.classList.remove('is-open'); root.innerHTML = ''; }
    };
    const openNickname = () => {
        const form = $('form', { class: 'mf-form' });
        form.append($('p', { class: 'mf-copy' }, 'Nhập nickname để lưu thành tích và xuất hiện trên bảng xếp hạng toàn cầu. Không cần email hoặc mật khẩu.'));
        const input = $('input', { class: 'mf-input', name: 'nickname', maxlength: '16', minlength: '2', autocomplete: 'nickname', placeholder: 'Ví dụ: HUYKIBO', required: 'required' });
        input.value = state.profile ? state.profile.nickname : '';
        form.append(input);
        form.append($('div', { class: 'mf-hint' }, '2–16 ký tự · chữ, số, dấu cách hoặc _'));
        const error = $('div', { class: 'mf-error', 'aria-live': 'polite' }); form.append(error);
        const actions = $('div', { class: 'mf-actions' });
        actions.append($('button', { class: 'mf-primary', type: 'submit' }, 'LƯU NICKNAME & TIẾP TỤC'));
        if (state.profile) actions.append($('button', { class: 'mf-secondary', type: 'button', onclick: closeModal }, 'HỦY'));
        form.append(actions);
        form.addEventListener('submit', event => {
            event.preventDefault();
            const nickname = cleanNickname(input.value);
            if (nickname.length < 2 || !/^[\p{L}\p{N}_ -]{2,16}$/u.test(nickname)) {
                error.textContent = 'Nickname không hợp lệ. Hãy dùng 2–16 ký tự chữ, số, khoảng trắng hoặc _. '; return;
            }
            const old = state.profile;
            state.profile = { id: old?.id || (window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); })), nickname };
            try { localStorage.setItem(PROFILE_KEY, JSON.stringify(state.profile)); } catch (_) { /* private browsing may block storage */ }
            closeModal();
            const callback = state.readyCallback; state.readyCallback = null;
            if (typeof callback === 'function') callback();
        });
        showModal(state.profile ? 'ĐỔI NICKNAME' : 'PLAYER NAME', form);
        setTimeout(() => input.focus(), 30);
    };
    const requirePlayer = callback => {
        loadProfile();
        if (state.profile) return true;
        state.readyCallback = callback || null; openNickname(); return false;
    };
    const modeLabel = mode => ({ easy: 'EASY', normal: 'NORMAL', hard: 'HARD' }[mode] || String(mode || 'NORMAL').toUpperCase());
    const showLeaderboard = async (selected = 'ALL') => {
        const body = $('div', { class: 'mf-leaderboard' });
        const toolbar = $('div', { class: 'mf-toolbar' });
        const filters = $('div', { class: 'mf-filters' });
        ['ALL', 'EASY', 'NORMAL', 'HARD'].forEach(mode => {
            filters.append($('button', { class: 'mf-filter' + (selected === mode ? ' active' : ''), type: 'button', onclick: () => showLeaderboard(mode) }, mode));
        });
        toolbar.append(filters);
        const close = $('button', { class: 'mf-close', type: 'button', onclick: closeModal, 'aria-label': 'Close' }, '✕'); toolbar.append(close);
        body.append(toolbar);
        if (state.profile) {
            const playerBar = $('div', { class: 'mf-playerbar' });
            playerBar.append($('span', {}, 'PLAYER: ' + state.profile.nickname));
            playerBar.append($('button', { class: 'mf-linkbtn', type: 'button', onclick: openNickname }, 'ĐỔI TÊN'));
            body.append(playerBar);
        }
        const content = $('div', { class: 'mf-table-wrap' });
        content.append($('div', { class: 'mf-loading' }, 'ĐANG TẢI BẢNG XẾP HẠNG...'));
        body.append(content);
        showModal('GLOBAL LEADERBOARD', body);
        const client = getClient();
        if (!client) {
            content.innerHTML = '<div class="mf-empty"><strong>CHƯA KẾT NỐI SUPABASE</strong><p>Điền Project URL và anon public key trong supabase-config.js, sau đó chạy SQL trong file supabase-schema.sql.</p></div>';
            return;
        }
        try {
            let query = client.from('leaderboard_runs').select('nickname, difficulty, game_mode, score, floor_reached, created_at').order('score', { ascending: false }).order('floor_reached', { ascending: false }).order('created_at', { ascending: true }).limit(100);
            if (selected !== 'ALL') query = query.eq('difficulty', selected.toLowerCase());
            const { data, error } = await query;
            if (error) throw error;
            content.innerHTML = '';
            if (!data || !data.length) { content.append($('div', { class: 'mf-empty' }, 'CHƯA CÓ THÀNH TÍCH. HÃY LÀ NGƯỜI ĐẦU TIÊN!')); return; }
            const table = $('table', { class: 'mf-table' });
            const thead = $('thead'); const trh = $('tr');
            ['#', 'PLAYER', 'DIFFICULTY', 'PLAY MODE', 'SCORE', 'FLOOR'].forEach(label => trh.append($('th', {}, label)));
            thead.append(trh); table.append(thead);
            const tbody = $('tbody');
            data.forEach((row, index) => {
                const tr = $('tr');
                if (index < 3) tr.className = 'rank-' + (index + 1);
                [String(index + 1).padStart(2, '0'), row.nickname, modeLabel(row.difficulty), String(row.game_mode || 'story').toUpperCase(), Number(row.score || 0).toLocaleString('en-US'), String(row.floor_reached || 1)].forEach((value, i) => tr.append($('td', { class: i === 3 ? 'score-cell' : '' }, value)));
                tbody.append(tr);
            });
            table.append(tbody); content.append(table);
            content.append($('div', { class: 'mf-footnote' }, 'TOP 100 · Sắp xếp theo điểm, sau đó tầng cao nhất.'));
        } catch (error) {
            content.innerHTML = '';
            content.append($('div', { class: 'mf-empty mf-errorbox' }, 'Không tải được bảng xếp hạng: ' + (error.message || 'Unknown error') + '. Kiểm tra SQL, URL và anon key trong cấu hình.'));
        }
    };
    const beginRun = (difficulty, gameMode) => {
        loadProfile(); state.run = { startedAt: Date.now(), difficulty: String(difficulty || 'normal').toLowerCase(), gameMode: String(gameMode || 'story').toLowerCase() };
        state.submitted = false;
    };
    const finishRun = async result => {
        if (state.submitted || !state.run || !state.profile) return;
        state.submitted = true;
        const client = getClient();
        if (!client) { console.info('[MemeFighter] Supabase chưa được cấu hình; kết quả chưa được gửi online.'); return; }
        const elapsed = Math.max(1, Math.round((Date.now() - state.run.startedAt) / 1000));
        const payload = {
            player_id: state.profile.id,
            nickname: state.profile.nickname,
            difficulty: state.run.difficulty,
            game_mode: state.run.gameMode,
            score: Math.max(0, Math.min(100000000, Math.floor(Number(result.score) || 0))),
            floor_reached: Math.max(1, Math.min(100, Math.floor(Number(result.floor) || 1))),
            kills: Math.max(0, Math.min(100000, Math.floor(Number(result.kills) || 0))),
            max_combo: Math.max(0, Math.min(100000, Math.floor(Number(result.maxCombo) || 0))),
            play_time_seconds: Math.min(604800, elapsed),
            outcome: result.outcome === 'victory' ? 'victory' : 'gameover'
        };
        try {
            const { error } = await client.from('leaderboard_runs').insert(payload);
            if (error) throw error;
            console.info('[MemeFighter] Online leaderboard result saved.');
        } catch (error) {
            console.error('[MemeFighter] Could not submit leaderboard result:', error.message || error);
            state.submitted = false; // permit one retry if finishRun is called again
        }
    };
    window.MemeLeaderboard = {
        requirePlayer, openNickname, showLeaderboard, closeModal, beginRun, finishRun,
        getPlayer: () => state.profile || loadProfile(), isConfigured: configured
    };
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && state.overlay?.classList.contains('is-open')) closeModal(); });
})();
