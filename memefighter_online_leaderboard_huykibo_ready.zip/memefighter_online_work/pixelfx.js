/* ============================================================
   PIXELFX — bộ hiệu ứng PIXEL-ART cho Trollface / Ultimate Meme Lord + CỔNG DỊCH CHUYỂN (portal)
   Không dùng ảnh ngoài: mọi sprite được dựng bằng code rồi phóng to "nearest-neighbour" nên luôn sắc nét kiểu pixel.
   Xuất ra window.PXFX:
     PXFX.fx          — hệ thống FX dùng chung (vòng tròn ma thuật, cột sáng, hạt vuông, chữ pixel, vệt chém ...)
     PXFX.spr         — sprite: banana, trollface, ...
     PXFX.drawOrb / drawBeam / drawSpikeWave / drawMeteor — vẽ đạn của boss
     PXFX.Portal      — cổng dịch chuyển hoành tráng sau khi qua màn
   ============================================================ */
(function () {
'use strict';
const TAU = Math.PI * 2;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const rand = (a, b) => a + Math.random() * (b - a);
const lerp = (a, b, t) => a + (b - a) * t;
const FONT = '"Press Start 2P", "Courier New", monospace';
const CELL = 3;                                   // kích thước "điểm ảnh" của hiệu ứng trên màn hình
const snap = (v, s = CELL) => Math.round(v / s) * s;

function mk(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function hex(c) { const n = parseInt(c.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
function mix(a, b, t) { const A = hex(a), B = hex(b); return '#' + A.map((v, i) => Math.round(lerp(v, B[i], t)).toString(16).padStart(2, '0')).join(''); }
function hash2(x, y) { let h = (x * 374761393 + y * 668265263) | 0; h = (h ^ (h >> 13)) * 1274126177 | 0; return ((h ^ (h >> 16)) >>> 0) / 4294967295; }

// vẽ sprite (canvas nhỏ) phóng s lần, tâm tại (x,y)
function blit(ctx, cv, x, y, s, o = {}) {
    ctx.save(); ctx.imageSmoothingEnabled = false; ctx.translate(Math.round(x), Math.round(y));
    if (o.rot) ctx.rotate(o.rot); if (o.flip) ctx.scale(-1, 1);
    if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
    ctx.drawImage(cv, Math.round(-cv.width * s / 2), Math.round(-cv.height * s / 2), cv.width * s, cv.height * s); ctx.restore();
}
function outline(src, color) {
    const w = src.width, h = src.height, out = mk(w + 2, h + 2), o = out.getContext('2d');
    const sd = src.getContext('2d').getImageData(0, 0, w, h).data;
    const has = (x, y) => x >= 0 && y >= 0 && x < w && y < h && sd[(y * w + x) * 4 + 3] > 0;
    o.fillStyle = color;
    for (let y = -1; y <= h; y++) for (let x = -1; x <= w; x++) if (!has(x, y) && (has(x - 1, y) || has(x + 1, y) || has(x, y - 1) || has(x, y + 1))) o.fillRect(x + 1, y + 1, 1, 1);
    o.drawImage(src, 1, 1); return out;
}
function fromRows(rows, pal) {
    const c = mk(rows[0].length, rows.length), g = c.getContext('2d');
    rows.forEach((r, y) => { for (let x = 0; x < r.length; x++) { const col = pal[r[x]]; if (col) { g.fillStyle = col; g.fillRect(x, y, 1, 1); } } });
    return c;
}

// ============================================================
// SPRITES
// ============================================================
const SPR = {};
function buildSprites() {
    // ---- vỏ chuối: hình lưỡi liềm tạo bằng 2 đường tròn, tô 4 tông màu + cuống nâu ----
    {
        const S = 24, c = mk(S, S), g = c.getContext('2d');
        const A = { x: 12, y: 13, r: 10.5 }, B = { x: 15.5, y: 8.5, r: 9 }, pts = [];
        for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
            const da = Math.hypot(x + 0.5 - A.x, y + 0.5 - A.y), db = Math.hypot(x + 0.5 - B.x, y + 0.5 - B.y);
            if (da < A.r && db > B.r) pts.push({ x, y, da, db });
        }
        let t1 = pts[0], t2 = pts[1], best = 0;
        for (const a of pts) for (const b of pts) { const dd = (a.x - b.x) ** 2 + (a.y - b.y) ** 2; if (dd > best) { best = dd; t1 = a; t2 = b; } }
        for (const p of pts) {
            const eo = A.r - p.da, ei = p.db - B.r;
            let col = '#ffd92e';
            if (eo < 0.9) col = '#c98a00'; else if (eo < 1.9) col = '#eba800'; else if (ei < 1.9) col = '#fff28a';
            if (Math.hypot(p.x - t1.x, p.y - t1.y) < 2.3) col = '#7a4f12';
            if (Math.hypot(p.x - t2.x, p.y - t2.y) < 1.5) col = '#3d2a0c';
            g.fillStyle = col; g.fillRect(p.x, p.y, 1, 1);
        }
        SPR.banana = outline(c, '#2a1a05');
    }
    // ---- mặt Trollface pixel 20x18 ----
    SPR.troll = outline(fromRows([
        '.....kkkkkkkkkk.....',
        '...kkWWWWWWWWWWkk...',
        '..kWWWWWWWWWWWWWWk..',
        '.kWWWWWWWWWWWWWWWWk.',
        '.kWWkkWWWWWWWWkkWWk.',
        'kWWWWWkkWWWWkkWWWWWk',
        'kWWWWkkkWWWWkkkWWWWk',
        'kWWWWWkkWWWWkkWWWWWk',
        'kWWWWWWWWWWWWWWWWWWk',
        'kWWkWWWWWWWWWWWWkWWk',
        'kWkkkWWWWWWWWWWkkkWk',
        '.kkWkkkkkkkkkkkkWkk.',
        '.kWWWkWkWkWkWkWkWWk.',
        '..kWWkkkkkkkkkkkWWk.'.slice(0, 20),
        '...kWWkWkWkWkWkWWk..',
        '....kkWWWWWWWWWkk...',
        '......kkkkkkkkkk....',
    ].map(r => r.padEnd(20, '.')), { k: '#14101c', W: '#f4f1ea' }), '#14101c');
    // chữ X mục tiêu / dấu chấm than nhỏ
    SPR.bang = outline(fromRows(['.rr.', 'rrrr', 'rrrr', '.rr.', '.rr.', '....', '.rr.', '.rr.'], { r: '#ff3b3b' }), '#2a0000');
    // ngôi sao 4 cánh nhỏ lấp lánh
    SPR.spark = fromRows(['...w...', '...w...', '..www..', 'wwwwwww', '..www..', '...w...', '...w...'], { w: '#ffffff' });
    // nốt "hạt" kim cương nhỏ
    SPR.gem = outline(fromRows(['..aa..', '.abba.', 'abbbba', '.abba.', '..aa..'], { a: '#ffffff', b: '#c4b5fd' }), '#1e1b4b');
}

// ============================================================
// Mặt đầu pixel hoá (ảnh tải từ game, thu nhỏ rồi phóng lớn không làm mịn)
// ============================================================
const headCache = new Map();
function pixHead(img, n) {
    if (!img || !img.naturalWidth) return null;
    const key = (img.src || '') + '|' + n; let c = headCache.get(key);
    if (c) return c;
    c = mk(n, n); const g = c.getContext('2d'); g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high';
    const ar = img.naturalHeight / img.naturalWidth, w = n, h = n * ar;
    g.drawImage(img, 0, Math.max(0, (n - h) / 2 - n * 0.04), w, h);
    headCache.set(key, c); return c;
}
// đĩa pixel (viền màu) cache theo (bán kính ô, màu)
const diskCache = new Map();
function pixDisk(rc, col, fill) {
    const key = rc + col + fill; let c = diskCache.get(key); if (c) return c;
    const S = rc * 2 + 2; c = mk(S, S); const g = c.getContext('2d');
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
        const d = Math.hypot(x + 0.5 - S / 2, y + 0.5 - S / 2);
        if (d < rc + 0.4) { g.fillStyle = d > rc - 1.1 ? col : (d > rc - 2.0 ? mix(col, fill, 0.55) : fill); g.fillRect(x, y, 1, 1); }
    }
    diskCache.set(key, c); return c;
}

// ============================================================
// Vòng ma thuật pixel (dựng bằng ImageData ở độ phân giải thấp rồi phóng to)
// ============================================================
const CIR = mk(60, 30), CIRg = CIR.getContext('2d'), CIRid = CIRg.createImageData(60, 30);
function drawCircle(ctx, sx, sy, width, t, col, col2, alpha, spin, asp) {
    const Wr = 60, Hr = 30, d = CIRid.data, c1 = hex(col), c2 = hex(col2 || '#ffffff'); d.fill(0);
    const pulse = 0.5 + 0.5 * Math.sin(t * 5);
    for (let y = 0; y < Hr; y++) for (let x = 0; x < Wr; x++) {
        const u = (x + 0.5 - Wr / 2) / (Wr / 2), v = (y + 0.5 - Hr / 2) / (Hr / 2), r = Math.hypot(u, v);
        if (r > 1) continue;
        const a = Math.atan2(v, u) + (spin || 0);
        let c = null, k = 1;
        if (r > 0.9) c = c1;
        else if (r > 0.84) { c = c2; k = 0.85; }
        else if (r > 0.7 && r < 0.78) c = c1;
        else if (r > 0.42 && r < 0.66) {                        // dải chữ rune: ô sáng / tối theo góc
            const seg = Math.floor(((a / TAU) + 2) * 16) % 16, sub = (r - 0.42) / 0.24;
            const pat = (seg * 7 + 3) % 5;
            if ((pat < 2 && sub > 0.15 && sub < 0.85) || (pat === 2 && (sub < 0.3 || sub > 0.7)) || (pat === 3 && Math.abs(sub - 0.5) < 0.18)) { c = c2; k = 0.55 + 0.45 * pulse; }
        } else if (r < 0.2) { c = c2; k = 0.6 + 0.4 * pulse; }
        else if (r < 0.28) c = c1;
        // ngôi sao 6 cánh ở giữa
        if (!c && r < 0.42) { const star = Math.abs(Math.cos(a * 3 + t)); if (r < 0.2 + star * 0.2 && star > 0.7) { c = c1; k = 0.8; } }
        if (c) { const i = (y * Wr + x) * 4; d[i] = c[0] * k + 255 * (1 - k) * 0; d[i + 1] = c[1] * k; d[i + 2] = c[2] * k; d[i + 3] = 255; }
    }
    CIRg.putImageData(CIRid, 0, 0);
    ctx.save(); ctx.imageSmoothingEnabled = false; ctx.globalAlpha *= alpha;
    const hh = width * (asp || 0.5);
    ctx.drawImage(CIR, Math.round(sx - width / 2), Math.round(sy - hh / 2), Math.round(width), Math.round(hh));
    ctx.restore();
}

// ============================================================
// Cột sáng pixel: các lớp trắng / màu / viền, có sọc cuộn lên
// ============================================================
function drawPillar(ctx, sx, gy, w, h, t, col, col2, alpha) {
    ctx.save(); ctx.imageSmoothingEnabled = false;
    const cw = Math.max(CELL * 2, snap(w)), top = gy - h;
    const layers = [[1, col2, 0.28], [0.74, col, 0.5], [0.46, mix(col, '#ffffff', 0.55), 0.8], [0.2, '#ffffff', 1]];
    for (const [k, c, a] of layers) {
        const lw = snap(cw * k), x0 = Math.round(sx - lw / 2);
        ctx.globalAlpha = alpha * a; ctx.fillStyle = c; ctx.fillRect(x0, top, lw, h);
    }
    // sọc năng lượng cuộn lên
    ctx.fillStyle = '#ffffff';
    for (let y = gy; y > top; y -= 18) {
        const yy = y - ((t * 220) % 18); const wob = Math.sin(yy * 0.05 + t * 8) * cw * 0.12, lw = snap(cw * (0.3 + 0.35 * (hash2(Math.floor(yy / 18), 3)))), a = clamp((yy - top) / h, 0, 1) * 0.55;
        ctx.globalAlpha = alpha * a; ctx.fillRect(Math.round(sx - lw / 2 + wob), Math.round(yy), lw, 3);
    }
    // chân cột: vòng sáng
    ctx.globalAlpha = alpha * 0.9; ctx.fillStyle = col2; ctx.fillRect(Math.round(sx - cw * 0.75), gy - 3, Math.round(cw * 1.5), 3);
    ctx.restore();
}

// ============================================================
// Tia laser pixel: ô vuông 6px, 5 lớp màu, nhiễu năng lượng chạy dọc tia
// ============================================================
function drawBeam(ctx, x, y, len, dir, t, th, pal) {
    const cell = 6, rows = Math.max(3, Math.round(th / cell) | 1), mid = (rows - 1) / 2;
    pal = pal || ['#ffffff', '#ffb3b3', '#ff4d4d', '#8f1020'];
    ctx.save(); ctx.imageSmoothingEnabled = false; ctx.translate(Math.round(x), Math.round(y)); if (dir < 0) ctx.scale(-1, 1);
    const wob = Math.sin(t * 50) * 1.2;
    for (let r = 0; r < rows; r++) {
        const d = Math.abs(r - mid) / Math.max(1, mid), c = d < 0.2 ? pal[0] : d < 0.5 ? pal[1] : d < 0.85 ? pal[2] : pal[3];
        ctx.fillStyle = c; ctx.fillRect(0, Math.round((r - mid) * cell - cell / 2 + wob * d), len, cell);
    }
    const f = Math.floor(t * 38);
    for (let i = 0; i < len / cell; i++) for (let r = 0; r < rows; r += 1) {
        const d = Math.abs(r - mid) / Math.max(1, mid);
        const h = hash2(i + f * 3, r + (f % 5));
        if (d > 0.3 && h > 0.86) { ctx.fillStyle = h > 0.95 ? pal[0] : pal[1]; ctx.fillRect(i * cell, Math.round((r - mid) * cell - cell / 2), cell, cell); }
        else if (d > 0.65 && h < 0.07) { ctx.fillStyle = pal[3]; ctx.fillRect(i * cell, Math.round((r - mid) * cell - cell / 2), cell, cell); }
    }
    ctx.restore();
}
function drawBeamAim(ctx, x, y, len, dir, t, col) {
    ctx.save(); ctx.translate(Math.round(x), Math.round(y)); if (dir < 0) ctx.scale(-1, 1);
    const cell = 6, f = Math.floor(t * 12);
    for (let i = 0; i < len / cell; i++) if ((i + f) % 4 < 2) { ctx.globalAlpha = 0.35 + 0.45 * Math.abs(Math.sin(t * 22)); ctx.fillStyle = col || '#ff4d4d'; ctx.fillRect(i * cell, -3, cell, 6); }
    ctx.restore();
}

// ============================================================
// Sóng đất kiểu gai tinh thể pixel (cho đòn đập đất)
// ============================================================
function drawSpikeWave(ctx, sx, sy, w, h, dir, t, cols) {
    cols = cols || ['#f3e8ff', '#c084fc', '#7e22ce', '#2e1065'];
    const cell = 6, n = Math.max(3, Math.round(w / cell)); ctx.save(); ctx.imageSmoothingEnabled = false; ctx.translate(Math.round(sx), Math.round(sy)); ctx.scale(dir, 1);
    const x0 = -w / 2;
    for (let i = 0; i < n; i++) {
        const k = i / (n - 1);                                   // 0 = đuôi, 1 = đầu sóng
        const ph = (i * 0.9 + t * 24), tooth = 0.55 + 0.45 * Math.abs(Math.sin(ph * 0.9));
        const hh = Math.round(h * Math.pow(k, 0.7) * tooth / cell) * cell + cell;
        const x = Math.round(x0 + i * cell);
        for (let j = 0; j < hh / cell; j++) {
            const top = j === hh / cell - 1, c = top ? cols[0] : (j > hh / cell - 3 ? cols[1] : (j % 3 === 0 ? cols[3] : cols[2]));
            ctx.fillStyle = c; ctx.fillRect(x, h / 2 - (j + 1) * cell, cell, cell);
        }
    }
    ctx.restore();
}

// ============================================================
// Đạn cầu meme (đầu meme pixel hoá trong đĩa năng lượng + 4 hạt quay quanh)
// ============================================================
function drawOrb(ctx, x, y, r, img, t, col, glow) {
    const rc = Math.max(5, Math.round(r / 3));
    const disk = pixDisk(rc, glow || '#a855f7', col || '#1b1240');
    ctx.save(); ctx.imageSmoothingEnabled = false;
    blit(ctx, disk, x, y, 3);
    const hd = pixHead(img, rc * 2 - 4);
    if (hd) { ctx.drawImage(hd, Math.round(x - hd.width * 1.5), Math.round(y - hd.height * 1.5), hd.width * 3, hd.height * 3); }
    ctx.fillStyle = '#fff';
    for (let k = 0; k < 4; k++) { const a = t * 6 + k * TAU / 4; ctx.fillRect(snap(x + Math.cos(a) * (r + 8)), snap(y + Math.sin(a) * (r + 8)), 3, 3); }
    ctx.restore();
}
// Thiên thạch Troll: đầu meme pixel + đuôi lửa vuông
function drawMeteor(ctx, x, y, r, img, t, vy) {
    ctx.save(); ctx.imageSmoothingEnabled = false;
    const fire = ['#fff7ae', '#ffb02e', '#ff5a1f', '#8a1c0a'];
    for (let i = 0; i < 12; i++) {
        const k = i / 12, yy = y - 14 - i * 8 * (vy > 0 ? 1 : -1) * 1, ww = snap(r * 1.6 * (1 - k * 0.8)), jitter = (hash2(i, Math.floor(t * 20)) - 0.5) * 12;
        ctx.globalAlpha = 1 - k * 0.8; ctx.fillStyle = fire[Math.min(3, Math.floor(k * 4))];
        ctx.fillRect(snap(x - ww / 2 + jitter), snap(yy), ww, 9);
    }
    ctx.globalAlpha = 1; drawOrb(ctx, x, y, r, img, t, '#2a0e0e', '#ff7a1f'); ctx.restore();
}

// ============================================================
// HỆ THỐNG FX DÙNG CHUNG
// ============================================================
// ============================================================
// VỆT ĐÒN ĐÁNH PIXEL (Ricardo đấm / đá): trăng khuyết ô vuông 3px, 4 tông màu (viền tối > màu đòn > sáng > trắng nóng),
// đuôi tan dần kiểu dither. head/tail = góc (rad) của đầu/đuôi vệt; sq < 1 => elip (đòn xoay).
// ============================================================
function drawSwing(ctx, cx, cy, dir, R, th, tail, head, col, alpha, sq = 1, seed = 0) {
    const dark = mix(col, '#000000', 0.5), mid = col, light = mix(col, '#ffffff', 0.55);
    const N = Math.max(24, Math.ceil(Math.abs(head - tail) * R / 2.4));
    ctx.save(); ctx.imageSmoothingEnabled = false;
    for (let i = 0; i <= N; i++) {
        const k = i / N, an = tail + (head - tail) * k;
        const taper = k > 0.93 ? (1 - k) / 0.07 : 1, w = Math.max(3, th * Math.pow(k, 1.15) * (0.25 + 0.75 * taper) + 3);
        const ca = Math.cos(an) * dir, sa = Math.sin(an) * sq, fade = clamp(k * 1.7, 0, 1);
        for (let j = 0; j * 3 < w; j++) {
            const off = -w / 2 + j * 3, q = Math.abs(off + 1.5) / (w / 2);          // 0 = giữa vệt, 1 = mép
            if (k < 0.55 && hash2(i * 7 + j + seed, j * 3 + seed) > fade * 1.15 + 0.12) continue;      // đuôi tan rời rạc
            const hot = k > 0.8 && q < 0.5;
            ctx.globalAlpha = alpha * (0.35 + 0.65 * fade);
            ctx.fillStyle = hot ? '#ffffff' : q > 0.78 ? dark : q > 0.45 ? mid : q > 0.18 ? light : '#ffffff';
            ctx.fillRect(snap(cx + ca * (R + off)), snap(cy + sa * (R + off)), CELL, CELL);
        }
    }
    ctx.restore();
}
// Đòn nhẹ (JAB / CROSS...): vạch gió ngang 3px lao tới trước nắm đấm + tia lửa đầu nắm tay
function drawThrust(ctx, x, y, dir, len, t, col) {
    const light = mix(col, '#ffffff', 0.55), e = 1 - Math.pow(1 - clamp(t / 0.7, 0, 1), 2), a = t > 0.65 ? (1 - t) / 0.35 : 1;
    ctx.save(); ctx.imageSmoothingEnabled = false;
    const rows = [[-12, 0.55, 40], [-6, 0.8, 64], [0, 1, 90], [6, 0.8, 64], [12, 0.55, 40]];
    for (const [oy, k, L0] of rows) {
        const L = L0 * (len / 90), head = 18 + (len - 18) * e * k, tail = Math.max(10, head - L);
        for (let d = tail; d < head; d += CELL) {
            const q = (d - tail) / Math.max(1, head - tail);
            if (q < 0.5 && hash2(Math.floor(d / 3), oy + 99) > q * 2 + 0.25) continue;
            ctx.globalAlpha = a * (0.3 + 0.7 * q); ctx.fillStyle = q > 0.85 ? '#ffffff' : q > 0.55 ? light : col;
            ctx.fillRect(snap(x + dir * d), snap(y + oy), CELL, CELL);
        }
    }
    if (t < 0.6) {   // tia lửa 4 hướng ở đầu nắm đấm
        const hx = x + dir * (18 + (len - 18) * e), s = (1 - t / 0.6); ctx.globalAlpha = a; ctx.fillStyle = '#ffffff';
        ctx.fillRect(snap(hx - 3), snap(y - 3), 6, 6); ctx.fillStyle = col;
        for (const [ox, oy2] of [[9, 0], [-9, 0], [0, 9], [0, -9]]) ctx.fillRect(snap(hx + ox * s * 1.6), snap(y + oy2 * s * 1.6), CELL, CELL);
    }
    ctx.restore();
}

// ============================================================
// SÓNG XUNG KÍCH ULTIMATE (ETERNAL DANCE) — vẽ bằng pixel, bám đúng bán kính sóng w.r đang gây sát thương:
// vành elip sát đất (2 vòng) + hai bức tường lửa pixel ở mép sóng + vòng hào quang quanh thân.
// w = { x, y (mặt đất), r, maxR, color, final }
// ============================================================
function drawShockWave(ctx, cam, w, time = 0) {
    const p = clamp(w.r / w.maxR, 0, 1), a = 1 - Math.pow(p, 1.7);
    if (a <= 0.02 || w.r < 8) return;
    const fin = !!w.final, big = fin ? 1.8 : 1;
    const C = fin ? ['#ffffff', '#ffd45a', '#ff6ec7'] : [mix(w.color, '#ffffff', 0.65), w.color, mix(w.color, '#000000', 0.45)];   // [lõi, thân, viền tối]
    const gx = cam.screenX(w.x), gy = cam.screenY(w.y), r = w.r, YS = 0.17, tick = Math.floor(time * 18);
    ctx.save(); ctx.imageSmoothingEnabled = false;
    // 1) vành elip sát đất: dày ở mép trước, nửa sau mờ hơn (chiều sâu); lõi trắng nóng ở giữa dải
    const ellipse = (rr, thick, al, seed) => {
        if (rr < 6) return;
        const n = Math.ceil(TAU * rr / 3.2);
        for (let i = 0; i < n; i++) {
            const an = i / n * TAU, sn = Math.sin(an), back = sn < 0, x = gx + Math.cos(an) * rr, y = gy + sn * rr * YS;
            if (hash2(i + seed, tick) > 0.93) continue;                                        // chớp nháy rời rạc
            for (let k = -thick; k <= thick; k += CELL) {
                const q = Math.abs(k) / (thick + 1);
                ctx.globalAlpha = al * (back ? 0.5 : 1) * (0.45 + 0.55 * (1 - q));
                ctx.fillStyle = q < 0.25 ? C[0] : q < 0.7 ? C[1] : C[2];
                ctx.fillRect(snap(x), snap(y + k), CELL, CELL);
            }
        }
    };
    ellipse(r, (fin ? 12 : 7), a, 1);
    ellipse(r * 0.86, (fin ? 6 : 3), a * 0.75, 77);
    if (fin) ellipse(r * 0.7, 3, a * 0.6, 151);
    // 2) hai bức tường lửa pixel ở mép trái/phải của sóng: cao nhất sát mép, thấp dần vào trong, cuộn lên theo thời gian
    const depth = fin ? 90 : 57, curtain = (1 - p * 0.65);
    for (const sd of [-1, 1]) {
        for (let d = 0; d < depth; d += CELL) {
            const col = Math.floor(d / CELL), fall = Math.pow(1 - d / depth, 1.25);
            const H = (34 + hash2(col + (sd > 0 ? 40 : 0), tick) * 52) * fall * curtain * big;
            for (let yy = 0; yy < H; yy += CELL) {
                const f = yy / Math.max(H, 1);
                if (f > 0.55 && hash2(col * 3 + yy, tick + sd) > 1.15 - f * 0.9) continue;   // đỉnh lửa tan rời
                ctx.globalAlpha = a * (1 - f * 0.55);
                ctx.fillStyle = (d < 9 && f < 0.5) ? C[0] : f < 0.35 ? C[0] : f < 0.7 ? C[1] : C[2];
                ctx.fillRect(snap(gx + sd * (r - d)), snap(gy - yy - 3), CELL, CELL);
            }
        }
    }
    // 3) vòng hào quang tròn quanh thân Ricardo, nở nhanh hơn sóng đất
    const hr = r * (fin ? 0.78 : 0.6), hy = gy - 70, hn = Math.ceil(TAU * hr / 4.5), sz = fin ? 6 : 3;
    for (let i = 0; i < hn; i++) {
        if (hash2(i, tick + 5) > 0.88) continue;
        const an = i / hn * TAU; ctx.globalAlpha = a * 0.8; ctx.fillStyle = i % 5 === 0 ? C[1] : C[0];
        ctx.fillRect(snap(gx + Math.cos(an) * hr), snap(hy + Math.sin(an) * hr), sz, sz);
    }
    ctx.restore();
}

class PixelFx {
    constructor() { this.list = []; this.sq = []; this.time = 0; }
    clear() { this.list.length = 0; this.sq.length = 0; }
    // ---- hạt vuông ----
    sparks(x, y, n, o = {}) {
        for (let i = 0; i < n; i++) {
            if (this.sq.length > 700) break;
            const a = o.angle !== undefined ? o.angle + (Math.random() - 0.5) * (o.cone || 1) : Math.random() * TAU, sp = rand(o.min || 60, o.max || 260);
            const cols = o.col || ['#ffffff'];
            this.sq.push({ x: x + (o.sx || 0) * (Math.random() - 0.5), y: y + (o.sy || 0) * (Math.random() - 0.5), vx: Math.cos(a) * sp, vy: Math.sin(a) * sp * (o.flat || 1) + (o.up ? -o.up : 0), g: o.g === undefined ? 500 : o.g, t: 0, life: rand(o.life || 0.5, (o.life || 0.5) * 1.5), size: o.size || (Math.random() < 0.3 ? 6 : 3), col: cols[Math.floor(Math.random() * cols.length)], drag: o.drag || 0 });
        }
    }
    // tan biến: thân quái vỡ thành điểm ảnh
    dissolve(x, y, w, h, cols, n = 40) {
        for (let i = 0; i < n; i++) this.sq.push({ x: x + rand(-w / 2, w / 2), y: y + rand(0, h), vx: rand(-90, 90), vy: rand(-220, -40), g: 180, t: 0, life: rand(0.4, 0.9), size: Math.random() < 0.4 ? 6 : 3, col: cols[Math.floor(Math.random() * cols.length)], drag: 0 });
    }
    // hút vào: hạt bay từ xa về tâm
    implode(x, y, r, cols, n = 28, life = 0.4) {
        for (let i = 0; i < n; i++) { const a = Math.random() * TAU, d = rand(r * 0.6, r), l = rand(life * 0.7, life); this.sq.push({ x: x + Math.cos(a) * d, y: y + Math.sin(a) * d * 0.8, vx: -Math.cos(a) * d / l, vy: -Math.sin(a) * d * 0.8 / l, g: 0, t: 0, life: l, size: Math.random() < 0.3 ? 6 : 3, col: cols[Math.floor(Math.random() * cols.length)], drag: 0 }); }
    }
    // ---- hiệu ứng có hình ----
    circle(x, gy, w, life, col, col2, o = {}) { this.list.push({ type: 'circle', x, y: gy, w, life, t: 0, col, col2: col2 || '#fff', spin: o.spin === undefined ? 1.2 : o.spin, grow: o.grow === undefined ? 0.25 : o.grow, fade: o.fade === undefined ? 0.25 : o.fade }); }
    pillar(x, gy, w, h, life, col, col2) { this.list.push({ type: 'pillar', x, y: gy, w, h, life, t: 0, col, col2: col2 || col }); }
    ring(x, y, r0, r1, life, col, o = {}) { this.list.push({ type: 'ring', x, y, r0, r1, life, t: 0, col, n: o.n || 28, sq: o.sq === undefined ? 1 : o.sq, size: o.size || 6 }); }
    mark(x, gy, life, col) { this.list.push({ type: 'mark', x, y: gy, life, t: 0, col: col || '#ff4d4d' }); }
    text(x, y, str, col, life = 0.9, size = 14) { this.list.push({ type: 'text', x, y, str, col: col || '#fff', life, t: 0, size }); }
    icon(x, y, key, life = 0.9, scale = 4) { this.list.push({ type: 'icon', x, y, key, life, t: 0, scale }); }
    slash(x, y, dir, R, col, life = 0.22, o = {}) { this.list.push({ type: 'slash', x, y, dir, R, col, col2: o.col2 || '#ffffff', life, t: 0, a0: o.a0 === undefined ? -1.25 : o.a0, a1: o.a1 === undefined ? 1.15 : o.a1, th: o.th || 18 }); }
    // tia nổ trúng đòn dạng pixel: 4 tia dài + 4 tia chéo ngắn + lõi vuông
    hit(x, y, r, col, life = 0.28) { this.list.push({ type: 'hit', x, y, r, col, life, t: 0 }); }
    // trọn bộ hiệu ứng trúng đòn: tia nổ + vòng ô vuông + mảnh vỡ bay theo hướng đánh + chữ POW! pixel
    // power: 0 = đòn nhẹ, 1 = đòn nặng, 2 = FINISHER
    punchHit(x, y, col, power = 0, dir = 1, word = '') {
        const R = [38, 62, 104][power], L = [0.2, 0.28, 0.4][power], light = mix(col, '#ffffff', 0.55);
        this.hit(x, y, R, col, L);
        this.ring(x, y, 6, [54, 86, 150][power], [0.24, 0.32, 0.46][power], '#ffffff', { n: [10, 16, 26][power], size: power ? 6 : 3 });
        if (power) this.ring(x, y, 4, [0, 60, 110][power], 0.28, col, { n: [0, 12, 20][power], size: 3 });
        this.sparks(x, y, [8, 16, 30][power], { col: ['#ffffff', col, light, '#ffd45a'], angle: dir > 0 ? 0 : Math.PI, cone: 2.3, min: 140, max: [380, 480, 640][power], g: 560, life: 0.42, size: power ? 6 : 3 });
        if (power === 2) this.sparks(x, y, 16, { col: ['#ffffff', col], min: 200, max: 760, g: 0, life: 0.5, drag: 0.04 });
        if (power && word) this.text(x + (Math.random() - 0.5) * 24, y - 36, word, power === 2 ? '#ff8a3d' : '#ffe27a', power === 2 ? 0.85 : 0.7, power === 2 ? 24 : 18);
    }
    pop(x, y, r, col, life = 0.3) { this.list.push({ type: 'pop', x, y, r, col, life, t: 0 }); }
    // nổ đất: vòng + hạt + vết nứt vuông
    groundBlast(x, gy, r, cols) {
        this.ring(x, gy, 10, r, 0.5, cols[1] || cols[0], { sq: 0.28, n: Math.round(r / 7), size: 6 });
        this.ring(x, gy, 6, r * 0.7, 0.4, '#ffffff', { sq: 0.28, n: Math.round(r / 10), size: 3 });
        this.sparks(x, gy - 4, Math.round(r / 6), { col: cols, angle: -Math.PI / 2, cone: 2.4, min: 120, max: 420, g: 900, life: 0.5 });
    }
    update(dt) {
        this.time += dt;
        for (let i = this.list.length - 1; i >= 0; i--) { const f = this.list[i]; f.t += dt; if (f.t >= f.life) this.list.splice(i, 1); }
        for (let i = this.sq.length - 1; i >= 0; i--) {
            const s = this.sq[i]; s.t += dt; if (s.t >= s.life) { this.sq.splice(i, 1); continue; }
            s.vy += s.g * dt; if (s.drag) { const k = Math.pow(1 - s.drag, dt * 60); s.vx *= k; s.vy *= k; } s.x += s.vx * dt; s.y += s.vy * dt;
        }
    }
    draw(ctx, cam) {
        ctx.save(); ctx.imageSmoothingEnabled = false;
        for (const f of this.list) this._drawOne(ctx, cam, f);
        for (const s of this.sq) {
            const a = 1 - s.t / s.life; ctx.globalAlpha = a < 0.35 ? a / 0.35 : 1; ctx.fillStyle = s.col;
            const sz = a < 0.25 ? Math.max(3, s.size - 3) : s.size;
            ctx.fillRect(snap(cam.screenX(s.x)), snap(cam.screenY(s.y)), sz, sz);
        }
        ctx.restore();
    }
    _drawOne(ctx, cam, f) {
        const p = clamp(f.t / f.life, 0, 1), sx = cam.screenX(f.x), sy = cam.screenY(f.y);
        ctx.save(); ctx.globalAlpha = 1;
        switch (f.type) {
            case 'circle': { const k = f.grow > 0 ? Math.min(1, p / f.grow) : 1, a = p > 1 - f.fade ? (1 - p) / f.fade : 1; drawCircle(ctx, sx, sy, f.w * (0.25 + 0.75 * (1 - Math.pow(1 - k, 3))), f.t, f.col, f.col2, a, f.t * f.spin, 0.36); break; }
            case 'pillar': { const a = Math.sin(Math.PI * Math.min(1, p * 1.15)), hh = f.h * Math.min(1, p * 6); drawPillar(ctx, sx, sy, f.w * (0.6 + 0.4 * a), hh, f.t, f.col, f.col2, a); break; }
            case 'ring': {
                const r = lerp(f.r0, f.r1, 1 - Math.pow(1 - p, 2.2)), a = 1 - p; ctx.globalAlpha = a; ctx.fillStyle = f.col;
                for (let k = 0; k < f.n; k++) { const an = k / f.n * TAU + f.t * 0.6; ctx.fillRect(snap(sx + Math.cos(an) * r), snap(sy + Math.sin(an) * r * f.sq), f.size, f.size); }
                break;
            }
            case 'mark': {      // dấu X cảnh báo thu nhỏ dần
                const r = 36 * (1 - p) + 12, blink = Math.floor(f.t * 14) % 2;
                ctx.globalAlpha = 0.5 + 0.5 * blink; ctx.fillStyle = f.col;
                for (let i = -2; i <= 2; i++) { ctx.fillRect(snap(sx + i * 9), snap(sy - 12 + i * 4 * 0 + i * 3), 6, 6); ctx.fillRect(snap(sx + i * 9), snap(sy - 12 - i * 3), 6, 6); }
                drawCircle(ctx, sx, sy, r * 3.2, f.t, f.col, '#fff', 0.7, f.t * 3);
                break;
            }
            case 'text': {
                const rise = p * 26, a = p > 0.7 ? (1 - p) / 0.3 : 1, sc = p < 0.15 ? 0.6 + p / 0.15 * 0.4 : 1;
                ctx.globalAlpha = a; ctx.font = `${Math.round(f.size * sc)}px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
                ctx.fillStyle = '#12091e'; for (const [ox, oy] of [[-3, 0], [3, 0], [0, -3], [0, 3], [3, 3]]) ctx.fillText(f.str, snap(sx + ox), snap(sy - rise + oy));
                ctx.fillStyle = f.col; ctx.fillText(f.str, snap(sx), snap(sy - rise)); break;
            }
            case 'icon': {
                const pop = p < 0.2 ? 0.3 + p / 0.2 * 0.9 : 1.2 - (p - 0.2) * 0.25, a = p > 0.75 ? (1 - p) / 0.25 : 1;
                ctx.globalAlpha = a; blit(ctx, SPR[f.key], sx, sy - p * 14 + Math.sin(f.t * 22) * 2, f.scale * pop, { rot: Math.sin(f.t * 18) * 0.12 }); break;
            }
            case 'slash': {
                const N = 22, a0 = f.a0, a1 = f.a1, reveal = clamp(p / 0.55, 0, 1), fade = p > 0.55 ? 1 - (p - 0.55) / 0.45 : 1;
                for (let i = 0; i < N * reveal; i++) {
                    const k = i / (N - 1), an = lerp(a0, a1, k), w = Math.sin(Math.PI * k) * f.th + 3, cx = Math.cos(an), cy = Math.sin(an);
                    for (let j = 0; j * 3 < w; j++) {
                        const rr = f.R - w / 2 + j * 3, hot = Math.abs(j * 3 - w / 2) < w * 0.22;
                        ctx.globalAlpha = fade * (0.5 + 0.5 * k); ctx.fillStyle = hot ? f.col2 : f.col;
                        ctx.fillRect(snap(sx + f.dir * cx * rr), snap(sy + cy * rr), 3, 3);
                    }
                }
                break;
            }
            case 'hit': {
                const e = 1 - Math.pow(1 - p, 2.4), r = f.r * (0.35 + 0.65 * e), a = p > 0.55 ? (1 - p) / 0.45 : 1, light = mix(f.col, '#ffffff', 0.55);
                ctx.globalAlpha = a;
                for (let i = 0; i < 8; i++) {
                    const ang = i * Math.PI / 4, dx = Math.cos(ang), dy = Math.sin(ang), long = i % 2 === 0, L = r * (long ? 1 : 0.6), T = long ? 12 : 8;
                    for (let d = 6; d < L; d += CELL) {
                        const q = d / L, th = Math.max(CELL, Math.round((1 - q) * T / CELL) * CELL);
                        ctx.fillStyle = q < 0.3 ? '#ffffff' : q < 0.65 ? light : f.col;
                        for (let u = -th / 2; u < th / 2; u += CELL) ctx.fillRect(snap(sx + dx * d - dy * u), snap(sy + dy * d + dx * u), CELL, CELL);
                    }
                }
                for (const [rr, cc] of [[snap(r * 0.2) + 3, f.col], [snap(r * 0.11), '#ffffff']]) {      // lõi hình thoi pixel (màu đòn + trắng nóng)
                    ctx.fillStyle = cc;
                    for (let dy = -rr; dy <= rr; dy += CELL) { const hw = rr - Math.abs(dy); ctx.fillRect(snap(sx - hw), snap(sy + dy), hw * 2 + CELL, CELL); }
                }
                break;
            }
            case 'pop': {
                const r = f.r * (0.3 + 0.7 * (1 - Math.pow(1 - p, 2))), a = 1 - p; ctx.globalAlpha = a; ctx.fillStyle = f.col;
                for (let k = 0; k < 8; k++) { const an = k * TAU / 8; for (let j = 0.4; j <= 1; j += 0.2) ctx.fillRect(snap(sx + Math.cos(an) * r * j), snap(sy + Math.sin(an) * r * j), 6 - (j > 0.7 ? 3 : 0), 6 - (j > 0.7 ? 3 : 0)); }
                ctx.fillStyle = '#fff'; ctx.fillRect(snap(sx) - 6, snap(sy) - 6, 12, 12); break;
            }
        }
        ctx.restore();
    }
}

// ============================================================
// CỔNG DỊCH CHUYỂN — xuất hiện khi dọn sạch màn: vòng rune dưới đất, cột sáng, khung đá trồi lên, xoáy năng lượng mở ra
// ============================================================
const THEMES = {
    forest: { dark: '#04210f', mid: '#0f7a3c', light: '#3ee08a', white: '#d8ffe8', glow: '#2aff8a', stone: ['#2f3d38', '#415650', '#1b2623', '#6f8f84'] },
    lava: { dark: '#2a0700', mid: '#a8280a', light: '#ff8a1f', white: '#fff1c2', glow: '#ff6a00', stone: ['#3d2a28', '#56403b', '#241615', '#8a6a5e'] },
    demon: { dark: '#1a0030', mid: '#6d1fb0', light: '#d946ef', white: '#fde7ff', glow: '#ef4444', stone: ['#34283f', '#4a3a5c', '#1e1528', '#7a6a96'] },
    gold: { dark: '#2a1c00', mid: '#b8860b', light: '#ffd45a', white: '#fffbe0', glow: '#ffd45a', stone: ['#3d3526', '#554a35', '#241f14', '#8c7d5c'] },
};
const frameCache = {};
const CELLP = 5, FW = 56, FH = 72, IX = 10, IY = 10, IW = 36, IH = 56;
function insideOuter(x, y) { if (x < 0 || x >= FW || y < 0 || y >= FH) return false; if (y < 28) return Math.hypot(x + 0.5 - 28, y + 0.5 - 28) < 28; return true; }
function insideInner(x, y) { if (x < IX || x >= IX + IW || y < IY || y >= FH - 6) return false; if (y < 28) return Math.hypot(x + 0.5 - 28, y + 0.5 - 28) < 18; return true; }
function buildFrame(th) {
    const T = THEMES[th], c = mk(FW, FH), g = c.getContext('2d'), gl = mk(FW, FH), gg = gl.getContext('2d');
    for (let y = 0; y < FH; y++) for (let x = 0; x < FW; x++) {
        const base = y >= FH - 6 && x >= 2 && x < FW - 2;                         // bệ đá
        if (!(insideOuter(x, y) && !insideInner(x, y)) && !base) continue;
        if (base && insideInner(x, y)) continue;
        const brickH = 6, row = Math.floor(y / brickH), off = (row % 2) * 6, mortar = (y % brickH === 0) || ((x + off) % 12 === 0);
        let col = T.stone[0];
        const n = hash2(x, y);
        if (mortar) col = T.stone[2]; else if (n > 0.8) col = T.stone[1]; else if (n < 0.1) col = T.stone[2];
        const upIn = !(insideOuter(x, y - 1) && !insideInner(x, y - 1)) && !(y - 1 >= FH - 6), leftIn = !(insideOuter(x - 1, y) && !insideInner(x - 1, y));
        if (upIn || leftIn) col = T.stone[3];                                      // mép sáng
        if (insideInner(x + 1, y) || insideInner(x, y + 1) && y < FH - 7) col = T.stone[2];            // mép trong tối
        g.fillStyle = col; g.fillRect(x, y, 1, 1);
    }
    // rune phát sáng dọc khung (lưu ở lớp glow)
    gg.fillStyle = T.light;
    const runes = [];
    for (let k = 0; k < 14; k++) { const a = Math.PI + (k / 13) * Math.PI, r = 23; runes.push([Math.round(28 + Math.cos(a) * r), Math.round(28 + Math.sin(a) * r)]); }
    for (let y = 30; y < FH - 10; y += 8) { runes.push([4, y]); runes.push([FW - 5, y]); }
    for (const [x, y] of runes) { gg.fillRect(x, y, 1, 3); gg.fillRect(x - 1, y + 1, 3, 1); }
    // đá chốt đỉnh (ngọc)
    const gem = [[28, 3], [27, 4], [28, 4], [29, 4], [26, 5], [27, 5], [28, 5], [29, 5], [30, 5], [27, 6], [28, 6], [29, 6], [28, 7]];
    for (const [x, y] of gem) { g.fillStyle = T.light; g.fillRect(x, y, 1, 1); gg.fillStyle = T.white; gg.fillRect(x, y, 1, 1); }
    g.fillStyle = T.white; g.fillRect(27, 5, 1, 1);
    return { frame: outline(c, '#0a0612'), glow: gl };
}
const VOR = mk(IW, IH), VORg = VOR.getContext('2d'), VORid = VORg.createImageData(IW, IH);
function drawVortex(th, t, open, speed) {
    const T = THEMES[th], pal = [hex(T.dark), hex(T.mid), hex(T.light), hex(T.white)], d = VORid.data; d.fill(0);
    for (let y = 0; y < IH; y++) for (let x = 0; x < IW; x++) {
        if (y < 18 && Math.hypot(x + 0.5 - 18, y + 0.5 - 18) >= 18) continue;
        const u = (x + 0.5 - 18) / 18, v = (y + 0.5 - 28) / 28, r = Math.hypot(u, v), R0 = open * 1.25;
        if (r > R0) continue;
        const a = Math.atan2(v, u), s = Math.sin(a * 3 + r * 9 - t * 5 * speed + Math.sin(a * 2 - t * 2) * 1.2);
        let val = s * 0.5 + 0.5 + (1 - r) * 0.4 + (r > R0 - 0.1 ? 0.5 : 0);
        let k = val > 1.15 ? 3 : val > 0.85 ? 2 : val > 0.45 ? 1 : 0;
        if (r < 0.14) k = 3; else if (r < 0.26 && k < 2) k = 2;
        if (hash2(x, y + Math.floor(t * 7)) > 0.988) k = 3;
        const c = pal[k], i = (y * IW + x) * 4; d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = 255;
    }
    VORg.putImageData(VORid, 0, 0); return VOR;
}

class Portal {
    // x: tâm cổng (world), gy: mặt đất, theme: 'forest' | 'lava' | 'demon' | 'gold'
    constructor(x, gy, theme, label, sub) {
        this.x = x; this.gy = gy; this.theme = theme; this.label = label; this.sub = sub;
        this.t = 0; this.state = 'opening'; this.open = 0; this.rise = 0; this.fade = 0; this.stT = 0; this.spawnT = 0; this.sfx = {};
        if (!frameCache[theme]) frameCache[theme] = buildFrame(theme);
        this.fr = frameCache[theme]; this.done = false; this.ground = null;
    }
    get cy() { return this.gy - 170; }
    contains(p) { return this.state === 'open' && Math.abs(p.x + p.w / 2 - this.x) < 85 && (p.y + p.h) > this.gy - 150; }
    begin() { if (this.state === 'open') { this.state = 'entering'; this.stT = 0; } }
    update(dt, world) {
        const T = THEMES[this.theme], fx = PXFX.fx; this.t += dt; this.stT += dt;
        const once = (k, fn) => { if (!this.sfx[k]) { this.sfx[k] = true; fn(); } };
        if (this.state === 'opening') {
            const t = this.t;
            once('a', () => { world.camera.shake(5, 1.0); world.audio.playCine('freeze'); world.banner('CONG DICH CHUYEN', 'DANG MO...', 1.6, T.light); });
            if (t < 0.9) { if (Math.random() < 0.9) fx.implode(this.x, this.gy - 10, 320, [T.light, T.white, T.mid], 3, 0.5); }
            if (t > 0.9) once('b', () => { { world.audio.playRoar(); world.camera.shake(14, 0.9); world.flash(0.5); fx.pillar(this.x, this.gy, 230, 760, 1.9, T.light, T.mid); fx.ring(this.x, this.gy, 10, 440, 0.8, T.white, { sq: 0.28, n: 60, size: 6 }); fx.ring(this.x, this.gy, 10, 300, 0.7, T.light, { sq: 0.28, n: 46, size: 6 }); fx.groundBlast(this.x, this.gy, 260, [T.light, T.white, T.mid]); } });
            this.rise = clamp((t - 0.9) / 1.0, 0, 1);
            if (t > 0.9 && t < 1.9 && Math.random() < 0.8) fx.sparks(this.x + rand(-130, 130), this.gy - 6, 2, { col: [T.light, '#ffffff', T.glow], angle: -Math.PI / 2, cone: 0.9, min: 100, max: 360, g: 380, life: 0.8 });
            this.open = clamp((t - 1.9) / 0.9, 0, 1);
            if (t > 1.9) once('c', () => { { world.camera.shake(18, 0.7); world.flash(0.9); world.audio.playCine('impact'); world.audio.playBigImpact(); fx.pop(this.x, this.cy, 280, T.white, 0.6); fx.ring(this.x, this.cy, 20, 380, 0.7, T.light, { n: 48 }); fx.sparks(this.x, this.cy, 60, { col: [T.light, T.white, T.glow], min: 120, max: 620, g: 0, life: 0.8, drag: 0.03 }); } });
            if (t >= 2.8) { this.state = 'open'; this.open = 1; this.rise = 1; this.stT = 0; world.banner('CONG DA MO!', this.label, 1.8, T.light, true); world.audio.playCine('reveal'); }
        } else if (this.state === 'open') {
            this.open = 1; this.rise = 1; this.spawnT -= dt;
            if (this.spawnT <= 0) {
                this.spawnT = 0.035;
                const a = Math.random() * TAU, rr = rand(150, 300);
                fx.implode(this.x + Math.cos(a) * 20, this.cy + Math.sin(a) * 30, rr, [T.light, T.white, T.glow], 1, 0.7);          // hạt xoáy vào tâm
                if (Math.random() < 0.5) fx.sparks(this.x + rand(-150, 150), this.gy - 4, 1, { col: [T.light, T.white], angle: -Math.PI / 2, cone: 0.5, min: 40, max: 160, g: -30, life: 1.2, size: 3 });
            }
            if (Math.random() < 0.04) fx.ring(this.x, this.gy, 20, 300, 1.0, T.light, { sq: 0.28, n: 36, size: 3 });
        } else if (this.state === 'entering') {
            const e = this.stT;
            once('e1', () => { world.audio.playRoar(); world.camera.shake(10, 1.4); fx.ring(this.x, this.cy, 20, 460, 0.9, T.white, { n: 56 }); });
            if (Math.random() < 0.9) fx.implode(this.x, this.cy, 420, [T.white, T.light, T.glow], 5, 0.5);
            this.fade = clamp((e - 0.5) / 0.9, 0, 1);
            if (e > 1.55) { this.done = true; this.state = 'done'; }
        }
    }
    draw(ctx, cam) {
        const T = THEMES[this.theme], sx = cam.screenX(this.x), gy = cam.screenY(this.gy), t = this.t;
        if (sx < -400 || sx > 1280 + 400) return;
        ctx.save(); ctx.imageSmoothingEnabled = false;
        // 1) quầng sáng nền
        const glowA = (this.state === 'opening' ? clamp((t - 0.9) / 1.2, 0, 1) : 1) * (0.28 + 0.06 * Math.sin(t * 3));
        if (glowA > 0) { const g = ctx.createRadialGradient(sx, gy - 170, 10, sx, gy - 170, 330); g.addColorStop(0, T.light); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.globalAlpha = glowA; ctx.fillStyle = g; ctx.fillRect(sx - 340, gy - 520, 680, 700); ctx.globalAlpha = 1; }
        // 2) khung đá trồi lên từ mặt đất
        const FWpx = FW * CELLP, FHpx = FH * CELLP, dy = (1 - this.rise) * (FHpx + 20);
        if (this.rise > 0) {
            ctx.save(); ctx.beginPath(); ctx.rect(sx - 400, gy - 800, 800, 800 + 4); ctx.clip();
            const fx0 = Math.round(sx - FWpx / 2), fy0 = Math.round(gy - FHpx + dy);
            // xoáy năng lượng nằm sau khung
            if (this.open > 0) {
                const vor = drawVortex(this.theme, t, this.open, this.state === 'entering' ? 3 : 1);
                ctx.drawImage(vor, fx0 + IX * CELLP, fy0 + IY * CELLP, IW * CELLP, IH * CELLP);
            }
            ctx.drawImage(this.fr.frame, fx0 - CELLP, fy0 - CELLP, (FW + 2) * CELLP, (FH + 2) * CELLP);
            // rune phát sáng nhấp nháy (cộng sáng)
            ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = (0.55 + 0.45 * Math.sin(t * 4)) * clamp(this.rise * 1.5 - 0.2, 0, 1);
            ctx.drawImage(this.fr.glow, fx0, fy0, FWpx, FHpx);
            ctx.globalAlpha *= 0.5; ctx.drawImage(this.fr.glow, fx0 - 3, fy0 - 3, FWpx + 6, FHpx + 6);
            ctx.restore();
        }
        // 3) nhãn + mũi tên (khi đã mở)
        if (this.state === 'open') {
            const a = clamp(this.stT * 2, 0, 1), bob = Math.round(Math.sin(t * 5) * 6 / 3) * 3, ty = gy - FHpx - 52;
            ctx.globalAlpha = a; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.font = `18px ${FONT}`; this._txt(ctx, this.label, sx, ty - 30, T.white, '#10081c');
            ctx.font = `10px ${FONT}`; this._txt(ctx, this.sub, sx, ty - 6, T.light, '#10081c');
            ctx.fillStyle = '#10081c'; ctx.fillRect(sx - 18, ty + 22 + bob, 36, 9); ctx.fillRect(sx - 12, ty + 31 + bob, 24, 9); ctx.fillRect(sx - 6, ty + 40 + bob, 12, 9);
            ctx.fillStyle = T.light; ctx.fillRect(sx - 15, ty + 25 + bob, 30, 6); ctx.fillRect(sx - 9, ty + 31 + bob, 18, 6); ctx.fillRect(sx - 3, ty + 37 + bob, 6, 6);
            ctx.globalAlpha = 1;
        }
        ctx.restore();
    }
    // vòng rune dưới đất vẽ trước người chơi; phần trước (tia hạt) vẽ qua fx chung
    drawGround(ctx, cam) {
        if (this.state === 'done') return;
        const T = THEMES[this.theme], sx = cam.screenX(this.x), gy = cam.screenY(this.gy);
        if (sx < -400 || sx > 1280 + 400) return;
        const a = this.state === 'opening' ? clamp(this.t / 0.5, 0, 1) : 1, grow = this.state === 'opening' ? clamp(this.t / 0.9, 0, 1) : 1;
        ctx_save(ctx, () => { drawCircle(ctx, sx, gy + 2, 460 * (0.2 + 0.8 * (1 - Math.pow(1 - grow, 3))), this.t, T.light, T.white, a * 0.9, this.t * (this.state === 'entering' ? 3 : 0.8), 0.3); });
    }
    _txt(ctx, s, x, y, col, bg) { ctx.fillStyle = bg; for (const [ox, oy] of [[-3, 0], [3, 0], [0, -3], [0, 3], [3, 3], [-3, 3]]) ctx.fillText(s, x + ox, y + oy); ctx.fillStyle = col; ctx.fillText(s, x, y); }
}
function ctx_save(ctx, fn) { ctx.save(); fn(); ctx.restore(); }

// mũi tên chỉ hướng cổng khi nó nằm ngoài màn hình
function drawPortalArrow(ctx, portal, cam, t) {
    if (!portal || portal.state !== 'open') return;
    const sx = cam.screenX(portal.x); if (sx > 40 && sx < 1240) return;
    const T = THEMES[portal.theme], dir = sx < 0 ? -1 : 1, x = dir > 0 ? 1280 - 70 : 70, y = 330, bob = Math.round(Math.sin(t * 6) * 10 / 3) * 3 * dir;
    ctx.save(); ctx.imageSmoothingEnabled = false; ctx.translate(x + bob, y); ctx.scale(dir, 1);
    ctx.fillStyle = '#10081c'; for (let i = 0; i < 4; i++) ctx.fillRect(-30 + i * 12, -27 + i * 9, 18, 54 - i * 18);
    ctx.fillStyle = T.light; for (let i = 0; i < 4; i++) ctx.fillRect(-27 + i * 12, -21 + i * 9, 12, 42 - i * 18);
    ctx.fillStyle = '#10081c'; ctx.font = `10px ${FONT}`; ctx.textAlign = 'center'; ctx.scale(dir, 1); ctx.fillText('CONG', 0, 48); ctx.restore();
}

const PXFX = { fx: null, spr: SPR, Portal, THEMES, mix, hash2, blit, pixHead, drawOrb, drawMeteor, drawBeam, drawBeamAim, drawSpikeWave, drawSwing, drawThrust, drawShockWave, drawCircle, drawPillar, drawPortalArrow, snap };
function init() { if (!SPR.banana) buildSprites(); if (!PXFX.fx) PXFX.fx = new PixelFx(); }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
PXFX.init = init;
window.PXFX = PXFX;
})();
