/*
 * MEMEFIGHTER - Supabase public client configuration
 * 1) Create a Supabase project.
 * 2) Copy Project URL and anon/public key from Project Settings > API.
 * 3) Paste them below. NEVER put the service_role key in this file.
 */
window.MEMEFIGHTER_SUPABASE_CONFIG = {
    url: 'https://xagtjctftvzqrndsclsk.supabase.co',
    anonKey: 'sb_publishable_8itHnquN5T2kLYFQD_GQ8A_bt_1rNfs',
    siteUrl: 'https://memefighter.is-best.net'
};
