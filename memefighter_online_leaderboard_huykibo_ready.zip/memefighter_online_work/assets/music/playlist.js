// Danh sách nhạc do người dùng chọn: sảnh và trận đấu
window.USER_PLAYLIST = [
  "assets/music/Multifandom_Dancin.mp3",
  "assets/music/Ricardo Milos U Got That Halogen Full HD 60 fps.mp3"
];
