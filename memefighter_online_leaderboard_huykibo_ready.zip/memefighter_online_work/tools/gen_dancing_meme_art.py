import math, sys
import numpy as np
from PIL import Image, ImageDraw

OUT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/out'
import os; os.makedirs(OUT, exist_ok=True)

def hx(h):
    h = h.lstrip('#'); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255)

OUTL = hx('#1d0a17')
SKIN, SKIN_H, SKIN_S, SKIN_D = hx('#e0a877'), hx('#f3c99c'), hx('#bd8355'), hx('#8f5a3a')
HAIR, HAIR_M, HAIR_H, HAIR_D = hx('#3a2013'), hx('#5a3521'), hx('#85583a'), hx('#24120a')
SH, SH_L, SH_H, SH_D, SH_X = hx('#a21caf'), hx('#c026d3'), hx('#f0abfc'), hx('#701a75'), hx('#4a044e')
PT, PT_H, PT_S, PT_D = hx('#fbbf24'), hx('#fde68a'), hx('#d98b0a'), hx('#a8610a')
PINK, PINK_H, PINK_D = hx('#f472b6'), hx('#fbcfe8'), hx('#be185d')
GOLD, GOLD_H, GOLD_D = hx('#fbbf24'), hx('#fff3b0'), hx('#b45309')
WHITE = hx('#ffffff')

class G:
    def __init__(self, s, W=200, H=270, k=1.0, ax=0.0, ay=0.0):
        self.s, self.W, self.H, self.k, self.ax, self.ay = s, W, H, k, ax, ay
        self.w, self.h = math.ceil(W / s), math.ceil(H / s)
        self.im = Image.new('RGBA', (self.w, self.h), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.im)
    def X(self, x): return (self.ax + x * self.k) / self.s
    def Y(self, y): return (self.ay + y * self.k) / self.s
    def ell(self, x0, y0, x1, y1, f):
        x0, x1 = min(x0, x1), max(x0, x1); y0, y1 = min(y0, y1), max(y0, y1)
        self.d.ellipse([self.X(x0), self.Y(y0), self.X(x1), self.Y(y1)], fill=f)
    def circ(self, x, y, r, f): self.ell(x - r, y - r, x + r, y + r, f)
    def rect(self, x0, y0, x1, y1, f):
        x0, x1 = min(x0, x1), max(x0, x1); y0, y1 = min(y0, y1), max(y0, y1)
        X0, Y0 = self.X(x0), self.Y(y0); self.d.rectangle([X0, Y0, max(X0, self.X(x1) - 1), max(Y0, self.Y(y1) - 1)], fill=f)
    def poly(self, pts, f): self.d.polygon([(self.X(x), self.Y(y)) for x, y in pts], fill=f)
    def line(self, p0, p1, f, w=2):
        self.d.line([(self.X(p0[0]), self.Y(p0[1])), (self.X(p1[0]), self.Y(p1[1]))], fill=f, width=max(1, round(w * self.k / self.s)))
    def cap(self, p0, p1, w, f):
        self.line(p0, p1, f, w); self.circ(p0[0], p0[1], w / 2, f); self.circ(p1[0], p1[1], w / 2, f)
    def px(self, x, y, f):
        ix, iy = int(self.X(x)), int(self.Y(y))
        if 0 <= ix < self.w and 0 <= iy < self.h: self.im.putpixel((ix, iy), f)
    def remap(self, fn):
        a = np.array(self.im)
        for iy in range(self.h):
            for ix in range(self.w):
                if a[iy, ix, 3] > 0:
                    dx = (ix * self.s - self.ax) / self.k; dy = (iy * self.s - self.ay) / self.k
                    r = fn(dx, dy, tuple(a[iy, ix]))
                    if r is not None: a[iy, ix] = r
        self.im = Image.fromarray(a); self.d = ImageDraw.Draw(self.im)
    def outline(self, col=OUTL):
        a = np.array(self.im); m = a[:, :, 3] > 0
        p = np.pad(m, 1)
        n = p[:-2, 1:-1] | p[2:, 1:-1] | p[1:-1, :-2] | p[1:-1, 2:]
        a[n & ~m] = col
        self.im = Image.fromarray(a); self.d = ImageDraw.Draw(self.im)
    def darken(self, k):
        a = np.array(self.im).astype(float); a[:, :, :3] *= k
        self.im = Image.fromarray(a.astype('uint8')); self.d = ImageDraw.Draw(self.im)
    def img(self):
        return self.im.resize((self.w * self.s, self.h * self.s), Image.NEAREST).crop((0, 0, self.W, self.H))

def hsh(x, y):
    n = (x * 374761393 + y * 668265263) & 0xffffffff
    n = ((n ^ (n >> 13)) * 1274126177) & 0xffffffff
    return ((n ^ (n >> 16)) & 0xffff) / 65535.0

def star(g, x, y, r, f=WHITE, f2=None):
    g.rect(x - 1.5, y - r, x + 1.5, y + r, f)
    g.rect(x - r, y - 1.5, x + r, y + 1.5, f)
    if f2: g.px(x, y, f2)

# --------------------------------------------------------------- HEAD (2px cells)
def draw_head(g, cx=101, cy=0):
    s = g.s
    # --- afro (big, glossy, with curl texture)
    SENT = (59, 35, 20, 255)
    g.ell(cx - 60, cy - 6, cx + 60, cy + 86, SENT)
    g.ell(cx - 54, cy + 56, cx - 20, cy + 96, SENT)      # side puffs down by the ears
    g.ell(cx + 20, cy + 56, cx + 54, cy + 96, SENT)
    def hair(x, y, col):
        if col != SENT: return None
        v = math.sin(x * 0.33 + math.sin(y * 0.27) * 1.7) + math.sin(y * 0.41 - x * 0.12) * 0.8 + (hsh(int(x // 2), int(y // 2)) - 0.5) * 1.2
        lit = (cx - x) * 0.012 + (cy + 30 - y) * 0.010           # light from upper-left
        t = v * 0.35 + lit
        if t > 1.05: return HAIR_H
        if t > 0.55: return HAIR_M
        if t < -0.75: return HAIR_D
        return HAIR
    g.remap(hair)
    # --- face
    g.ell(cx - 30, cy + 20, cx + 30, cy + 86, SKIN)
    g.ell(cx + 8, cy + 24, cx + 30, cy + 84, SKIN_S)                      # shadow side
    g.ell(cx + 2, cy + 20, cx + 28, cy + 82, SKIN)                        # re-cover so only a rim of shade stays
    g.ell(cx - 29, cy + 24, cx - 8, cy + 66, SKIN_H)                      # cheek highlight
    g.ell(cx - 24, cy + 28, cx - 3, cy + 64, SKIN)
    # forehead/jaw shade under hair + jaw
    g.ell(cx - 28, cy + 74, cx + 28, cy + 92, SKIN_S)
    g.ell(cx - 26, cy + 70, cx + 26, cy + 88, SKIN)
    # --- sideburns
    g.rect(cx - 30, cy + 38, cx - 25, cy + 64, HAIR_D); g.rect(cx + 25, cy + 38, cx + 30, cy + 64, HAIR_D)
    # --- headband (follows curve of forehead), stripes pink / cream / yellow
    for x in range(cx - 56, cx + 56, 2):
        dx = (x - cx) / 56.0
        top = cy + 20 + round((1 - dx * dx) * -3 + dx * dx * 8)
        g.rect(x, top, x + 2, top + 5, PINK_H)
        g.rect(x, top + 5, x + 2, top + 8, PINK)
        g.rect(x, top + 8, x + 2, top + 10, hx('#fde047'))
        g.rect(x, top + 10, x + 2, top + 13, PINK)
        g.rect(x, top + 13, x + 2, top + 15, PINK_D)
    # ribbon tails (two short tails fluttering behind the head)
    g.poly([(cx + 40, cy + 30), (cx + 58, cy + 36), (cx + 54, cy + 42), (cx + 40, cy + 38)], PINK)
    g.poly([(cx + 40, cy + 34), (cx + 56, cy + 46), (cx + 50, cy + 50), (cx + 40, cy + 42)], PINK_D)
    # --- sunglasses: round lenses (yellow / cyan) with glint + gold-ish frame
    for (lx, lc, lh, ls) in ((cx - 16, hx('#fbbf24'), hx('#fef08a'), hx('#d97706')), (cx + 16, hx('#22d3ee'), hx('#cffafe'), hx('#0369a1'))):
        ly = cy + 54
        g.circ(lx, ly, 14, hx('#2a0f1f'))
        g.circ(lx, ly, 12, lc)
        g.ell(lx - 12, ly + 1, lx + 12, ly + 12, ls)
        g.ell(lx - 12, ly - 12, lx + 12, ly + 7, lc)
        g.ell(lx - 9, ly - 11, lx + 2, ly - 3, lh)
        g.rect(lx - 7, ly - 8, lx - 3, ly - 4, WHITE)
        g.px(lx + 4, ly + 5, lh); g.px(lx + 6, ly + 3, lh)
    g.rect(cx - 4, cy + 51, cx + 4, cy + 56, hx('#2a0f1f'))                # bridge
    g.rect(cx - 33, cy + 51, cx - 28, cy + 55, hx('#2a0f1f')); g.rect(cx + 28, cy + 51, cx + 33, cy + 55, hx('#2a0f1f'))
    # --- nose
    g.rect(cx - 2, cy + 62, cx + 3, cy + 68, SKIN_S); g.px(cx - 4, cy + 69, SKIN_S); g.px(cx + 4, cy + 69, SKIN_S)
    g.rect(cx - 2, cy + 62, cx, cy + 66, SKIN_H)
    # --- cheeks blush
    g.ell(cx - 29, cy + 66, cx - 21, cy + 72, hx('#e8896a')); g.ell(cx + 21, cy + 66, cx + 29, cy + 72, hx('#d9785c'))
    # --- big grin
    my0, my1 = cy + 70, cy + 84
    MOUTH = (74, 13, 31, 255)
    g.ell(cx - 18, my0, cx + 18, my1 + 4, MOUTH)
    # teeth on top half, tongue bottom
    def mouth(x, y, c):
        if c != MOUTH: return None
        if y < cy + 77: return (255, 255, 255, 255) if int(x // 4) % 3 else (226, 232, 240, 255)
        if y >= cy + 80 and abs(x - cx) < 9: return hx('#fb5b7e')
        return None
    g.remap(mouth)
    g.line((cx - 18, my0 + 8), (cx - 12, my0 + 14), hx('#a1554a'), 2)       # lip corner
    g.line((cx + 18, my0 + 8), (cx + 12, my0 + 14), hx('#a1554a'), 2)
    g.rect(cx - 12, my1 + 4, cx + 12, my1 + 7, hx('#b0604f'))             # lower lip
    # moustache (fat 70s) + soul patch
    g.poly([(cx - 22, cy + 70), (cx - 8, cy + 66), (cx, cy + 69), (cx + 8, cy + 66), (cx + 22, cy + 70), (cx + 16, cy + 74), (cx, cy + 71), (cx - 16, cy + 74)], HAIR_D)
    g.rect(cx - 3, cy + 90, cx + 4, cy + 95, HAIR_D)
    # --- ear + gold hoop on the left, sparkle in hair
    g.circ(cx - 33, cy + 66, 5, SKIN_S)
    g.ell(cx - 40, cy + 66, cx - 30, cy + 80, GOLD); g.ell(cx - 38, cy + 68, cx - 32, cy + 78, (0, 0, 0, 0))
    star(g, cx - 38, cy + 14, 6, WHITE)
    star(g, cx + 36, cy + 8, 4, hx('#fbcfe8'))
    g.outline(OUTL)

# --------------------------------------------------------------- TORSO
def draw_torso(g, hi=True):
    s = g.s
    # neck
    g.rect(92, 62, 109, 82, SKIN); g.rect(92, 62, 98, 82, SKIN_H); g.rect(104, 62, 109, 82, SKIN_S)
    # shirt body
    BODY = (162, 28, 175, 255)
    g.poly([(60, 94), (68, 82), (90, 76), (110, 76), (132, 82), (142, 94), (138, 130), (134, 168), (66, 168), (62, 130)], BODY)
    g.circ(66, 94, 13, BODY); g.circ(134, 94, 13, BODY)
    def satin(x, y, c):
        if c != BODY: return None
        t = (x + y * 0.55) % 30
        base = SH
        if x > 122: base = SH_D
        elif x < 76: base = SH_L
        if t < 2: return SH_H if base != SH_D else SH_L
        if t < 5: return SH_L if base == SH else base
        if y > 140: return SH_D if base != SH_L else SH
        return base
    g.remap(satin)
    # chest V opening + chain
    g.poly([(90, 76), (110, 76), (100, 126)], SKIN)
    g.poly([(100, 78), (110, 76), (100, 126)], SKIN_S)
    g.poly([(76, 80), (92, 74), (100, 126), (84, 114), (78, 96)], SH_H)
    g.poly([(124, 80), (108, 74), (100, 126), (116, 114), (122, 96)], SH_L)
    g.poly([(80, 84), (91, 78), (97, 116), (86, 108)], SH_L)
    g.poly([(120, 84), (109, 78), (103, 116), (114, 108)], SH)
    g.line((78, 84), (90, 75), hx('#fdf4ff'), 3); g.line((122, 84), (110, 75), hx('#fdf4ff'), 3)
    # chain & medallion
    for (px_, py_) in ((93, 80), (94, 88), (96, 96), (98, 104), (99, 111), (107, 80), (106, 88), (104, 96), (102, 104), (101, 111)):
        g.rect(px_, py_, px_ + 2, py_ + 3, GOLD if (py_ // 8) % 2 else GOLD_H)
    g.circ(100, 120, 7, GOLD_D); g.circ(100, 120, 5.5, GOLD); g.circ(98, 118, 2.2, GOLD_H)
    star(g, 100, 120, 3, hx('#fff7c2'))
    # sparkles + stitching
    for (sx, sy) in ((80, 130), (121, 120)):
        star(g, sx, sy, 2.5, hx('#fae8ff'))
    g.line((100, 126), (100, 150), SH_X, 2)
    for yy in range(130, 150, 6): g.rect(98, yy, 103, yy + 2, GOLD)
    # belt with gem buckle
    g.rect(64, 150, 136, 168, GOLD_D); g.rect(64, 150, 136, 164, GOLD); g.rect(64, 150, 136, 154, GOLD_H)
    for xx in range(68, 132, 10): g.rect(xx, 158, xx + 3, 161, GOLD_D)
    g.circ(100, 158, 9, GOLD_D); g.circ(100, 158, 7.5, GOLD_H); g.circ(100, 158, 5.5, hx('#ec4899')); g.circ(98, 156, 1.8, hx('#fbcfe8'))
    g.rect(66, 166, 134, 172, PT_S)
    g.outline(OUTL)

# --------------------------------------------------------------- ARMS
def draw_arm_up(g, mirror=False):
    # sleeve capsule from shoulder (64,92) to elbow (52,132); mirrored for front arm
    X = (lambda x: 200 - x) if mirror else (lambda x: x)
    S = (lambda pts: [(X(x), y) for x, y in pts])
    SL = (162, 28, 175, 255)
    g.circ(X(64), 92, 14, SL)
    g.cap((X(64), 92), (X(54), 124), 24, SL)
    g.poly(S([(40, 112), (70, 112), (74, 126), (36, 126)]), SL)               # bell cuff
    def sat(x, y, c):
        if c != SL: return None
        t = (x * (-1 if mirror else 1) + y * 0.6) % 30
        if t < 2: return SH_H
        if t < 5: return SH_L
        return SH if y < 118 else SH_D
    g.remap(sat)
    g.line((X(40), 126), (X(70), 126), hx('#fbcfe8'), 3); g.line((X(38), 124), (X(72), 124), SH_H, 2)
    g.cap((X(53), 126), (X(52), 138), 15, SKIN)
    g.circ(X(64), 88, 4, SH_H)
    g.outline(OUTL)

def draw_arm_fore(g, mirror=False):
    X = (lambda x: 200 - x) if mirror else (lambda x: x)
    g.circ(X(52), 132, 8.5, SKIN)
    g.cap((X(52), 134), (X(50), 160), 16, SKIN)
    g.cap((X(51), 138), (X(49), 156), 7, SKIN_H)
    # gold bangle + sparkle
    g.rect(X(43), 148, X(59), 153, GOLD_D)
    g.rect(X(43), 148, X(59), 151, GOLD)
    g.rect(X(44), 148, X(48), 150, GOLD_H)
    # hand (fist with thumb and knuckle shading)
    g.ell(X(42), 158, X(58), 176, SKIN_S)
    g.ell(X(42), 158, X(57), 173, SKIN)
    g.ell(X(43), 159, X(51), 166, SKIN_H)
    for yy in (165, 169): g.line((X(45), yy), (X(55), yy), SKIN_D, 1)
    g.outline(OUTL)

# --------------------------------------------------------------- LEGS
def draw_thigh(g, hipx, knx, side):
    # side = -1 left (outer stripe on left) / +1 right
    P = (251, 191, 36, 255)
    g.cap((hipx, 160), (knx, 206), 33, P)
    g.rect(hipx - 17, 142, hipx + 17, 164, P)
    def shade(x, y, c):
        if c != P: return None
        rel = (x - (hipx + (knx - hipx) * max(0, min(1, (y - 160) / 46)))) * 1.0
        if rel * side > 10: return PT_S
        if rel * side < -11: return PT_H
        return PT
    g.remap(shade)
    sx = hipx + side * 12 + (knx - hipx) * 0
    g.line((sx, 150), (sx + (knx - hipx) * 0.8, 206), hx('#ec4899'), 3)
    g.line((sx - side * 3, 150), (sx - side * 3 + (knx - hipx) * 0.8, 206), hx('#fbcfe8'), 2)
    g.outline(OUTL)

def draw_shin(g, knx, ftx, side):
    P = (251, 191, 36, 255)
    ky = 208
    # platform shoe (toe points right)
    g.poly([(ftx - 15, 238), (ftx + 6, 238), (ftx + 20, 248), (ftx + 24, 258), (ftx - 17, 258)], hx('#f472b6'))
    g.poly([(ftx - 15, 238), (ftx + 6, 238), (ftx + 12, 243), (ftx - 15, 244)], hx('#f9a8d4'))
    g.poly([(ftx + 8, 246), (ftx + 20, 249), (ftx + 24, 258), (ftx + 6, 258)], PINK_D)
    g.line((ftx - 10, 249), (ftx + 14, 252), GOLD, 2)
    g.rect(ftx - 19, 257, ftx + 27, 264, hx('#fff7fb')); g.rect(ftx - 19, 262, ftx + 27, 266, hx('#c9b8d6'))
    g.rect(ftx - 19, 254, ftx - 9, 265, hx('#fff7fb'))
    # bell-bottom flare
    FL = P
    g.poly([(knx - 16, ky - 4), (knx + 16, ky - 4), (knx + 15, 220), (ftx + 24, 240), (ftx - 24, 240), (knx - 15, 220)], FL)
    def shade(x, y, c):
        if c != FL: return None
        rel = x - ftx
        t = (y - 220) / 20.0
        if rel * side > 9 + t * 8: return PT_S
        if rel * side < -(10 + t * 8): return PT_H
        return PT
    g.remap(shade)
    g.rect(ftx - 25, 234, ftx + 25, 241, hx('#ec4899')); g.rect(ftx - 25, 234, ftx + 25, 236, hx('#f9a8d4'))
    g.line((knx + side * 11, 212), (ftx + side * 15, 234), hx('#ec4899'), 3)
    star(g, ftx - side * 4, 224, 2.5, WHITE)
    g.outline(OUTL)

# --------------------------------------------------------------- RUN
def build_parts(dark_back=0.82):
    P = {}
    g = G(2, k=0.8, ax=19.2, ay=7); draw_head(g); P['head'] = g.img()
    g = G(3); draw_torso(g); P['torso'] = g.img()
    g = G(3); draw_arm_up(g, False); g.darken(dark_back); P['armBu'] = g.img()
    g = G(3); draw_arm_fore(g, False); g.darken(dark_back); P['armBf'] = g.img()
    g = G(3); draw_arm_up(g, True); P['armFu'] = g.img()
    g = G(3); draw_arm_fore(g, True); P['armFf'] = g.img()
    g = G(3); draw_thigh(g, 84, 82, -1); g.darken(dark_back); P['legBt'] = g.img()
    g = G(3); draw_shin(g, 82, 80, -1); g.darken(dark_back); P['legBs'] = g.img()
    g = G(3); draw_thigh(g, 116, 118, 1); P['legFt'] = g.img()
    g = G(3); draw_shin(g, 118, 120, 1); P['legFs'] = g.img()
    return P

def portrait(P):
    # bust: head + shoulders at 2px cells, rendered natively for a crisp card portrait
    g = G(2, 200, 270)
    draw_torso(g)
    t = g.img()
    gh = G(2, 200, 270, k=0.8, ax=19.2, ay=7); draw_head(gh)
    h = gh.img()
    c = Image.new('RGBA', (200, 270), (0, 0, 0, 0))
    c.alpha_composite(t.crop((0, 0, 200, 270)))
    # arms (front/back sleeves) for shoulders
    for k in ('armBu', 'armFu'):
        c.alpha_composite(P[k])
    c.alpha_composite(t)
    c.alpha_composite(h)
    box = c.crop((38, 0, 164, 140))
    box = box.resize((box.width * 2, box.height * 2), Image.NEAREST)
    out = Image.new('RGBA', (256, 256), (0, 0, 0, 0))
    out.alpha_composite(box, ((256 - box.width) // 2, 256 - box.height - 2 if box.height < 256 else 0))
    return out

if __name__ == '__main__':
    P = build_parts()
    for k, im in P.items(): im.save(f'{OUT}/dc_{k}.png')
    portrait(P).save(f'{OUT}/disco.png')
    # preview assembled
    c = Image.new('RGBA', (200, 270), (60, 50, 90, 255))
    for n in ['armBu', 'armBf', 'legBt', 'legBs', 'legFt', 'legFs', 'torso', 'head', 'armFu', 'armFf']:
        c.alpha_composite(P[n])
    c.resize((600, 810), Image.NEAREST).save(f'{OUT}/preview_full.png')
    print('ok')
