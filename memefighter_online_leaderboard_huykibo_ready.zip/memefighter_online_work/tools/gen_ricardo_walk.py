# Dung lai chu ky di bo Ricardo (12 khung) tu chan sach cua _orig/walk_5.png.
# Chay: python3 tools/gen_ricardo_walk.py 12  (can numpy, scipy, pillow) -> sinh frames.pkl + anh xem truoc trong assets/sprites/ricardo/_orig/
# Cac khung walk_0..11.png da duoc xuat san; script nay de tinh chinh dang di neu can.
import numpy as np, math, os, sys
from PIL import Image
from scipy import ndimage as ndi
from scipy.interpolate import CubicSpline

import os
ROOT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','assets','sprites','ricardo')
SRC=ROOT+'/_orig/walk_5.png'
im=Image.open(SRC).convert('RGBA'); a=np.array(im).astype(np.float32)
H0,W0=a.shape[:2]
alpha=a[...,3]; lum=0.299*a[...,0]+0.587*a[...,1]+0.114*a[...,2]
yy,xx=np.mgrid[0:H0,0:W0]
opaque=alpha>110
skin=opaque&(lum>95)&(a[...,0]>a[...,2]+25)

# ---------- leg masks ----------
region=(yy>=99)&(xx>=34)
lab,_=ndi.label(skin&region); leg_skin=lab==lab[125,60]
dil=ndi.binary_dilation(leg_skin,iterations=2)
outline=dil&~leg_skin&(alpha>20)&(lum<110)&region
boot_c=(alpha>20)&(yy>=163)&(xx>=54)&~leg_skin
lab2,n2=ndi.label(boot_c); sz=ndi.sum(boot_c,lab2,range(1,n2+1)); boot=lab2==1+int(np.argmax(sz))
leg=leg_skin|outline|boot

HIP=np.array([47.0,104.0]); KNEE=np.array([63.5,141.0]); ANK=np.array([66.0,169.0])
def ang(v): return math.degrees(math.atan2(v[0],v[1]))   # tu huong 'xuong' quay sang +x
TH0=ang(KNEE-HIP); SH0=ang(ANK-KNEE)
L1=np.linalg.norm(KNEE-HIP); L2=np.linalg.norm(ANK-KNEE)
d1=(KNEE-HIP)/L1
proj=(xx-KNEE[0])*d1[0]+(yy-KNEE[1])*d1[1]
RK=10.5
circ=((xx-KNEE[0])**2+(yy-KNEE[1])**2)<=RK**2
thigh_m=leg&~boot&((proj<0)|circ)
shin_m=leg&~boot&((proj>=0)|circ)&(yy<175)
thigh_m=ndi.binary_opening(thigh_m,structure=np.ones((3,3)))|(thigh_m&(yy<112))
shin_m=ndi.binary_opening(shin_m,structure=np.ones((3,3)))
shin_skin_rows=leg_skin&(yy>=158)&(yy<=167)
def rgba(mask):
    o=np.zeros_like(a); o[mask]=a[mask]; return o
# vien toi quanh hinh bong nguyen goc (chi o canh ngoai that su, khong o cho cat)
OUT=np.array([34,16,10],np.float32)
sil=ndi.binary_erosion(leg,structure=np.array([[0,1,0],[1,1,1],[0,1,0]]),border_value=0)
edge=leg&~sil
def with_outline(arr,mask):
    arr=arr.copy(); e=edge&mask
    l=0.299*arr[...,0]+0.587*arr[...,1]+0.114*arr[...,2]
    t=e&(l>70)
    arr[t,:3]=arr[t,:3]*0.25+OUT*0.75
    return arr
thigh=with_outline(rgba(thigh_m),thigh_m); shin=with_outline(rgba(shin_m),shin_m); bootp=rgba(boot)
# keo dai cang chan xuong (an duoi ung) bang mau da hang cuoi
ys,xs=np.where(leg_skin&(yy>=162)&(yy<=166))
ext=np.zeros_like(a)
for y in range(167,176):
    row=np.where(leg_skin[164])[0]
    x0,x1=row.min()+3,row.max()-3
    ext[y,x0:x1+1]=a[164,x0:x1+1]; ext[y,x0:x1+1,3]=255
shin=np.where(shin[...,3:4]>0,shin,ext)
# goc de cua ung: do doc day ung (toe up am)
bx=np.where(boot.any(0))[0]
bot=[]
for x in range(72,bx.max()-3):
    col=np.where(boot[:,x])[0]
    if len(col): bot.append((x,col.max()))
bot=np.array(bot); slope=np.polyfit(bot[:,0],bot[:,1],1)[0]
P_REST=math.degrees(math.atan(slope))    # >0: mui xuong
print('rest foot pitch (toe-down +)',round(P_REST,1),'TH0',round(TH0,1),'SH0',round(SH0,1),'L',round(L1,1),round(L2,1))

# ---------- upper body (walk_5 tren hong) ----------
keep=np.zeros((H0,W0),bool)
for x in range(W0):
    if x<35: yl=116
    elif x<40: yl=103
    elif x<46: yl=101
    elif x<52: yl=99
    elif x<58: yl=97
    else: yl=96
    keep[:yl+1,x]=True
# xoa vet xam xanh o eo
up=rgba(keep&(alpha>0))
bar=(xx>=27)&(xx<=33)&(yy>=66)&(yy<=88)&keep&(a[...,1]>=a[...,0]-8)&(alpha>0)
up[bar]=[30,14,10,255]
upper=up
# --- tay: cang tay gan (truoc than) va cang tay xa (sau than) quay quanh khuyu ---
E_N=np.array([20.0,80.0]); E_F=np.array([62.0,73.0])
ke=keep&(alpha>0)
nf=ke&(yy>=80)&(((yy<98)&(xx<=27))|((yy>=98)&(xx<=35)))
cap_n=ke&(((xx-E_N[0])**2+(yy-E_N[1])**2)<=9.5**2)&(xx<=28)
ff=ke&(xx>=61)&(yy>=66)&(yy<=99)
near_fore=rgba(nf|cap_n)
far_fore=rgba(ff)
# keo dai dau trong cua cang tay xa ve ben trai (bi than che)
for y in range(66,100):
    row=np.where(ff[y])[0]
    if len(row) and row.min()<=64 and y<=86:
        x0=row.min()
        for x in range(x0-12,x0):
            far_fore[y,x]=far_fore[y,x0]; far_fore[y,x,3]=255
torso=rgba(ke&~nf&~ff)
torso[bar]=[30,14,10,255]

# ---------- gait ----------
def per(pts):
    u=np.array([p[0] for p in pts]); v=np.array([p[1] for p in pts]); return CubicSpline(u,v,bc_type='periodic')
THIGH=per([(0,30),(0.12,22),(0.3,4),(0.5,-16),(0.58,-24),(0.7,-8),(0.85,18),(1.0,30)])
KNEEF=per([(0,5),(0.1,14),(0.3,9),(0.45,8),(0.55,30),(0.65,54),(0.73,62),(0.85,34),(0.95,10),(1.0,5)])
PITCH=per([(0,-14),(0.08,0),(0.42,0),(0.55,28),(0.65,32),(0.75,18),(0.88,-2),(1.0,-14)])

CW,CH=240,250; GROUND=232; HX=120
def place(part,pivot,rot,dst):
    r=math.radians(rot); c,s=math.cos(r),math.sin(r)
    # inverse map: p = R^-1 (p' - dst) + pivot
    A=np.array([[c,s],[-s,c]])   # R^-1 (R=[[c,-s],[s,c]])
    off=np.array(pivot)-A@np.array(dst)
    img=Image.fromarray(part.astype(np.uint8))
    return img.transform((CW,CH),Image.AFFINE,(A[0,0],A[0,1],off[0],A[1,0],A[1,1],off[1]),resample=Image.BICUBIC)
def leg_img(u,hip,tint=1.0):
    th=float(THIGH(u%1)); kf=float(KNEEF(u%1)); pt=float(PITCH(u%1))
    knee=hip+L1*np.array([math.sin(math.radians(th)),math.cos(math.radians(th))])
    psi=th-kf
    ank=knee+L2*np.array([math.sin(math.radians(psi)),math.cos(math.radians(psi))])
    out=Image.new('RGBA',(CW,CH),(0,0,0,0))
    for part,piv,rot,dst in ((thigh,HIP,TH0-th,hip),(shin,KNEE,SH0-psi,knee),(bootp,ANK,pt-P_REST,ank)):
        out.alpha_composite(place(part,piv,rot,dst))
    if tint!=1.0:
        arr=np.array(out).astype(np.float32); arr[...,:3]*=tint; out=Image.fromarray(arr.astype(np.uint8))
    return out
def lowest(img):
    al=np.array(img)[...,3]>100; r=np.where(al.any(1))[0]; return r.max()
def frame(u,sway=0.0,arm=0.0):
    hip0=np.array([HX,0.0])
    near=leg_img(u,hip0+np.array([0,100.0])); far=leg_img(u+0.5,hip0+np.array([-3,100.0]),0.80)
    # chieu cao hong: cho chan thap nhat cham dat
    low=max(lowest(near),lowest(far))
    dy=GROUND-low
    hip=np.array([HX,100.0+dy])
    far=leg_img(u+0.5,hip+np.array([-3,0]),0.80); near=leg_img(u,hip)
    out=Image.new('RGBA',(CW,CH),(0,0,0,0))
    out.alpha_composite(far); out.alpha_composite(near)
    out.alpha_composite(place(far_fore,E_F,sway+(-arm*0.9),hip+(E_F-HIP)))   # cang tay xa (sau than)
    out.alpha_composite(place(torso,HIP,sway,hip))
    # cang tay gan: quay quanh khuyu, di theo than
    r=math.radians(sway); c,sn=math.cos(r),math.sin(r)
    en=hip+np.array([[c,-sn],[sn,c]])@(E_N-HIP)
    out.alpha_composite(place(near_fore,E_N,sway+arm*1.1,en))
    return out,hip
if __name__=='__main__':
    N=int(sys.argv[1]) if len(sys.argv)>1 else 8
    frames=[]
    for i in range(N):
        u=i/N
        # lac than nhe: nghieng nhe theo nhip, hai lan moi chu ky
        sway=1.2*math.sin(2*math.pi*u*2+0.6)
        arm=16*math.cos(2*math.pi*u)
        f,hip=frame(u,sway,arm); frames.append(f)
    # contact sheet
    sheet=Image.new('RGBA',(N*CW//1,CH),(90,140,90,255))
    for i,f in enumerate(frames): sheet.alpha_composite(f,(i*CW,0))
    sheet.save(os.path.join(ROOT,'_orig','new_walk_sheet_preview.png'))
    import pickle; pickle.dump([np.array(f) for f in frames],open(os.path.join(ROOT,'_orig','frames.pkl'),'wb'))
    print('ok',N)
