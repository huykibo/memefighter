import math, json, numpy as np
from PIL import Image
from scipy.interpolate import CubicSpline
ns={}
exec(open('gen.py').read().split("if __name__")[0],ns)
per=ns['per']
ns['THIGH']=per([(0,32),(0.15,18),(0.3,-5),(0.45,-28),(0.6,5),(0.75,48),(0.9,42),(1.0,32)])
ns['KNEEF']=per([(0,25),(0.15,38),(0.3,25),(0.45,12),(0.55,60),(0.65,105),(0.75,95),(0.9,55),(1.0,25)])
ns['PITCH']=per([(0,-5),(0.15,0),(0.35,4),(0.5,35),(0.65,50),(0.8,40),(0.92,15),(1.0,-5)])
leg_img=ns['leg_img']; place=ns['place']; lowest=ns['lowest']
CW,CH,GROUND,HX=ns['CW'],ns['CH'],ns['GROUND'],ns['HX']
HIP=ns['HIP']; E_N=ns['E_N']; E_F=ns['E_F']
def lift(u):
    for a,b in ((0.38,0.5),(0.88,1.0)):
        if a<=u<b: return 8*math.sin(math.pi*(u-a)/(b-a))
    return 0
def frame(u):
    lean=11+2*math.sin(2*math.pi*2*u); arm=28*math.cos(2*math.pi*u)
    base=np.array([HX,100.0])
    near=leg_img(u,base); far=leg_img(u+0.5,base+np.array([-3,0]),0.80)
    low=max(lowest(near),lowest(far)); dy=GROUND-low-lift(u)
    hip=np.array([HX,100.0+dy])
    out=Image.new('RGBA',(CW,CH),(0,0,0,0))
    out.alpha_composite(leg_img(u+0.5,hip+np.array([-3,0]),0.80)); out.alpha_composite(leg_img(u,hip))
    out.alpha_composite(place(ns['far_fore'],E_F,lean-arm*0.9,hip+(E_F-HIP)))
    out.alpha_composite(place(ns['torso'],HIP,lean,hip))
    r=math.radians(lean); c,s=math.cos(r),math.sin(r)
    en=hip+np.array([[c,-s],[s,c]])@(E_N-HIP)
    out.alpha_composite(place(ns['near_fore'],E_N,lean+arm*1.1,en))
    return np.array(out)
N=12
fr=[frame(i/N) for i in range(N)]
bb=np.array([(lambda ys,xs:(xs.min(),ys.min(),xs.max(),ys.max()))(*np.where(f[...,3]>20)[::-1][::-1]) for f in fr])
