# RICARDO MILOS — MEME FIGHTER (bản nâng cấp)

Game hành động 2D bằng HTML5 Canvas + JavaScript thuần. **Không cần cài đặt hay build**: mở `index.html` bằng Chrome / Edge / Firefox là chơi được.
(Một số trình duyệt chặn đọc file nhạc khi mở trực tiếp bằng `file://`; nếu vậy chạy `python3 -m http.server` trong thư mục này rồi vào http://localhost:8000.)

## 1. Cài đặt nhạc

- Nhạc nền chính: `assets/music/Multifandom_Dancin.mp3` (bài bạn cung cấp), phát liên tục từ sảnh chờ vào trận, qua menu / cài đặt / pause / chuyển màn, **không phát lại từ đầu** và chỉ có **một** phần tử audio duy nhất.
- Thêm bài khác: bỏ file `.mp3 / .ogg / .wav / .m4a` vào `assets/music/`, rồi chạy `update_lists.bat` (Windows) hoặc `./update_lists.sh` (Mac / Linux) hoặc `python3 update_lists.py`. Mở lại game, vào **Cài đặt nhạc & âm thanh** để chọn bài cho sảnh / trận.
- Không muốn chạy script: trong Cài đặt bấm **THÊM NHẠC TỪ MÁY...** (chỉ có tác dụng trong phiên chơi đó).
- Cài đặt có: bật/tắt nhạc, thanh âm lượng nhạc, chọn bài sảnh / trận, bật/tắt và âm lượng hiệu ứng. Tất cả lưu bằng `localStorage`.
- Trình duyệt chặn tự phát âm thanh nên nhạc bắt đầu ở **lần click hoặc nhấn phím đầu tiên**.
- Nhạc tự hạ âm lượng trong đoạn cinematic (phim cốt truyện, ultimate) rồi trả lại. Phím `N` đổi bài, `M` bật/tắt nhạc.
- Thiếu hoặc lỗi file mp3 → tự dùng nhạc chiptune dự phòng và báo nhẹ, game không crash.

## 2. Điều khiển

| Phím | Chức năng |
|---|---|
| ← → | Di chuyển · nhấn đúp + giữ = chạy nhanh |
| ↑ / Space | Nhảy · nhấn lần 2 khi đang trên không = **NHẢY ĐÔI** |
| **K (giữ)** hoặc ↓ | **ĐỠ ĐÒN**: giảm 80% sát thương, đỡ từ phía trước |
| Shift + ← / → | Lướt nhanh |
| **Z / X / C** | Đấm nhẹ / **đấm mạnh** / đá. Nối phím để tung combo tối đa 4 đòn |
| **A** | **DACNE** — nhảy meme hồi 36 HP · 14s · 20 MP |
| **S** | **THRUST** — lao tới, 28 sát thương + choáng · 7s · 15 MP |
| **D** | **SHOCKWAVE** — nhảy xoay đập xuống, sóng xung kích · 10s · 25 MP |
| **F** | **ETERNAL DANCE** — ultimate điện ảnh · 45s · 100 MP |
| Esc | Tạm dừng · đóng menu |
| F1 hoặc `?` | Hướng dẫn |

> **Bố cục phím (v22):** di chuyển bằng mũi tên, đánh Z X C, kỹ năng A S D F. Các phím cũ (WASD, J H L, U I O P) không còn tác dụng trong trận. Chữ J/H/L/U/I/O/P trong phần combo bên dưới tương ứng Z/X/C/A/S/D/F.

**Block / Perfect Block:** nhấn K đúng lúc ngay trước khi đòn trúng (trong 0,2 giây đầu sau khi giơ đỡ) = *Perfect Block*: không mất máu, đối thủ bị choáng, +MP, và đòn kế tiếp của bạn gây x1,6 sát thương (*COUNTER*). Đòn xuyên giáp (một số đòn của boss) chỉ giảm 40% và phá thế đỡ. Bị đánh từ phía sau thì không đỡ được.

**Đánh trúng:** hit-stop ngắn, kẻ địch rung + nháy trắng, vòng sáng / tia / chữ comic, số sát thương nổi, đẩy lùi theo loại đòn, rung màn hình nhẹ, âm thanh riêng cho đòn thường / nặng / kỹ năng / đỡ / Perfect. Đòn đánh trượt có tiếng gió nhẹ và chữ MISS.

## 3. Chuột

Mọi nút (Sảnh, **Chọn nhân vật**, Cài đặt, Hướng dẫn, Pause, Game Over, Victory) đều click được, có trạng thái hover / nhấn / vô hiệu, và vẫn điều hướng được bằng bàn phím (↑↓ chọn, Enter xác nhận, Esc đóng). Pause dừng hẳn logic game và tiếp tục đúng trạng thái cũ khi Tiếp tục. Menu luôn chặn click xuyên qua lớp bên dưới.

## 4. Nhân vật

- **Ricardo Milos**: vẽ bằng *khung xương 2D* (thân, đầu, 2 tay 2 khúc, 2 chân 2 khúc, giày) dùng IK nên chân luôn chạm đất, không bao giờ mất chân. Đầu lấy từ ảnh sticker bạn gửi. Có animation riêng cho idle, dance, run, jump, double jump (lộn người), punch, kick, dash, block, perfect block, hit, stun, ultimate, victory.
- **Quái meme** (mỗi loại có thân vẽ riêng, đầu từ ảnh bạn gửi hoặc tự vẽ):
  - **Trollface** — chế giễu (né sạch đòn rồi phản công), dịch chuyển ra sau lưng, ném vỏ chuối làm bạn trượt ngã.
  - **Gigachad** — cận chiến nặng, giáp (đòn nhẹ −50%), gồng cơ (−80%, không choáng), đấm giáng, dậm đất tạo sóng.
  - **Doge** (Swole Doge) — rất nhanh, **né đòn** rồi phản công, cào liên hoàn, zoomies.
  - **NPC Wojak** — khó đoán: tát, dậm, ném bong bóng COPE, lao SEETHE, đứng đờ và giả vờ ra đòn.
  - **Dancing Meme** (v25 vẽ lại + thiết kế lại kỹ năng) — vũ công disco đánh theo nhịp 128 BPM, vòng sáng dưới chân đổi màu theo từng phách. Kỹ năng: *Moonwalk Groove* (bước/lùi theo phách), *Fever Spin* (nhảy xoay 360°, tiếp đất tạo 2 sóng sáng sát đất), *Note Barrage* (nốt nhạc lượn sóng), *Spotlight Drop* (đèn sân khấu khoá vị trí, vòng sáng đếm ngược rồi cột sáng giáng xuống), *Disco Fever* (dưới 40% máu: nhanh hơn, 5 nốt, 3 cột đèn).
  - **Sigma Meme** — tinh nhuệ: khoanh tay *guard* bắt đòn thường rồi phản công; đòn mạnh (H) và kỹ năng phá được guard; dưới 40% máu nổi điên.
  - **Ultimate Meme Lord** (boss) — 3 giai đoạn: quả cầu meme + đập · sóng đất xuyên giáp + triệu hồi · dịch chuyển + laser quét ngang.
- Mỗi quái có tên + thanh máu trên đầu; HUD hiển thị mục tiêu gần nhất / boss.
- Menu **Chọn nhân vật** cho xem thông tin và kỹ năng của cả 8 nhân vật (hiện chỉ Ricardo chơi được; đối thủ ở trạng thái vô hiệu để xem).

## 5. Cốt truyện

Giữ nguyên: phim mở đầu, 4 chương = 4 màn, hội thoại, **THE ETERNAL DANCE** tự kích hoạt khi sắp gục trước boss (buff 20 giây), phim kết. Cảnh phim đã chuyển sang vẽ bằng nhân vật mới. Lời thoại nằm trong `STORY` ở `game.js`.

## 6. Cấu trúc mã (`game.js`, chia vùng rõ ràng)

| Vùng | Nội dung |
|---|---|
| `Heads`, `Rig`, `DogePuppet`, `RPOSE` | Ảnh đầu, khung xương + IK, tư thế |
| `FxSystem` | Vòng năng lượng, tia, chữ comic, sóng xung kích |
| `Player` | Di chuyển, Block, Double Jump, 4 kỹ năng, combo |
| `Enemy` + 7 lớp quái, `EnemyManager`, `EnemyProjectile` | AI, đòn, đạn |
| `CombatSystem` | Hitbox, hit-stop, sóng, đỡ / Perfect |
| `AudioManager` | SFX tổng hợp, nhạc nền (một audio duy nhất), cài đặt |
| `UIManager` | HUD, nút bấm, chọn nhân vật, cài đặt, pause |
| `CutsceneManager`, `STORY` | Phim cốt truyện |
| `GameEngine` | Vòng lặp, chế độ chơi, chuột / phím |

Ảnh đầu nằm trong `assets/heads/` (thiếu file thì dùng hình dự phòng). Hệ thống chỉ có **một** vòng lặp game (`requestAnimationFrame`) và hai trình nghe phím (một lưu trạng thái phím, một xử lý menu).

## 5. Hình ảnh & animation Ricardo (sprite sheet mới)

Ricardo giờ được vẽ bằng **khung hình pixel-art** cắt từ sprite sheet mới (thay cho bộ "rối xương" cũ):

| Trạng thái | Khung dùng (`assets/sprites/ricardo/`) |
|---|---|
| Đứng yên | `idle_0..3` (lặp 5 khung/giây) |
| Đi / chạy nhanh (nhấn đúp ← →) | `walk_0..11` / `sprint_0..11` (v27 dựng lại; `run_2`/`run_3` vẫn dùng cho đòn đá) (tốc độ theo quãng đường chạy) |
| Nhảy / nhảy đôi / tiếp đất | `jump_0` (nén) · `jump_1` (trên không, nhảy đôi thì lộn vòng) · `jump_2` (tiếp đất) |
| Đấm (J / H) | `attack_0..3` theo từng nhịp của combo |
| Đá (L) | chưa có khung đá trong sheet → tạm dùng `run_2` / `run_3` (gối co) + `attack_*` |
| Đỡ đòn (K) | `attack_0` (hai tay giơ) |
| Bị đánh / choáng | `hurt_0..2` · ngã xuống = `hurt_0` xoay ngửa |
| DACNE (U) | `skill_0` + nhảy theo nhịp, lật hướng mỗi nhịp |
| THRUST (I) | `attack_0` → `skill_2` (lao tới có vệt gió) → `attack_3` |
| SHOCKWAVE (O) | `jump_0` → `jump_1` xoay → `jump_2` |
| ETERNAL DANCE (P) | `skill_1` (hào quang vàng) + nhịp nhảy, kết thúc `attack_1` |
| Lướt (Shift) | `skill_2` + hậu ảnh |

- Chân dung HUD / menu: `assets/heads/ricardo.png` (cắt từ chân dung trong sheet).
- Ảnh FX trong sheet (`fx_slash.png`, `fx_burst.png`, `fx_boom.png`) và ảnh đứng lớn (`full.png`) đã được cắt sẵn trong thư mục sprite, chưa gắn vào game.
- **Muốn thay khung nào**: ghi đè file PNG cùng tên. Điểm neo (giữa hông, đáy ủng) nằm trong `assets/sprites/ricardo_meta.js` (`ax`, `ay`, tính theo pixel ảnh). Đổi kích thước nhân vật: sửa `RicardoSprite.U` trong `game.js`.
- Thiếu thư mục sprite thì game tự quay về nhân vật rối xương cũ, không crash.

## 7. Gigachad dạng sprite (khung hình) — giống Ricardo

Gigachad (`ChadEnemy`) không còn dùng "rối xương" mà dùng **khung hình pixel-art** cắt từ sprite sheet mới, cùng cơ chế với Ricardo:

| Trạng thái | Khung dùng (`assets/sprites/chad/`) |
|---|---|
| Đứng yên | `idle_0..2` (vòng 0-1-2-1) |
| Đuổi theo | `walk_0..3`; nếu vận tốc > 170 thì `run_0..2` |
| Gồng tay báo đòn (`windup`) | `attack_0` (ngả người nhẹ ra sau) |
| Đấm giáng (`gigaPunch`) | `attack_1` (có vệt gió) → thu thế `attack_2` |
| Nhảy đập đất (`pound`) | `jump_0` nén gối → `jump_1` / `jump_2` trên không → `jump_3` tiếp đất + bụi `fx_boom` |
| Gồng cơ "YES." (`flex`) | `skill_0` → `skill_1` (hào quang) |
| Bị đánh | `hurt_0` → `hurt_1` → `hurt_2`; chết = `hurt_0` ngã ngửa |

- Toạ độ neo (giữa hông / đáy bàn chân) nằm trong `assets/sprites/chad_meta.js` (`CHAD_SPRITE_META`); mã vẽ là `ChadSprite` trong `game.js` (dùng chung `render()` với `RicardoSprite`).
- Muốn đổi kích thước: chỉnh `ChadSprite.U` (mặc định 0.9) hoặc `scale` trong `ChadEnemy`.
- Thiếu file ảnh thì game tự quay về khung xương cũ, không crash.
- Ảnh đầu / chân dung HUD của Gigachad (`assets/heads/chad.png`) cũng đã đổi sang chân dung mới.

## 8. Sửa lỗi đứng hình ở cảnh kết (v19)

- **Nguyên nhân:** cảnh kết (và hội thoại chương 4) có nhân vật **THE DELETER** nhưng hàm vẽ `CutsceneManager._deleter` chưa được viết -> `TypeError` -> vòng lặp `requestAnimationFrame` dừng hẳn -> màn hình đứng sau khi hạ boss.
- **Đã sửa:** viết `_deleter` (áo choàng đen, đầu là phím **DEL**, nhiễu glitch đỏ); `loop()` giờ có `try/catch` + `finally` luôn đặt khung kế tiếp, nên một lỗi vẽ sau này chỉ ghi `console.error` chứ không làm đứng cả game.

## 9. Ultimate Meme Lord = Trollface cơ bắp (sprite mới)

Boss **Ultimate Meme Lord** (cùng hình trong menu / cutscene / chân dung HUD) dùng nhân vật Trollface áo choàng đỏ dạng khung hình pixel-art: `assets/sprites/lord/`, meta `assets/sprites/lord_meta.js`, mã `LordSprite` + `MemeLord._sprite()` trong `game.js`.
Khung: idle_0-4, walk_0-5, run_0-3, jump_0-3, attack_0-2, hurt_0-2, skill_0-2 (niệm phép / cầu ma thuật / lao tới), FX fx_slash, fx_beam, fx_circle, fx_pillar, fx_burst. Ghi đè PNG cùng tên để đổi khung; kích thước chỉnh `LordSprite.U`.

### Hoạt ảnh mượt của Meme Lord (v23)
- Mọi khung được hòa trộn (cross-fade) sang khung kế tiếp; bước chân đi/chạy tính theo **quãng đường đã đi** nên không còn đơ hay trượt chân.
- Vào đòn / ra đòn / niệm phép / laser đều chuyển tiếp mượt giữa các khung (idle → gồng → đấm → thu thế → idle).
- Đã dọn thêm mảnh pixel thừa ở các khung đi và chạy (`assets/sprites/lord/`).


## 10. v26 — Skill Trollface pixel-art, boss phase 3 khó hơn, hồi sinh Eternal Dance, cổng dịch chuyển

Mã mới nằm trong `pixelfx.js` (nạp trước `game.js`, không cần ảnh ngoài — mọi sprite được dựng bằng code rồi phóng to không làm mịn).

**Skill Trollface vẽ lại bằng pixel-art**
- Trollface thường: vỏ chuối pixel (xoay khi bay, nằm yên lấp lánh + dấu `!`), vệt chém pixel cho slap / kick / counter, chế giễu có icon mặt Troll + chữ `PROBLEM?`, dịch chuyển tan thành điểm ảnh rồi hút lại + vòng rune.
- Ultimate Meme Lord: cầu meme (đầu meme pixel hoá trong đĩa năng lượng), sóng đất dạng gai tinh thể, laser ô vuông nhiều lớp, trận pháp rune + cột sáng pixel, hậu ảnh khi lao.

**Boss cuối — Phase 3 "TROLL OVERDRIVE"** (kỹ năng spam dày, hồi chiêu ~0,3 lần phase 1, không dùng lặp một chiêu hai lần liên tiếp)
- *Meteor Rain*: 14 thiên thạch đầu meme rơi, có dấu X cảnh báo 0,7 s.
- *Troll Pillars*: 4 đợt cột lửa nổ dưới chân (vòng rune báo trước), mỗi đợt rộng hơn.
- *Fan Barrage*: 4 đợt đạn toả quạt 6–7 viên.
- *Troll Rush*: gồng rồi lao xuyên màn hình (xuyên giáp).
- *Laser 3 loạt*: cao – thấp – cao (loạt thấp phải nhảy qua).
- Đập đất tạo 4 sóng (2 tốc độ), cầu meme hồi lại nhanh, dịch chuyển thường xuyên, đi nhanh hơn.
- Dưới 12% máu: **OVERDRIVE** — nhanh hơn, hồi chiêu ngắn hơn, 18 thiên thạch, 5 đợt đạn quạt.

**Hồi sinh bằng ETERNAL DANCE (đúng 1 lần mỗi lượt chơi)**
- Khi Ricardo chết lần đầu (mọi chế độ: Story / Arcade / Survival) game tự phát cảnh Eternal Dance, hồi 85% máu, đầy MP, buff 20 s, nổ năng lượng vàng gây sát thương + choáng kẻ địch quanh đó và xoá đạn.
- Chết lần hai thì Game Over. Chơi lại / bắt đầu mới thì được hồi sinh lại 1 lần. (Điểm kích hoạt cũ ở 25% máu trước boss đã được thay bằng cơ chế này.)

**Cổng dịch chuyển sau mỗi màn (Story)**
- Dọn sạch wave cuối của màn → cổng mở ra phía trước nhân vật: vòng rune dưới đất, cột sáng, khung đá trồi lên, xoáy năng lượng mở rộng, rung màn hình + chớp sáng. Cổng có màu theo màn kế (rừng xanh / dung nham cam / quỷ tím) và tên màn đích.
- Đi vào cổng: Ricardo bị hút xoay tròn, màn hình trắng xoá rồi sang màn kế. Cổng nằm ngoài màn hình sẽ có mũi tên chỉ hướng.

## v28 — Hiệu ứng "Ricardo giáng thế" khi vào màn mới
Sau khi qua cổng dịch chuyển (và xem xong phim chương), màn mới mở ra bằng cảnh ra mắt (~2.5 giây):
1. **Báo hiệu**: màn hình tối dần, cột sáng vàng từ trời giáng xuống kèm vòng rune dưới đất, mặt đất rung.
2. **Lao xuống**: Ricardo lao từ trên trời như sao băng, có đuôi sáng + vạch tốc độ + ngọn lửa khí tức.
3. **Chạm đất**: chớp trắng, hit-stop, rung màn hình, chữ BOOM!, sóng xung kích + mảnh đá văng; sóng đẩy lùi/choáng quái xung quanh; tên màn hiện ra ngay lúc này.
4. **Gồng khí tức**: 3 nhịp xung năng lượng hút về thân, hào quang + tia sáng xoay.
5. **AURA BREAK!!**: khí tức bùng nổ (vòng sáng 3 màu, cột sáng, sóng đẩy), rồi trả quyền điều khiển (hào quang còn ~2 giây).
Chỉnh thời gian/độ mạnh trong `game.js`: các hàm `_startEntrance`, `_updateEntrance`, `_entranceImpact`, `_entranceBurst`, `_drawEntranceBack`.

## v29 — Hiệu ứng đấm/đá của Ricardo chuyển sang PIXEL
- **Vệt đòn** (`Player._drawEffects` + `PXFX.drawSwing / drawThrust`): đòn nhẹ (JAB, CROSS...) = vạch gió pixel + tia lửa đầu nắm đấm; đòn nặng/đá = trăng khuyết ô vuông 3px 4 tông màu, đuôi tan kiểu dither, đòn mạnh có thêm vệt trắng phụ; đòn hất (UPPERCUT, DRAGON KICK) quét từ dưới lên; đòn xoay (TORNADO, BRAZILIAN FINISH) = vòng elip pixel.
- **Trúng đòn** (`PixelFx.punchHit`): tia nổ 8 hướng + lõi hình thoi, vòng điểm ảnh, mảnh vỡ bay theo hướng đánh, chữ POW!/BAM! phông pixel. 3 cấp: nhẹ / nặng / finisher.
- Hạt tia lửa (`spark`) giờ là ô vuông bám lưới 3px.

## v30 — ULTIMATE (ETERNAL DANCE) vẽ lại bằng PIXEL
- **Nhảy rồi đáp**: mỗi đợt trong 5 đợt sóng, Ricardo nhảy lên rồi đáp xuống; sóng nổ ra đúng lúc chạm đất. Đòn kết thúc nhảy cao hơn.
- **Sóng xung kích** (`PXFX.drawShockWave`): vẽ theo đúng bán kính sóng đang gây sát thương — vành elip sát đất (2 vòng), 2 bức tường lửa pixel ở mép sóng, vòng hào quang quanh thân. Đòn kết thúc to hơn, 3 vành, màu trắng-vàng-hồng.
- **Gồng khí tức**: ngọn lửa pixel + tia sáng xoay quanh người trong suốt chiêu; lúc nạp có hạt năng lượng hút về thân; trận pháp pixel dưới chân.
- Mỗi lần đáp có tia lửa vuông, cột sáng, đá vỡ; đòn kết có tia nổ pixel, vòng điểm ảnh, cột sáng khổng lồ.

## v31 — Ultimate: đứng yên một chỗ + chỉ nhảy; bỏ cột sáng giữa

## v32 — Ultimate: đứng yên một chỗ nhảy điệu DACNE (không nhảy lên), sóng pixel gây sát thương mạnh hơn (16 -> 26/đợt), mỗi nhịp có vòng sóng pixel dưới chân; không có cột sáng giữa.

## 10. Độ khó & tiến trình kỹ năng theo tầng (bản nâng cấp)

Trước khi vào Story / Arcade / Survival, người chơi chọn một trong ba mức:

- **Easy:** quái có 78% máu, 72% sát thương, 84% tốc độ; AI dùng kỹ năng ít hơn, thời gian cảnh báo dài hơn và hồi chiêu lâu hơn.
- **Normal:** chỉ số và nhịp chiến đấu mặc định.
- **Hard:** quái có 130% máu, 124% sát thương, 116% tốc độ; AI chủ động hơn, hồi chiêu ngắn hơn và có thể trộn các kỹ năng đã mở khóa.

Lựa chọn được lưu trong `localStorage` với khóa `ricardoDifficulty` và được chọn sẵn ở lần chơi sau.

### Các tầng và kỹ năng mới

| Tầng | Kỹ năng mở khóa | Cách đối phó |
|---|---|---|
| 1 | Basic Attack | Canh đỡ đòn / phản công |
| 2 | Dash Breaker | Nhảy qua hoặc lướt né |
| 3 | Pixel Shockwave | Nhảy qua sóng gai sát đất |
| 4 | Energy Orb | Di chuyển ngang hoặc đỡ đúng nhịp |
| 5 | Rune Strike | Rời khỏi vòng rune cảnh báo |
| 6 | Triple Volley | Lách khe đạn hoặc áp sát |
| 7 | Afterimage Feint | Chờ cú lao và sóng bồi kết thúc |
| 8 | Ground Snare | Quan sát bẫy trên mặt đất, đổi vị trí |
| 9 | Meteor Mark | Rời khỏi dấu ngắm trước khi thiên thạch rơi |
| 10 | Hellfire Grid | Đọc chuỗi vòng rune, tìm vùng an toàn |

Mỗi tầng mới hiển thị bảng pixel thông báo tên kỹ năng, mô tả và gợi ý né tránh; âm thanh mở khóa được phát qua AudioManager. Kỹ năng dùng chung hệ thống projectile / hitbox hiện có, có thời gian telegraph, thời gian hồi chiêu và hiệu ứng pixel từ `pixelfx.js`. Story quy đổi 3 wave mỗi chương thành các tầng 1–9, màn boss là tầng 10; Survival và Arcade tăng tầng theo wave / round.

## MEMEFIGHTER Online Leaderboard (nickname-only guest mode)

This build includes an online leaderboard integration using Supabase. Players choose a nickname once in the browser; the game creates a guest UUID and remembers it in localStorage. No email/password is required.

### 1. Create the Supabase database

1. Create a project at https://supabase.com/.
2. Open **SQL Editor** in the Supabase dashboard.
3. Open `supabase-schema.sql`, copy all SQL, and run it.
4. In **Project Settings → API**, copy the Project URL and the `anon` / publishable public key.

### 2. Configure the game

Open `supabase-config.js` and replace:

- `YOUR_SUPABASE_PROJECT_URL` with the Project URL.
- `YOUR_SUPABASE_ANON_PUBLIC_KEY` with the anon/public key.

Do not use the `service_role` secret key in browser code.

### 3. Deploy

Upload the entire game folder (including `leaderboard.js`, `supabase-config.js`, `supabase-schema.sql`, `assets/`, `game.js`, and `index.html`) to Cloudflare Pages, Netlify, or another static host. The game can still run locally before Supabase is configured, but online scores will not be submitted until the URL and public key are set.

### Guest leaderboard behavior

- The first time a player starts a run, a nickname dialog appears.
- Nickname and guest UUID are saved in that browser's localStorage.
- Results are submitted once when a run ends (Game Over or Victory).
- Each record includes nickname, difficulty, game mode, score, highest floor, kills, max combo, duration, outcome, and timestamp.
- The lobby has a **BẢNG XẾP HẠNG ONLINE** entry with All / Easy / Normal / Hard filters.

### Important security note

Nickname-only guest mode cannot prove a player's identity or fully prevent forged scores because the browser is not a trusted environment. The SQL enables public read/insert and blocks public update/delete, with basic field constraints. For a competitive public release, add server-side score validation (for example, a Supabase Edge Function with rate limits and gameplay validation) before treating leaderboard scores as cheat-proof.


## 11. MEMEFIGHTER online leaderboard deployment

- Public website origin: `https://memefighter.is-best.net`
- Supabase publishable key has been inserted into `supabase-config.js`.
- **Still required:** replace `YOUR_SUPABASE_PROJECT_URL` with the Project URL from Supabase Dashboard → Project Settings → API. The website domain is not the Supabase Project URL.
- Run `supabase-schema.sql` in the Supabase SQL Editor before testing leaderboard reads/writes.
- Keep only the publishable/anon key in browser code. Never put a `service_role` or secret key in this folder.
