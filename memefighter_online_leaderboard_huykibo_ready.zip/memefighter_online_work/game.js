/* ============================================================
   RICARDO MILOS: MEME FIGHTER - Complete Game
   A 2D side-scrolling arcade fighting game
   Built with HTML5 Canvas + JavaScript ES6+
   ============================================================ */
(() => {
'use strict';

// ============================================================
// CONSTANTS
// ============================================================
const W = 1280, H = 720;
const GRAVITY = 1400;
const MAX_DT = 0.033;
const GROUND_Y = 560;

// ============================================================
// UTILITIES
// ============================================================
const lerp = (a, b, t) => a + (b - a) * t;
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const rand = (a, b) => a + Math.random() * (b - a);
const randInt = (a, b) => Math.floor(rand(a, b + 1));
const dist = (x1, y1, x2, y2) => Math.hypot(x2 - x1, y2 - y1);
const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
const easeOut = t => t * (2 - t);
const easeIn = t => t * t;
// Hiệu ứng pixel-art (pixelfx.js) — nạp trước game.js
const PXFX = window.PXFX;
const pfx = () => (PXFX && PXFX.fx) || null;

function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
}

// ============================================================
// INPUT MANAGER
// ============================================================
// Chuẩn hóa phím theo vị trí vật lý (e.code) để không bị ảnh hưởng bởi
// Caps Lock, Shift, bộ gõ tiếng Việt (Unikey/Telex) hay layout bàn phím.
function keyId(e) {
    const c = e.code || '';
    if (c.startsWith('Key')) return c.slice(3).toLowerCase();
    if (c === 'Space') return ' ';
    if (c === 'ShiftLeft' || c === 'ShiftRight') return 'shift';
    if (c === 'Enter' || c === 'NumpadEnter') return 'enter';
    if (c === 'Escape') return 'escape';
    if (c.startsWith('Arrow')) return c.toLowerCase();
    return (e.key || '').toLowerCase();
}

// Bố cục phím: di chuyển = mũi tên; đánh = Z X C (đấm nhẹ / đấm mạnh / đá); kỹ năng = A S D F; đỡ = K hoặc ↓.
// Phím vật lý được đổi sang mã nội bộ cũ (j/h/l, u/i/o/p) nên toàn bộ logic chiến đấu giữ nguyên.
const KEY_REMAP = { z: 'j', x: 'h', c: 'l', a: 'u', s: 'i', d: 'o', f: 'p' };
const KEY_DISABLED = new Set(['j', 'h', 'l', 'u', 'i', 'o', 'p', 'w']);
const KEY_DISPLAY = { J: 'Z', H: 'X', L: 'C', U: 'A', I: 'S', O: 'D', P: 'F' };
function gameKey(e) { const k = keyId(e); if (KEY_REMAP[k]) return KEY_REMAP[k]; return KEY_DISABLED.has(k) ? '_' + k : k; }

class InputManager {
    constructor() {
        this.keys = {};
        this.tapped = {};   // phím vừa được nhấn xuống trong frame này (edge trigger)
        this.lastTap = {};  // thời điểm nhấn gần nhất của từng phím di chuyển (để bắt nhấn đúp)
        this.sprintKey = null; // phím hướng đang ở chế độ chạy nhanh
        this._bind();
    }
    _bind() {
        const prevent = new Set(['arrowup','arrowdown','arrowleft','arrowright',' ','tab']);
        window.addEventListener('keydown', e => {
            const k = gameKey(e);
            if (prevent.has(k)) e.preventDefault();
            if (!e.repeat && !this.keys[k]) {
                this.tapped[k] = true;
                if (k === 'arrowleft' || k === 'arrowright') {
                    const now = performance.now();
                    if (this.lastTap[k] && now - this.lastTap[k] < 280) this.sprintKey = k;   // nhấn đúp -> chạy nhanh
                    else if (this.sprintKey && this.sprintKey !== k) this.sprintKey = null;
                    this.lastTap[k] = now;
                }
            }
            this.keys[k] = true;
        });
        window.addEventListener('keyup', e => {
            const k = gameKey(e);
            this.keys[k] = false;
            if (this.sprintKey === k) this.sprintKey = null;   // thả phím -> hết chạy nhanh
        });
        window.addEventListener('blur', () => { this.keys = {}; this.tapped = {}; this.sprintKey = null; });
    }
    isDown(k) { return !!this.keys[k]; }
    pressed(k) { return !!this.tapped[k]; }
    // Gọi 1 lần SAU khi game đã xử lý xong frame
    endFrame() { this.tapped = {}; }
    moveX() {
        return (this.isDown('arrowright') ? 1 : 0) - (this.isDown('arrowleft') ? 1 : 0);
    }
    // Trả về hướng (-1/0/1) nếu đang giữ phím sau khi nhấn đúp, ngược lại 0
    sprintDir() {
        const k = this.sprintKey;
        if (!k || !this.keys[k]) return 0;
        return k === 'arrowright' ? 1 : -1;
    }
    jumpBtn() { return this.pressed('arrowup') || this.pressed(' '); }
    crouchBtn() { return this.isDown('arrowdown'); }
    dashBtn() { return this.pressed('shift'); }
}

// ============================================================
// AUDIO MANAGER — toàn bộ âm thanh được tổng hợp bằng WebAudio (không cần file mp3)
//  • SFX: tiếng đấm/đá (thud + whoosh), finisher, kỹ năng, nhảy, lướt, chịu đòn, quái chết...
//  • Nhạc nền chiptune: trống + bass + arpeggio + giai điệu, riêng cho menu và từng màn
// ============================================================
const MAIN_TRACK = 'assets/music/Multifandom_Dancin.mp3';
const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
const MUSIC_TRACKS = {
    menu:  { bpm: 112, bars: [{ r: 45, c: [57, 60, 64] }, { r: 41, c: [53, 57, 60] }, { r: 48, c: [60, 64, 67] }, { r: 43, c: [55, 59, 62] }],
             kick: [0, 6, 10], snare: [4, 12], hat: [0, 2, 4, 6, 8, 10, 12, 14], bass: [0, 3, 6, 8, 11, 14], bassOct: [6, 14], arpWave: 'triangle', arpVol: 0.06, lead: true },
    0:     { bpm: 128, bars: [{ r: 45, c: [57, 60, 64] }, { r: 41, c: [53, 57, 60] }, { r: 48, c: [60, 64, 67] }, { r: 43, c: [55, 59, 62] }],
             kick: [0, 4, 8, 12], snare: [4, 12], hat: [2, 6, 10, 14], bass: [0, 2, 4, 6, 8, 10, 12, 14], bassOct: [6, 14], arpWave: 'square', arpVol: 0.03, lead: true },
    1:     { bpm: 94, bars: [{ r: 38, c: [50, 53, 57] }, { r: 34, c: [46, 50, 53] }, { r: 43, c: [55, 58, 62] }, { r: 45, c: [57, 61, 64] }],
             kick: [0, 10], snare: [8], hat: [0, 4, 8, 12], bass: [0, 8], bassOct: [], bassLen: 6, arpWave: 'sine', arpVol: 0.07, lead: true },
    2:     { bpm: 120, bars: [{ r: 40, c: [52, 55, 59] }, { r: 36, c: [48, 52, 55] }, { r: 38, c: [50, 54, 57] }, { r: 35, c: [47, 50, 54] }],
             kick: [0, 3, 8, 11], snare: [4, 12], hat: [0, 2, 4, 6, 8, 10, 12, 14], bass: [0, 3, 6, 8, 11, 14], bassOct: [6], bassWave: 'sawtooth', bassVol: 0.1, arpWave: 'square', arpVol: 0.028, lead: true },
    3:     { bpm: 152, bars: [{ r: 36, c: [48, 51, 55] }, { r: 32, c: [44, 48, 51] }, { r: 34, c: [46, 50, 53] }, { r: 31, c: [43, 47, 50] }],
             kick: [0, 3, 6, 8, 10, 12, 14], snare: [4, 12], hat: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15], bass: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15], bassOct: [3, 7, 11, 15], bassWave: 'sawtooth', bassVol: 0.09, bassLen: 0.9, arpWave: 'square', arpVol: 0.03, lead: true }
};
const ARP_PAT = [0, 1, 2, 1, 2, 1, 0, 1];
const LEAD_STEPS = [0, 3, 6, 8, 10, 12, 14];
const LEAD_IDX = [2, 1, 0, 1, 2, 1, 0];

class AudioManager {
    constructor() {
        this.ctx = null;
        this.volMaster = 1.7;
        // Cài đặt người dùng (localStorage): bài nhạc cho sảnh / trận, bật-tắt nhạc & hiệu ứng, âm lượng
        this.settings = { menu: MAIN_TRACK, game: 'assets/music/Ricardo Milos U Got That Halogen Full HD 60 fps.mp3', volMusic: 0.7, volSfx: 0.9, musicOn: true, sfxOn: true };
        try { Object.assign(this.settings, JSON.parse(localStorage.getItem('rm_audio_v3') || '{}')); } catch (e) { /* bỏ qua */ }
        // Danh sách nhạc: bài chính do người dùng cung cấp luôn đứng đầu, sau đó là các bài bổ sung (assets/music/playlist.js)
        const list = ((typeof window !== 'undefined' && window.USER_PLAYLIST) || []).slice();
        if (!list.includes(MAIN_TRACK)) list.unshift(MAIN_TRACK);
        this.playlist = list.map(p => ({ name: AudioManager.baseName(p), src: p }));
        this.fileEl = null; this.fileSrc = null; this.fileShuffle = false; this.curContext = 'menu';   // CHỈ MỘT phần tử <audio> cho toàn game
        this.bad = new Set(); this.pendingPlay = false; this.duckLevel = 1;
        this.onNowPlaying = null; this.onNotice = null;
        this.master = this.sfx = this.music = this.noiseBuf = null;
        this.bgmPlaying = false;
        this.currentTrack = null;
        this.track = null;
        this._timer = null;
        this.step = 0;
        this.nextTime = 0;
    }
    _buildBuses() {
        const c = this.ctx;
        this.master = c.createGain(); this.master.gain.value = this.volMaster;
        const comp = c.createDynamicsCompressor();
        comp.threshold.value = -12; comp.knee.value = 14; comp.ratio.value = 10; comp.attack.value = 0.003; comp.release.value = 0.2;
        this.sfx = c.createGain(); this.sfx.gain.value = this.settings.volSfx;
        this.music = c.createGain(); this.music.gain.value = this.settings.volMusic * 0.34 * this.duckLevel;
        this.sfx.connect(this.master); this.music.connect(this.master);
        this.master.connect(comp); comp.connect(c.destination);
        const n = Math.floor(c.sampleRate * 1.5);
        const b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0);
        for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
        this.noiseBuf = b;
    }
    _init() {
        if (!this.ctx) {
            const AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) return false;
            this.ctx = new AC();
            this._buildBuses();
        }
        if (this.ctx.state === 'suspended') this.ctx.resume();
        return true;
    }
    unlock() { this._init(); }          // gọi ở lần bấm phím/chuột đầu tiên (trình duyệt yêu cầu)
    get muted() { return !this.settings.musicOn; }      // 'muted' = nhạc nền đang tắt
    _ready() { return this.settings.sfxOn && this._init(); }
    _now(delay = 0) { return this.ctx.currentTime + 0.005 + delay; }

    // ---- khối âm thanh cơ bản ----
    _osc(type, f0, f1, t, dur, vol, bus) {
        const c = this.ctx, o = c.createOscillator(), g = c.createGain();
        o.type = type;
        o.frequency.setValueAtTime(f0, t);
        if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(vol, t + 0.004);
        g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        o.connect(g); g.connect(bus || this.sfx);
        o.start(t); o.stop(t + dur + 0.03);
    }
    _noise(t, dur, vol, o = {}) {
        const c = this.ctx, src = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
        src.buffer = this.noiseBuf; src.loop = true;
        f.type = o.type || 'lowpass';
        f.frequency.setValueAtTime(o.f0 || 2000, t);
        if (o.f1) f.frequency.exponentialRampToValueAtTime(Math.max(30, o.f1), t + dur);
        f.Q.value = o.q || 1;
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(vol, t + 0.004);
        g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        src.connect(f); f.connect(g); g.connect(o.bus || this.sfx);
        src.start(t, Math.random() * 0.5); src.stop(t + dur + 0.03);
    }

    // ---- hiệu ứng chiến đấu ----
    playSwing(m) {
        if (!this._ready()) return;
        const t = this._now(), kick = m.frames.some(f => f[0] === 'k'), heavy = m.dmg >= 24, r = 0.93 + Math.random() * 0.14;
        const dur = m.spin ? 0.32 : heavy ? 0.16 : 0.1;
        this._noise(t, dur, 0.55 + m.dmg / 100, { type: 'bandpass', f0: (kick ? 500 : 800) * r, f1: (kick ? 2600 : 3400) * r, q: 1.2 });
        if (m.spin) this._noise(t + 0.14, 0.2, 0.55, { type: 'bandpass', f0: 700, f1: 3000, q: 1.2 });
        if (heavy) this._osc('sawtooth', 190 * r, 105, t, 0.13, 0.2);          // tiếng "hự"
    }
    playHit(i = 1) {
        if (!this._ready()) return;
        i = clamp(i, 0.3, 2.6);
        const t = this._now();
        this._osc('sine', 170 + i * 20, 45, t, 0.12 + 0.04 * i, Math.min(0.95, 0.4 + i * 0.3));
        this._osc('square', 230, 90, t, 0.06, 0.07 + i * 0.03);
        this._noise(t, 0.07, 0.3 + i * 0.15, { type: 'highpass', f0: 1800 });
    }
    playBigImpact() {
        if (!this._ready()) return;
        const t = this._now();
        this._osc('sine', 120, 30, t, 0.6, 0.9);
        this._noise(t, 0.4, 0.45, { type: 'lowpass', f0: 4000, f1: 200 });
        this._noise(t, 0.1, 0.35, { type: 'highpass', f0: 2500 });
    }
    playComboUp(n) {
        if (!this._ready()) return;
        const t = this._now(), notes = [659, 784, 988, 1175, 1568].slice(0, n >= 15 ? 5 : n >= 10 ? 4 : 3);
        notes.forEach((f, i) => this._osc('square', f, f, t + i * 0.055, 0.14, 0.14));
    }
    playBlock() {
        if (!this._ready()) return;
        const t = this._now();
        this._osc('square', 900, 600, t, 0.07, 0.3);
        this._osc('triangle', 1350, 900, t, 0.1, 0.22);
        this._noise(t, 0.06, 0.5, { type: 'bandpass', f0: 3000, q: 2 });
    }
    playHurt() {
        if (!this._ready()) return;
        const t = this._now();
        this._osc('sawtooth', 380, 110, t, 0.28, 0.2);
        this._osc('sine', 130, 50, t, 0.14, 0.4);
    }
    playEnemyDeath(boss = false) {
        if (!this._ready()) return;
        const t = this._now();
        this._osc('sawtooth', 700, 60, t, boss ? 0.8 : 0.4, 0.17);
        this._noise(t, boss ? 0.8 : 0.45, 0.28, { type: 'lowpass', f0: 3000, f1: 100 });
        if (boss) { this._osc('sine', 100, 28, t, 1.0, 0.9); this._osc('sawtooth', 350, 30, t + 0.1, 0.9, 0.13); }
    }
    playRoar() {
        if (!this._ready()) return;
        const t = this._now();
        this._osc('sawtooth', 95, 42, t, 1.2, 0.3);
        this._osc('sawtooth', 100, 46, t, 1.2, 0.25);
        this._noise(t, 1.0, 0.3, { type: 'lowpass', f0: 900, f1: 200 });
    }
    playSkill(type) {
        if (!this._ready()) return;
        const t = this._now();
        if (type === 'skill1') {          // Dance: samba arpeggio + conga
            [523, 659, 784, 1047, 784].forEach((f, i) => this._osc('square', f, f, t + i * 0.07, 0.14, 0.07));
            [0, 0.14, 0.28].forEach(d => this._osc('sine', 220, 120, t + d, 0.1, 0.4));
        } else if (type === 'skill2') {   // Thrust: lao tới
            this._osc('sawtooth', 180, 1100, t, 0.28, 0.3);
            this._noise(t, 0.25, 0.8, { type: 'bandpass', f0: 500, f1: 4000, q: 1 });
        } else if (type === 'skill3') {   // Chưởng: nạp khí (âm vút tăng dần)
            this._osc('sine', 140, 900, t, 0.55, 0.22);
            this._osc('sawtooth', 70, 420, t, 0.55, 0.06);
            this._noise(t, 0.55, 0.18, { type: 'bandpass', f0: 300, f1: 3500, q: 2 });
        } else if (type === 'chuong_fire') {   // Chưởng: tia bắn ra
            this._osc('sawtooth', 260, 60, t, 0.7, 0.3);
            this._osc('square', 1400, 300, t, 0.35, 0.08);
            this._osc('sine', 120, 40, t, 0.5, 0.7);
            this._noise(t, 0.7, 0.55, { type: 'bandpass', f0: 2500, f1: 400, q: 0.8 });
        } else if (type === 'ult') {      // Ultimate: tăng dần -> nổ -> hợp âm
            this._osc('sawtooth', 150, 1200, t, 0.6, 0.12);
            this._noise(t, 0.6, 0.25, { type: 'highpass', f0: 500, f1: 6000 });
            this._osc('sine', 120, 30, t + 0.55, 0.8, 0.9);
            [392, 494, 587, 784].forEach((f, i) => this._osc('square', f, f, t + 0.6 + i * 0.04, 0.5, 0.09));
        }
    }
    playDash() { if (!this._ready()) return; this._noise(this._now(), 0.16, 1.0, { type: 'bandpass', f0: 400, f1: 3500, q: 1 }); }
    playJump() { if (!this._ready()) return; this._osc('square', 260, 620, this._now(), 0.11, 0.18); }
    playLand() {
        if (!this._ready()) return;
        const t = this._now();
        this._osc('sine', 100, 50, t, 0.09, 0.5);
        this._noise(t, 0.06, 0.45, { type: 'lowpass', f0: 800 });
    }
    playKO() { if (!this._ready()) return; const t = this._now(); [523, 440, 349, 262].forEach((f, i) => this._osc('sawtooth', f, f * 0.8, t + i * 0.13, 0.3, 0.12)); this._osc('sine', 100, 30, t, 0.7, 0.6); }
    playVictory() {
        if (!this._ready()) return;
        const t = this._now();
        [523, 659, 784, 1047].forEach((f, i) => this._osc('square', f, f, t + i * 0.16, 0.22, 0.09));
        [523, 659, 784, 1047].forEach(f => this._osc('triangle', f, f, t + 0.7, 0.9, 0.12));
    }
    playDefeat() {
        if (!this._ready()) return;
        const t = this._now();
        [392, 370, 349, 294].forEach((f, i) => this._osc('triangle', f, f * 0.97, t + i * 0.3, 0.45, 0.16));
        this._osc('sawtooth', 65, 40, t, 1.6, 0.15);
    }
    // ---- âm thanh chiến đấu bổ sung ----
    playReady() { if (!this._ready()) return; const t = this._now(); this._osc('triangle', 988, 988, t, 0.1, 0.12); this._osc('triangle', 1319, 1319, t + 0.09, 0.2, 0.12); }
    playDeny() { if (this._ready()) this._osc('square', 130, 90, this._now(), 0.1, 0.1); }
    playBlockUp() { if (this._ready()) this._noise(this._now(), 0.06, 0.5, { type: 'bandpass', f0: 1200, q: 2 }); }
    playDoubleJump() { if (!this._ready()) return; const t = this._now(); this._osc('sine', 380, 980, t, 0.16, 0.16); this._osc('triangle', 760, 1500, t + 0.04, 0.14, 0.08); }
    playHeal() { if (!this._ready()) return; const t = this._now(); [523, 659, 784].forEach((f, i) => this._osc('triangle', f, f, t + i * 0.06, 0.22, 0.12)); }
    playWhiff() { if (this._ready()) this._noise(this._now(), 0.1, 0.3, { type: 'bandpass', f0: 500, f1: 1800, q: 1 }); }
    playHeavyHit() { if (!this._ready()) return; const t = this._now(); this._osc('sine', 150, 38, t, 0.26, 0.95); this._noise(t, 0.18, 0.6, { type: 'lowpass', f0: 3500, f1: 300 }); this._noise(t, 0.06, 0.45, { type: 'highpass', f0: 2200 }); }
    playPerfect() { if (!this._ready()) return; const t = this._now(); this._osc('sine', 1568, 1568, t, 0.4, 0.2); this._osc('sine', 2093, 2093, t + 0.04, 0.35, 0.16); this._osc('triangle', 784, 784, t, 0.3, 0.12); this._noise(t, 0.12, 0.35, { type: 'highpass', f0: 3000 }); }
    playSwingEnemy() { if (this._ready()) this._noise(this._now(), 0.12, 0.55, { type: 'bandpass', f0: 350, f1: 1500, q: 1 }); }
    // ---- âm thanh điện ảnh (cốt truyện) ----
    playType() { if (this._ready()) this._osc('square', 1500 + Math.random() * 300, 1500, this._now(), 0.02, 0.05); }
    playCine(name) {
        if (!this._ready()) return;
        const t = this._now();
        switch (name) {
            case 'impact': this.playBigImpact(); break;
            case 'gong':
                this._osc('sine', 98, 96, t, 1.6, 0.55); this._osc('sine', 247, 245, t, 1.2, 0.22); this._osc('sine', 415, 410, t, 0.9, 0.14);
                this._noise(t, 0.15, 0.25, { type: 'bandpass', f0: 1500, q: 1 }); break;
            case 'dark':
                this._osc('sawtooth', 55, 52, t, 2.2, 0.12); this._osc('sawtooth', 58, 54, t, 2.2, 0.1);
                this._noise(t, 2.0, 0.12, { type: 'lowpass', f0: 400, f1: 120 }); break;
            case 'glitch':
                for (let i = 0; i < 7; i++) {
                    this._noise(t + i * 0.06, 0.05, 0.5, { type: 'bandpass', f0: 800 + Math.random() * 3000, q: 4 });
                    this._osc('square', 200 + Math.random() * 1400, 100, t + i * 0.06, 0.05, 0.1);
                } break;
            case 'riser':
                this._osc('sawtooth', 120, 900, t, 1.0, 0.14);
                this._noise(t, 1.0, 0.35, { type: 'highpass', f0: 400, f1: 6000 }); break;
            case 'reveal':
                [523, 659, 784, 1047].forEach((f, i) => this._osc('triangle', f, f, t + i * 0.07, 0.45, 0.12));
                this._noise(t, 0.3, 0.2, { type: 'highpass', f0: 3000 }); break;
            case 'freeze':
                this._osc('sine', 1400, 300, t, 0.9, 0.18); this._osc('sine', 80, 40, t, 1.2, 0.5);
                this._noise(t, 0.8, 0.2, { type: 'lowpass', f0: 3000, f1: 150 }); break;
            case 'eternal':
                this._osc('sawtooth', 150, 1300, t, 1.0, 0.14);
                this._noise(t, 1.0, 0.4, { type: 'highpass', f0: 500, f1: 7000 });
                this._osc('sine', 110, 28, t + 0.9, 1.2, 0.95);
                [220, 277, 330, 440, 554, 659].forEach((f, i) => { this._osc('triangle', f, f, t + 0.9, 2.2, 0.1); this._osc('sine', f * 2, f * 2, t + 0.95 + i * 0.03, 1.8, 0.05); });
                break;
            case 'whoosh': this._noise(t, 0.4, 0.8, { type: 'bandpass', f0: 300, f1: 3000, q: 1 }); break;
        }
    }
    playMenuSelect() { if (this._ready()) this._osc('square', 900, 900, this._now(), 0.045, 0.2); }
    playMenuConfirm() { if (!this._ready()) return; const t = this._now(); this._osc('square', 660, 660, t, 0.06, 0.18); this._osc('square', 990, 990, t + 0.06, 0.12, 0.18); }
    playPause(on) { if (this._ready()) this._osc('square', on ? 600 : 400, on ? 400 : 600, this._now(), 0.1, 0.16); }
    playAnnounce(text = '', sub = '') {
        if (!this._ready()) return;
        const t = this._now();
        this._osc('sine', 98, 96, t, 1.2, 0.5);                       // cồng
        this._osc('sine', 247, 245, t, 0.9, 0.2);
        this._osc('sine', 415, 410, t, 0.6, 0.12);
        this._noise(t, 0.12, 0.2, { type: 'bandpass', f0: 1500, q: 1 });
        if (/FIGHT/i.test(sub)) {
            [330, 440, 554].forEach(f => this._osc('sawtooth', f, f, t + 0.85, 0.35, 0.11));
            this._noise(t + 0.85, 0.14, 0.3, { type: 'highpass', f0: 1800 });
        } else {
            [262, 330, 392].forEach(f => this._osc('triangle', f, f, t + 0.1, 0.5, 0.12));
        }
    }

    // ---- nhạc nền ----
    static baseName(p) {
        let n = String(p).split('/').pop();
        try { n = decodeURIComponent(n); } catch (e) { /* giữ nguyên */ }
        return n.replace(/\.[^.]+$/, '');
    }
    _save() { try { localStorage.setItem('rm_audio_v3', JSON.stringify(this.settings)); } catch (e) { /* bỏ qua */ } }
    // Lựa chọn cho mục cài đặt: từng file nhạc, ngẫu nhiên, chiptune dự phòng
    options() { return this.playlist.map(p => p.src).concat(['shuffle', 'chiptune']); }
    labelOf(v) {
        if (v === 'shuffle') return 'NGẪU NHIÊN (tất cả file)';
        if (v === 'chiptune') return 'CHIPTUNE (dự phòng)';
        const p = this.playlist.find(x => x.src === v);
        return p ? p.name : AudioManager.baseName(MAIN_TRACK);
    }
    cycle(which, dir) {
        const opts = this.options();
        let idx = opts.indexOf(this.settings[which]); if (idx < 0) idx = 0;
        this.settings[which] = opts[(idx + dir + opts.length) % opts.length];
        this._save();
    }
    _applyVolume() {
        if (this.fileEl) this.fileEl.volume = clamp(this.settings.volMusic * this.duckLevel, 0, 1);
        if (this.music) this.music.gain.value = this.settings.volMusic * 0.34 * this.duckLevel;
        if (this.sfx) this.sfx.gain.value = this.settings.volSfx;
    }
    setVolume(which, v) {
        this.settings[which] = Math.round(clamp(v, 0, 1) * 20) / 20;
        this._applyVolume(); this._save();
    }
    duck(v) { this.duckLevel = v; this._applyVolume(); }     // hạ âm lượng nhạc cho đoạn cinematic (không tạo audio mới)
    addFiles(files) {
        let n = 0;
        for (const f of files) {
            if (!/\.(mp3|ogg|wav|m4a|aac|flac)$/i.test(f.name) && !/^audio\//.test(f.type)) continue;
            this.playlist.push({ name: f.name.replace(/\.[^.]+$/, ''), src: URL.createObjectURL(f), session: true });
            n++;
        }
        return n;
    }
    nextTrack() {      // phím N: chuyển bài; áp dụng cho cả sảnh và trận để nhạc không bị ngắt giữa chừng
        const list = this.playlist.filter(p => !this.bad.has(p.src));
        if (list.length < 2) return false;
        const cur = this.settings[this.curContext];
        const idx = (list.findIndex(p => p.src === cur) + 1) % list.length;
        this.settings.menu = this.settings.game = list[idx].src; this._save();
        this.startBGM(this.currentTrack !== null && this.currentTrack !== undefined ? this.currentTrack : 'menu');
        return true;
    }
    _pickRandom(except) {
        const l = this.playlist.filter(p => p.src !== except && !this.bad.has(p.src));
        const pool = l.length ? l : this.playlist; return pool[Math.floor(Math.random() * pool.length)].src;
    }
    _ensureEl() {
        if (this.fileEl) return this.fileEl;
        const el = new Audio(); el.preload = 'auto';
        el.onended = () => { if (this.fileShuffle) this._playFile(this._pickRandom(this.fileSrc), true); };
        el.onerror = () => {      // thiếu file / định dạng không hỗ trợ: báo nhẹ và dùng chiptune, KHÔNG crash
            if (this.fileSrc) { this.bad.add(this.fileSrc); if (this.onNotice) this.onNotice('Không tải được nhạc: ' + this.labelOf(this.fileSrc)); }
            this.fileSrc = null; this.bgmPlaying = false;
            if (this.settings.musicOn) this._startChip(this.currentTrack);
        };
        return (this.fileEl = el);
    }
    _playFile(src, shuffle) {
        const el = this._ensureEl();
        this.fileShuffle = !!shuffle; el.loop = !shuffle;
        if (this.fileSrc !== src) {               // đổi bài (cùng bài thì giữ nguyên, KHÔNG phát lại từ đầu)
            el.pause(); el.src = src.startsWith('blob:') ? src : encodeURI(src); this.fileSrc = src;
            const p = this.playlist.find(x => x.src === src);
            if (this.onNowPlaying && p) this.onNowPlaying(p.name);
        }
        this._applyVolume();
        if (el.paused) { const pr = el.play(); if (pr && pr.catch) pr.then(() => { this.pendingPlay = false; }).catch(() => { this.pendingPlay = true; }); }   // bị chặn autoplay -> chờ thao tác
        this.bgmPlaying = true; return true;
    }
    resumePending() {      // gọi ở mỗi lần bấm phím / chuột: nếu trình duyệt chặn autoplay thì phát lại ngay bây giờ
        if (this.pendingPlay && this.fileEl && this.settings.musicOn && this.fileSrc) {
            const pr = this.fileEl.play(); if (pr && pr.then) pr.then(() => { this.pendingPlay = false; }).catch(() => {});
        }
    }
    startBGM(key) {
        this._stopChip();
        this.currentTrack = key;
        const cx = key === 'menu' ? 'menu' : 'game';
        this.curContext = cx;
        if (!this.settings.musicOn) { if (this.fileEl) this.fileEl.pause(); this.bgmPlaying = false; return; }
        const sel = this.settings[cx];
        let src = null, shuffle = false;
        if (sel === 'shuffle') { shuffle = true; src = (this.fileSrc && this.fileEl && !this.fileEl.ended) ? this.fileSrc : this._pickRandom(this.fileSrc); }
        else if (sel !== 'chiptune') {
            if (this.playlist.some(p => p.src === sel) && !this.bad.has(sel)) src = sel;
            else if (!this.bad.has(MAIN_TRACK)) src = MAIN_TRACK;
        }
        if (src && this._playFile(src, shuffle)) return;
        if (this.fileEl) this.fileEl.pause();
        this._startChip(key);
    }
    _startChip(key) {
        if (!this.settings.musicOn || !this._init()) return;
        this.track = MUSIC_TRACKS[key] || MUSIC_TRACKS[0];
        this.bgmPlaying = true; this.step = 0; this.nextTime = this.ctx.currentTime + 0.08;
        if (!this._timer) this._timer = setInterval(() => this._tick(), 25);
    }
    _stopChip() {
        if (this._timer) { clearInterval(this._timer); this._timer = null; }
        if (!(this.fileEl && !this.fileEl.paused)) this.bgmPlaying = false;
    }
    _tick() {
        if (!this.bgmPlaying || !this.ctx) return;
        const sd = 60 / this.track.bpm / 4;
        if (this.nextTime < this.ctx.currentTime - 0.5) this.nextTime = this.ctx.currentTime + 0.05;   // sau khi tab bị ngủ
        while (this.nextTime < this.ctx.currentTime + 0.2) {
            this._scheduleStep(this.step, this.nextTime, sd);
            this.step = (this.step + 1) % 64;
            this.nextTime += sd;
        }
    }
    _scheduleStep(step, t, sd) {
        const tr = this.track, bar = Math.floor(step / 16) % 4, s = step % 16, B = tr.bars[bar], M = this.music;
        if (tr.kick.includes(s)) this._osc('sine', 150, 42, t, 0.14, 0.55, M);
        if (tr.snare.includes(s)) {
            this._noise(t, 0.11, 0.25, { type: 'highpass', f0: 1800, bus: M });
            this._osc('triangle', 220, 140, t, 0.08, 0.14, M);
        }
        if (tr.hat.includes(s)) this._noise(t, 0.03, 0.07, { type: 'highpass', f0: 7000, bus: M });
        if (bar === 3 && s >= 12 && s % 2 === 1) this._noise(t, 0.06, 0.18, { type: 'highpass', f0: 2000, bus: M });   // trống dạo cuối chu kỳ
        if (tr.bass.includes(s)) {
            const n = B.r + (tr.bassOct.includes(s) ? 12 : 0);
            this._osc(tr.bassWave || 'triangle', mtof(n), mtof(n), t, sd * (tr.bassLen || 1.6), tr.bassVol || 0.22, M);
        }
        let an = B.c[ARP_PAT[s % 8]] + 12; if (s % 8 === 6) an += 12;
        this._osc(tr.arpWave || 'square', mtof(an), mtof(an), t, sd * 0.85, tr.arpVol || 0.035, M);
        if (tr.lead && bar % 2 === 1 && LEAD_STEPS.includes(s)) {
            const ln = B.c[LEAD_IDX[LEAD_STEPS.indexOf(s)]] + 24;
            this._osc('triangle', mtof(ln), mtof(ln), t, sd * 2, 0.1, M);
        }
    }
    stopBGM() {      // chỉ dùng khi người chơi tắt nhạc
        this.bgmPlaying = false;
        if (this._timer) { clearInterval(this._timer); this._timer = null; }
        if (this.fileEl) this.fileEl.pause();
    }
    toggleMusic(force) {
        this.settings.musicOn = force === undefined ? !this.settings.musicOn : !!force; this._save();
        if (!this.settings.musicOn) this.stopBGM(); else this.startBGM(this.currentTrack !== null && this.currentTrack !== undefined ? this.currentTrack : 'menu');
        return !this.settings.musicOn;
    }
    toggleMute() { return this.toggleMusic(); }
    toggleSfx() { this.settings.sfxOn = !this.settings.sfxOn; this._save(); return !this.settings.sfxOn; }
}

// ============================================================
// CAMERA
// ============================================================
class Camera {
    constructor() {
        this.x = 0; this.y = 0;
        this.targetX = 0; this.targetY = 0;
        this.shakeAmount = 0; this.shakeDuration = 0;
        this.zoom = 1; this.targetZoom = 1;
        this.shakeOffX = 0; this.shakeOffY = 0;
    }
    follow(tx, ty, mapW) {
        this.targetX = clamp(tx - W / 2, 0, Math.max(0, mapW - W));
        this.targetY = 0;
    }
    shake(amount, dur = 0.3) {
        this.shakeAmount = amount;
        this.shakeDuration = dur;
    }
    update(dt) {
        this.x = lerp(this.x, this.targetX, 1 - Math.pow(0.001, dt));
        this.y = lerp(this.y, this.targetY, 1 - Math.pow(0.001, dt));
        this.zoom = lerp(this.zoom, this.targetZoom, 1 - Math.pow(0.01, dt));
        if (this.shakeDuration > 0) {
            this.shakeDuration -= dt;
            this.shakeOffX = (Math.random() - 0.5) * this.shakeAmount;
            this.shakeOffY = (Math.random() - 0.5) * this.shakeAmount;
            this.shakeAmount *= 0.92;
        } else {
            this.shakeOffX = this.shakeOffY = 0;
        }
    }
    screenX(wx) { return (wx - this.x) + this.shakeOffX; }
    screenY(wy) { return (wy - this.y) + this.shakeOffY; }
    visible(wx, wy, ww, wh) {
        const sx = wx - this.x;
        return sx + ww > -100 && sx < W + 100 && wy + wh > -100 && wy < H + 100;
    }
}

// ============================================================
// PARTICLE SYSTEM (Object Pooled)
// ============================================================
const mix2 = c => PXFX.mix ? PXFX.mix(c, '#ffffff', 0.5) : c;     // màu sáng hơn của màu sóng
class ParticleSystem {
    constructor(maxParticles = 500) {
        this.pool = [];
        for (let i = 0; i < maxParticles; i++) {
            this.pool.push({ active: false, x: 0, y: 0, vx: 0, vy: 0, life: 0, maxLife: 1, color: '#fff', size: 3, gravity: 0, type: 'circle' });
        }
    }
    _get() {
        for (let i = 0; i < this.pool.length; i++) {
            if (!this.pool[i].active) return this.pool[i];
        }
        return null;
    }
    emit(x, y, count, cfg) {
        for (let i = 0; i < count; i++) {
            const p = this._get();
            if (!p) return;
            p.active = true;
            p.x = x + (cfg.spreadX || 0) * (Math.random() - 0.5);
            p.y = y + (cfg.spreadY || 0) * (Math.random() - 0.5);
            p.vx = (cfg.vx || 0) + (cfg.vxRand || 0) * (Math.random() - 0.5);
            p.vy = (cfg.vy || 0) + (cfg.vyRand || 0) * (Math.random() - 0.5);
            p.life = p.maxLife = cfg.life || 0.5;
            p.color = Array.isArray(cfg.color) ? cfg.color[randInt(0, cfg.color.length - 1)] : (cfg.color || '#fff');
            p.size = cfg.size || 3;
            p.gravity = cfg.gravity !== undefined ? cfg.gravity : 400;
            p.type = cfg.type || 'circle';
        }
    }
    hitSpark(x, y, color = '#ffcc44') {
        this.emit(x, y, 12, { vxRand: 500, vyRand: 400, vy: -150, life: 0.3, color: [color, '#fff', '#ffaa33'], size: 3, gravity: 300, type: 'spark' });
    }
    dust(x, y) {
        this.emit(x, y, 6, { vxRand: 120, vy: -30, vyRand: 40, life: 0.3, color: ['#8a7a6a', '#a09080'], size: 4, gravity: 100 });
    }
    energyBurst(x, y, color = '#39e7ff') {
        this.emit(x, y, 25, { vxRand: 400, vyRand: 400, life: 0.5, color: [color, '#fff'], size: 4, gravity: -50 });
    }
    trail(x, y, color = '#ff3ca6') {
        this.emit(x, y, 2, { spreadX: 10, spreadY: 20, vxRand: 30, vyRand: 30, life: 0.3, color, size: 3, gravity: 0 });
    }
    fire(x, y) {
        this.emit(x, y, 3, { spreadX: 20, vy: -80, vyRand: 60, vxRand: 40, life: 0.4, color: ['#ff6600', '#ff3300', '#ffaa00'], size: 5, gravity: -100 });
    }
    smoke(x, y) {
        this.emit(x, y, 2, { spreadX: 15, vy: -40, vyRand: 20, life: 0.6, color: ['#555', '#777', '#999'], size: 6, gravity: -30 });
    }
    update(dt) {
        for (const p of this.pool) {
            if (!p.active) continue;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.vy += p.gravity * dt;
            p.life -= dt;
            if (p.life <= 0) p.active = false;
        }
    }
    draw(ctx, cam) {
        for (const p of this.pool) {
            if (!p.active) continue;
            const sx = cam.screenX(p.x), sy = cam.screenY(p.y);
            if (sx < -20 || sx > W + 20 || sy < -20 || sy > H + 20) continue;
            const alpha = clamp(p.life / p.maxLife, 0, 1);
            ctx.globalAlpha = alpha;
            ctx.fillStyle = p.color;
            const s = p.size * (0.5 + 0.5 * alpha);
            if (p.type === 'spark') {          // tia lửa pixel: ô vuông 3px/6px bám lưới
                const q = s > 3.4 ? 6 : 3;
                ctx.fillRect(Math.round(sx / 3) * 3, Math.round(sy / 3) * 3, q, q);
            } else {
                ctx.beginPath();
                ctx.arc(sx, sy, s, 0, Math.PI * 2);
                ctx.fill();
            }
        }
        ctx.globalAlpha = 1;
    }
}

// ============================================================
// FLOATING TEXT SYSTEM
// ============================================================
class FloatingTextSystem {
    constructor() {
        this.texts = [];
    }
    show(x, y, text, color = '#fff', size = 20, duration = 0.8) {
        this.texts.push({ x, y, text, color, size, life: duration, maxLife: duration, scale: 1.5 });
    }
    update(dt) {
        for (let i = this.texts.length - 1; i >= 0; i--) {
            const t = this.texts[i];
            t.y -= 50 * dt;
            t.life -= dt;
            t.scale = lerp(t.scale, 1, 0.1);
            if (t.life <= 0) this.texts.splice(i, 1);
        }
    }
    draw(ctx, cam) {
        for (const t of this.texts) {
            const sx = cam.screenX(t.x), sy = cam.screenY(t.y);
            const alpha = clamp(t.life / t.maxLife * 2, 0, 1);
            ctx.globalAlpha = alpha;
            ctx.fillStyle = t.color;
            ctx.font = `900 ${Math.round(t.size * t.scale)}px system-ui`;
            ctx.textAlign = 'center';
            ctx.shadowColor = t.color;
            ctx.shadowBlur = 8;
            ctx.fillText(t.text, sx, sy);
            ctx.shadowBlur = 0;
        }
        ctx.globalAlpha = 1;
    }
}

// ============================================================
// ZONE / MAP DEFINITIONS
// ============================================================
const ZONES = [
    {
        id: 0, name: 'NEON CITY', width: 5000, groundY: GROUND_Y,
        skyColors: ['#0a0020', '#1a0a3a', '#2a1050'],
        groundColor: '#1a1a30', groundAccent: '#2a2a50',
        parallaxColors: [
            { buildings: '#0d0d25', windows: '#39e7ff', neon: '#ff3ca6' },
            { buildings: '#151535', windows: '#ffd45a', signs: '#00ffff' },
        ],
        ambientParticle: { color: ['#39e7ff33', '#ff3ca655'], type: 'rain' },
        enemyTypes: ['wojak', 'doge'], enemyCount: [2, 3, 4], waves: 3
    },
    {
        id: 1, name: 'DARK FOREST', width: 5500, groundY: GROUND_Y,
        skyColors: ['#050f05', '#0a1f0a', '#102a10'],
        groundColor: '#1a2a15', groundAccent: '#2a3a20',
        parallaxColors: [
            { hills: '#0a1a08', trees: '#0d200d' },
            { trunks: '#2a1a0a', leaves: '#1a3a1a', moss: '#2aff8a' },
        ],
        ambientParticle: { color: ['#2aff8a44', '#aaffcc33'], type: 'firefly' },
        enemyTypes: ['troll', 'dancer', 'doge'], enemyCount: [2, 3, 4], waves: 3
    },
    {
        id: 2, name: 'LAVA FORTRESS', width: 4500, groundY: GROUND_Y,
        skyColors: ['#1a0a00', '#2a0f00', '#4a1a00'],
        groundColor: '#2a1a10', groundAccent: '#3a2a1a',
        parallaxColors: [
            { mountains: '#1a0a05', lava: '#ff4400' },
            { walls: '#2a1a10', chains: '#5a5a6a', flames: '#ff6600' },
        ],
        ambientParticle: { color: ['#ff660044', '#ff220033'], type: 'ember' },
        enemyTypes: ['chad', 'sigma', 'wojak'], enemyCount: [2, 2, 3], waves: 3
    },
    {
        id: 3, name: 'DEMON ARENA', width: 3000, groundY: GROUND_Y,
        skyColors: ['#0a0015', '#150020', '#2a0040'],
        groundColor: '#1a0a20', groundAccent: '#2a1a35',
        parallaxColors: [
            { arches: '#0d0020', torches: '#ffcc00' },
            { pillars: '#1a0a30', runes: '#ff3333', energy: '#cc0033' },
        ],
        ambientParticle: { color: ['#cc003344', '#ffcc0033'], type: 'rune' },
        enemyTypes: ['boss'], enemyCount: [1], waves: 1
    }
];

// ============================================================
// MAP RENDERER (Procedural Parallax Backgrounds)
// ============================================================
class MapManager {
    constructor() {
        this.currentZone = 0;
        this.bgCanvases = [];
        this.envTimer = 0;
        this._prerender();
    }
    _prerender() {
        for (let z = 0; z < ZONES.length; z++) {
            const zone = ZONES[z];
            const layers = [];
            // Layer 0: far background
            layers.push(this._renderLayer(zone, 0));
            // Layer 1: mid background
            layers.push(this._renderLayer(zone, 1));
            this.bgCanvases.push(layers);
        }
    }
    _renderLayer(zone, layerIdx) {
        const c = document.createElement('canvas');
        c.width = zone.width;
        c.height = H;
        const ctx = c.getContext('2d');
        switch (zone.id) {
            case 0: this._drawNeonCity(ctx, zone, layerIdx); break;
            case 1: this._drawDarkForest(ctx, zone, layerIdx); break;
            case 2: this._drawLavaFortress(ctx, zone, layerIdx); break;
            case 3: this._drawDemonArena(ctx, zone, layerIdx); break;
        }
        return c;
    }
    _drawNeonCity(ctx, zone, layer) {
        const w = zone.width, h = H;
        if (layer === 0) {
            // Far buildings silhouette
            for (let i = 0; i < w; i += rand(60, 120)) {
                const bh = rand(150, 350);
                const bw = rand(40, 80);
                ctx.fillStyle = '#0d0d25';
                ctx.fillRect(i, GROUND_Y - bh, bw, bh);
                // Windows
                for (let wy = GROUND_Y - bh + 10; wy < GROUND_Y - 20; wy += rand(12, 20)) {
                    for (let wx = i + 5; wx < i + bw - 5; wx += rand(8, 15)) {
                        if (Math.random() > 0.4) {
                            ctx.fillStyle = Math.random() > 0.5 ? '#39e7ff44' : '#ffd45a33';
                            ctx.fillRect(wx, wy, 4, 4);
                        }
                    }
                }
            }
        } else {
            // Mid buildings with neon signs
            for (let i = 0; i < w; i += rand(80, 160)) {
                const bh = rand(100, 260);
                const bw = rand(50, 100);
                ctx.fillStyle = '#151535';
                ctx.fillRect(i, GROUND_Y - bh, bw, bh);
                ctx.strokeStyle = '#2a2a55';
                ctx.lineWidth = 1;
                ctx.strokeRect(i, GROUND_Y - bh, bw, bh);
                // Brighter windows
                for (let wy = GROUND_Y - bh + 8; wy < GROUND_Y - 15; wy += rand(10, 16)) {
                    for (let wx = i + 4; wx < i + bw - 4; wx += rand(8, 14)) {
                        if (Math.random() > 0.35) {
                            ctx.fillStyle = Math.random() > 0.5 ? '#39e7ff66' : '#ffd45a55';
                            ctx.fillRect(wx, wy, 5, 4);
                        }
                    }
                }
                // Neon signs
                if (Math.random() > 0.5) {
                    const sx = i + 5, sy = GROUND_Y - bh + rand(20, bh * 0.3);
                    const sw = rand(20, bw - 10), sh = rand(8, 15);
                    const neonColor = Math.random() > 0.5 ? '#ff3ca6' : '#39e7ff';
                    ctx.shadowColor = neonColor;
                    ctx.shadowBlur = 15;
                    ctx.strokeStyle = neonColor;
                    ctx.lineWidth = 2;
                    ctx.strokeRect(sx, sy, sw, sh);
                    ctx.shadowBlur = 0;
                }
                // Street lamps
                if (Math.random() > 0.6) {
                    ctx.strokeStyle = '#3a3a5a';
                    ctx.lineWidth = 3;
                    const lx = i + bw / 2;
                    ctx.beginPath(); ctx.moveTo(lx, GROUND_Y); ctx.lineTo(lx, GROUND_Y - 80); ctx.stroke();
                    ctx.fillStyle = '#ffd45a66';
                    ctx.shadowColor = '#ffd45a';
                    ctx.shadowBlur = 20;
                    ctx.beginPath(); ctx.arc(lx, GROUND_Y - 85, 5, 0, Math.PI * 2); ctx.fill();
                    ctx.shadowBlur = 0;
                }
            }
        }
    }
    _drawDarkForest(ctx, zone, layer) {
        const w = zone.width;
        if (layer === 0) {
            // Distant hills and large trees
            for (let i = 0; i < w; i += rand(30, 60)) {
                const hillH = rand(80, 200);
                ctx.fillStyle = '#0a1a08';
                ctx.beginPath();
                ctx.moveTo(i, GROUND_Y);
                ctx.quadraticCurveTo(i + rand(20, 40), GROUND_Y - hillH, i + rand(50, 90), GROUND_Y);
                ctx.fill();
            }
            // Large tree silhouettes
            for (let i = 0; i < w; i += rand(150, 300)) {
                this._drawTree(ctx, i, GROUND_Y, rand(80, 160), '#0d200d', '#081808');
            }
        } else {
            // Closer trees with more detail
            for (let i = 0; i < w; i += rand(100, 250)) {
                this._drawTree(ctx, i, GROUND_Y, rand(60, 120), '#1a3a1a', '#0d200d');
                // Mushrooms
                if (Math.random() > 0.6) {
                    const mx = i + rand(-30, 30), my = GROUND_Y;
                    ctx.fillStyle = '#4a2a1a';
                    ctx.fillRect(mx - 2, my - 12, 4, 12);
                    ctx.fillStyle = Math.random() > 0.5 ? '#ff4444' : '#aa44ff';
                    ctx.beginPath(); ctx.arc(mx, my - 14, 8, Math.PI, 0); ctx.fill();
                    // Glow
                    if (Math.random() > 0.5) {
                        ctx.fillStyle = '#2aff8a33';
                        ctx.beginPath(); ctx.arc(mx, my - 14, 15, 0, Math.PI * 2); ctx.fill();
                    }
                }
            }
            // Rocks
            for (let i = 0; i < w; i += rand(200, 400)) {
                const rx = i, ry = GROUND_Y;
                ctx.fillStyle = '#3a3a2a';
                ctx.beginPath();
                ctx.moveTo(rx - 15, ry);
                ctx.lineTo(rx - 10, ry - 20);
                ctx.lineTo(rx + 5, ry - 25);
                ctx.lineTo(rx + 15, ry - 15);
                ctx.lineTo(rx + 18, ry);
                ctx.fill();
            }
        }
    }
    _drawTree(ctx, x, groundY, height, leafColor, trunkColor) {
        const tw = height * 0.15;
        ctx.fillStyle = trunkColor;
        ctx.fillRect(x - tw / 2, groundY - height * 0.6, tw, height * 0.6);
        ctx.fillStyle = leafColor;
        ctx.beginPath();
        ctx.moveTo(x - height * 0.4, groundY - height * 0.4);
        ctx.lineTo(x, groundY - height);
        ctx.lineTo(x + height * 0.4, groundY - height * 0.4);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(x - height * 0.35, groundY - height * 0.55);
        ctx.lineTo(x, groundY - height * 0.9);
        ctx.lineTo(x + height * 0.35, groundY - height * 0.55);
        ctx.fill();
    }
    _drawLavaFortress(ctx, zone, layer) {
        const w = zone.width;
        if (layer === 0) {
            // Volcanic mountains
            for (let i = 0; i < w; i += rand(100, 200)) {
                const mh = rand(150, 300);
                ctx.fillStyle = '#1a0a05';
                ctx.beginPath();
                ctx.moveTo(i, GROUND_Y);
                ctx.lineTo(i + rand(30, 60), GROUND_Y - mh);
                ctx.lineTo(i + rand(80, 150), GROUND_Y);
                ctx.fill();
                // Lava glow at top
                if (Math.random() > 0.5) {
                    ctx.fillStyle = '#ff440066';
                    ctx.beginPath();
                    ctx.arc(i + 50, GROUND_Y - mh + 10, 15, 0, Math.PI * 2);
                    ctx.fill();
                }
            }
        } else {
            // Fortress walls and pillars
            for (let i = 0; i < w; i += rand(120, 250)) {
                const ph = rand(80, 180);
                const pw = rand(20, 35);
                ctx.fillStyle = '#2a1a10';
                ctx.fillRect(i, GROUND_Y - ph, pw, ph);
                // Stone texture lines
                for (let ly = GROUND_Y - ph; ly < GROUND_Y; ly += rand(10, 20)) {
                    ctx.strokeStyle = '#1a0a05';
                    ctx.lineWidth = 1;
                    ctx.beginPath(); ctx.moveTo(i, ly); ctx.lineTo(i + pw, ly); ctx.stroke();
                }
                // Chains
                if (Math.random() > 0.6) {
                    ctx.strokeStyle = '#5a5a6a';
                    ctx.lineWidth = 2;
                    const cx = i + pw / 2;
                    for (let cy = GROUND_Y - ph; cy < GROUND_Y - 20; cy += 8) {
                        ctx.beginPath();
                        ctx.ellipse(cx + (cy % 16 < 8 ? -2 : 2), cy, 3, 4, 0, 0, Math.PI * 2);
                        ctx.stroke();
                    }
                }
            }
            // Lava pools on ground
            for (let i = 0; i < w; i += rand(300, 600)) {
                const lw = rand(40, 80);
                ctx.fillStyle = '#ff440066';
                ctx.shadowColor = '#ff4400';
                ctx.shadowBlur = 15;
                ctx.fillRect(i, GROUND_Y + 2, lw, 8);
                ctx.shadowBlur = 0;
            }
        }
    }
    _drawDemonArena(ctx, zone, layer) {
        const w = zone.width;
        if (layer === 0) {
            // Gothic arches and massive architecture
            for (let i = 0; i < w; i += rand(150, 300)) {
                const ah = rand(200, 380);
                const aw = rand(60, 120);
                ctx.fillStyle = '#0d0020';
                ctx.fillRect(i, GROUND_Y - ah, aw, ah);
                // Pointed arch top
                ctx.beginPath();
                ctx.moveTo(i, GROUND_Y - ah);
                ctx.lineTo(i + aw / 2, GROUND_Y - ah - 40);
                ctx.lineTo(i + aw, GROUND_Y - ah);
                ctx.fill();
                // Torches
                if (Math.random() > 0.4) {
                    ctx.fillStyle = '#ffcc00';
                    ctx.shadowColor = '#ffcc00';
                    ctx.shadowBlur = 20;
                    ctx.beginPath();
                    ctx.arc(i + aw / 2, GROUND_Y - ah + 30, 5, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.shadowBlur = 0;
                }
            }
        } else {
            // Pillars and rune circles
            for (let i = 0; i < w; i += rand(200, 350)) {
                const ph = rand(100, 200);
                ctx.fillStyle = '#1a0a30';
                ctx.fillRect(i, GROUND_Y - ph, 25, ph);
                ctx.fillRect(i - 5, GROUND_Y - ph, 35, 10);
                ctx.fillRect(i - 5, GROUND_Y - 10, 35, 10);
                // Glowing runes on pillar
                for (let ry = GROUND_Y - ph + 20; ry < GROUND_Y - 20; ry += 30) {
                    ctx.fillStyle = '#ff333366';
                    ctx.shadowColor = '#ff3333';
                    ctx.shadowBlur = 8;
                    ctx.fillRect(i + 5, ry, 15, 3);
                    ctx.shadowBlur = 0;
                }
            }
            // Ground runes
            for (let i = 0; i < w; i += rand(150, 300)) {
                ctx.strokeStyle = '#cc003344';
                ctx.shadowColor = '#cc0033';
                ctx.shadowBlur = 10;
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.arc(i, GROUND_Y + 5, rand(20, 40), 0, Math.PI * 2);
                ctx.stroke();
                ctx.shadowBlur = 0;
            }
        }
    }
    setZone(id) { this.currentZone = clamp(id, 0, ZONES.length - 1); }
    getZone() { return ZONES[this.currentZone]; }
    getGroundY() { return ZONES[this.currentZone].groundY; }
    getWidth() { return ZONES[this.currentZone].width; }
    update(dt) { this.envTimer += dt; }
    drawSky(ctx) {
        const zone = ZONES[this.currentZone];
        const g = ctx.createLinearGradient(0, 0, 0, H);
        g.addColorStop(0, zone.skyColors[0]);
        g.addColorStop(0.5, zone.skyColors[1]);
        g.addColorStop(1, zone.skyColors[2]);
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, W, H);
        // Stars
        if (this.currentZone !== 2) {
            ctx.fillStyle = '#ffffff';
            for (let i = 0; i < 60; i++) {
                const sx = (i * 197 + i * i * 13) % W;
                const sy = (i * 83 + i * 7) % (GROUND_Y * 0.5);
                const blink = Math.sin(this.envTimer * 2 + i) * 0.3 + 0.7;
                ctx.globalAlpha = blink * 0.6;
                ctx.beginPath(); ctx.arc(sx, sy, 1, 0, Math.PI * 2); ctx.fill();
            }
            ctx.globalAlpha = 1;
        }
        // Moon/Sun
        if (this.currentZone === 0) {
            ctx.fillStyle = '#aaccff';
            ctx.shadowColor = '#aaccff';
            ctx.shadowBlur = 40;
            ctx.beginPath(); ctx.arc(W * 0.8, 100, 30, 0, Math.PI * 2); ctx.fill();
            ctx.shadowBlur = 0;
        } else if (this.currentZone === 2) {
            ctx.fillStyle = '#ff4400';
            ctx.shadowColor = '#ff4400';
            ctx.shadowBlur = 50;
            ctx.beginPath(); ctx.arc(W * 0.7, 80, 40, 0, Math.PI * 2); ctx.fill();
            ctx.shadowBlur = 0;
        } else if (this.currentZone === 3) {
            // Swirling vortex
            ctx.save();
            ctx.translate(W / 2, 120);
            for (let r = 0; r < 5; r++) {
                ctx.globalAlpha = 0.1;
                ctx.strokeStyle = r % 2 === 0 ? '#6600aa' : '#cc0033';
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.arc(0, 0, 40 + r * 25, this.envTimer * 0.5 + r, this.envTimer * 0.5 + r + 3);
                ctx.stroke();
            }
            ctx.restore();
            ctx.globalAlpha = 1;
        }
    }
    drawBackground(ctx, cam) {
        const zone = ZONES[this.currentZone];
        const layers = this.bgCanvases[this.currentZone];
        if (!layers) return;
        // Parallax layer 0 (far, slow)
        const speed0 = 0.15;
        const offX0 = -cam.x * speed0;
        ctx.drawImage(layers[0], offX0, 0);
        if (offX0 + zone.width < W) ctx.drawImage(layers[0], offX0 + zone.width, 0);
        // Parallax layer 1 (mid)
        const speed1 = 0.4;
        const offX1 = -cam.x * speed1;
        ctx.drawImage(layers[1], offX1, 0);
        if (offX1 + zone.width < W) ctx.drawImage(layers[1], offX1 + zone.width, 0);
    }
    drawGround(ctx, cam) {
        const zone = ZONES[this.currentZone];
        const gy = cam.screenY(zone.groundY);
        // Main ground
        ctx.fillStyle = zone.groundColor;
        ctx.fillRect(0, gy, W, H - gy);
        // Ground line
        ctx.strokeStyle = zone.groundAccent;
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke();
        // Ground texture
        ctx.fillStyle = zone.groundAccent + '44';
        for (let x = -cam.x % 40; x < W; x += 40) {
            ctx.fillRect(x, gy + 8, 20, 3);
        }
        // Zone-specific ground details
        if (this.currentZone === 0) {
            // Road lanes
            ctx.fillStyle = '#ffffff15';
            ctx.fillRect(0, gy + 25, W, 2);
        } else if (this.currentZone === 2) {
            // Lava cracks
            for (let x = -cam.x % 80; x < W; x += 80) {
                ctx.strokeStyle = '#ff440044';
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(x, gy + 5);
                ctx.lineTo(x + rand(-10, 10), gy + 15);
                ctx.lineTo(x + rand(-15, 15), gy + 25);
                ctx.stroke();
            }
        }
    }
    drawAmbient(ctx, cam, particles) {
        const zone = ZONES[this.currentZone];
        // Zone-specific ambient particles
        if (Math.random() > 0.7) {
            const px = cam.x + rand(0, W);
            const py = rand(0, GROUND_Y);
            switch (zone.ambientParticle.type) {
                case 'rain':
                    particles.emit(px, py, 1, { vy: 400, vx: -50, life: 0.5, color: '#39e7ff22', size: 1, gravity: 0, type: 'spark' });
                    break;
                case 'firefly':
                    particles.emit(px, py, 1, { vxRand: 30, vyRand: 30, life: 1.5, color: '#2aff8a66', size: 2, gravity: -10 });
                    break;
                case 'ember':
                    particles.emit(px, GROUND_Y, 1, { vxRand: 20, vy: -60, life: 1, color: ['#ff660066', '#ff220044'], size: 2, gravity: -30 });
                    break;
                case 'rune':
                    particles.emit(px, GROUND_Y - 5, 1, { vxRand: 10, vy: -20, life: 1.2, color: '#cc003344', size: 2, gravity: -5 });
                    break;
            }
        }
    }
}

// ============================================================
// COMBO TABLE — J (đấm nhẹ) · H (đấm mạnh) · L (đá)   |   K = ĐỠ ĐÒN
// Nhấn tiếp phím trong "cửa sổ nối đòn" để chuyển sang đòn kế tiếp.
// Mỗi chuỗi phím cho ra một chiêu khác nhau, tối đa 4 đòn.
// Frame token: p=punch k=kick j=jump d=dance i=idle  + số thứ tự frame
// ============================================================
const ANIM_OF = { p: 'punch', k: 'kick', j: 'jump', d: 'dance', i: 'idle', r: 'run' };
const CHAIN_GRACE = 0.32;   // sau khi đòn kết thúc vẫn nối được trong khoảng này
function mv(o) {
    return Object.assign({
        name: '', dur: 0.3, dmg: 10, hit: [0.3, 0.65], cancel: 0.55,
        reach: 70, y: 36, h: 34, lunge: 40, kb: 140, stun: 0.35, mp: 3,
        hop: 0, launch: false, spin: false, lean: 0, arc: '#ffffff', shake: 4,
        frames: ['p0']
    }, o);
}
const COMBO_MOVES = {
    // --- Đòn mở đầu ---
    'J':  mv({ name: 'JAB', dur: 0.26, dmg: 8, hit: [0.28, 0.6], cancel: 0.42, reach: 64, y: 34, h: 28, lunge: 28, kb: 90, frames: ['p0', 'p1', 'p1', 'p0'] }),
    'H':  mv({ name: 'HAYMAKER', dur: 0.5, dmg: 24, hit: [0.3, 0.7], cancel: 0.62, reach: 82, y: 32, h: 40, lunge: 46, kb: 240, stun: 0.45, mp: 5, shake: 9, arc: '#ffb347', frames: ['p0', 'p2', 'p3', 'p4', 'p4', 'p5', 'p5', 'p2', 'p0'] }),
    'L':  mv({ name: 'FRONT KICK', dur: 0.38, dmg: 16, hit: [0.3, 0.72], cancel: 0.58, reach: 92, y: 46, h: 36, lunge: 34, kb: 200, shake: 6, arc: '#6ec6ff', frames: ['k0', 'k1', 'k2', 'k3', 'k3', 'k3', 'k2', 'k1'] }),
    // --- Đòn thứ 2 ---
    'JJ': mv({ name: 'CROSS', dur: 0.3, dmg: 10, hit: [0.25, 0.6], cancel: 0.46, reach: 72, lunge: 44, kb: 120, frames: ['p2', 'p4', 'p4', 'p6'] }),
    'JH': mv({ name: 'STRAIGHT', dur: 0.42, dmg: 20, hit: [0.28, 0.65], cancel: 0.58, reach: 90, lunge: 70, kb: 220, shake: 8, arc: '#ffb347', frames: ['p0', 'p3', 'p4', 'p4', 'p5', 'p5', 'p6'] }),
    'JL': mv({ name: 'JAB-KICK', dur: 0.36, dmg: 16, hit: [0.3, 0.7], cancel: 0.56, reach: 92, y: 46, lunge: 40, kb: 190, shake: 6, arc: '#6ec6ff', frames: ['p1', 'k1', 'k2', 'k3', 'k3', 'k2'] }),
    'HJ': mv({ name: 'BACKFIST', dur: 0.28, dmg: 12, hit: [0.2, 0.55], cancel: 0.42, reach: 70, lunge: 30, kb: 130, frames: ['p2', 'p3', 'p3', 'p6'] }),
    'HH': mv({ name: 'DOUBLE SMASH', dur: 0.48, dmg: 26, hit: [0.3, 0.7], cancel: 0.62, reach: 86, lunge: 60, kb: 280, stun: 0.5, mp: 5, shake: 11, arc: '#ff8a3d', frames: ['p0', 'p3', 'p4', 'p5', 'p5', 'p5', 'p4', 'p2'] }),
    'HL': mv({ name: 'SMASH KICK', dur: 0.46, dmg: 24, hit: [0.3, 0.72], cancel: 0.6, reach: 100, y: 44, lunge: 54, kb: 300, stun: 0.45, shake: 9, arc: '#ff6ec7', frames: ['p4', 'k1', 'k2', 'k3', 'k3', 'k3', 'k2', 'k1'] }),
    'LJ': mv({ name: 'KICK-PUNCH', dur: 0.3, dmg: 14, hit: [0.28, 0.62], cancel: 0.46, reach: 74, lunge: 36, kb: 150, frames: ['k3', 'p1', 'p4', 'p4', 'p6'] }),
    'LH': mv({ name: 'AXE KICK', dur: 0.5, dmg: 26, hit: [0.32, 0.7], cancel: 0.62, reach: 88, y: 18, h: 62, lunge: 30, kb: 160, stun: 0.6, mp: 5, shake: 10, arc: '#ffd45a', frames: ['k1', 'j3', 'k2', 'k3', 'k3', 'k4', 'k1'] }),
    'LL': mv({ name: 'DOUBLE KICK', dur: 0.36, dmg: 18, hit: [0.28, 0.7], cancel: 0.54, reach: 96, y: 46, lunge: 40, kb: 210, shake: 6, arc: '#6ec6ff', frames: ['k0', 'k2', 'k3', 'k3', 'k2'] }),
    // --- Đòn thứ 3 (chiêu đặt tên) ---
    'JJJ': mv({ name: 'HOOK', dur: 0.34, dmg: 14, hit: [0.28, 0.65], cancel: 0.5, reach: 78, lunge: 50, kb: 180, lean: 0.08, frames: ['p3', 'p5', 'p5', 'p6'] }),
    'JJH': mv({ name: 'DIRTY HOOK', dur: 0.46, dmg: 26, hit: [0.3, 0.7], cancel: 0.6, reach: 88, lunge: 64, kb: 300, stun: 0.5, shake: 11, arc: '#ff8a3d', frames: ['p0', 'p3', 'p5', 'p5', 'p4', 'p2'] }),
    'JJL': mv({ name: 'TORNADO KICK', dur: 0.5, dmg: 24, hit: [0.2, 0.8], cancel: 0.64, reach: 108, y: 40, h: 44, lunge: 56, kb: 280, shake: 9, spin: true, arc: '#6ec6ff', frames: ['k0', 'k2', 'k3', 'k3', 'k3', 'k2'] }),
    'JHL': mv({ name: 'RICARDO SPECIAL', dur: 0.56, dmg: 32, hit: [0.2, 0.85], cancel: 0.66, reach: 116, y: 30, h: 60, lunge: 30, kb: 340, stun: 0.6, mp: 6, hop: 260, launch: true, shake: 13, spin: true, arc: '#ff6ec7', frames: ['d2', 'k2', 'k3', 'k3', 'k3', 'd4'] }),
    'HHH': mv({ name: 'TRIPLE SMASH', dur: 0.56, dmg: 34, hit: [0.3, 0.72], cancel: 0.66, reach: 94, y: 24, h: 56, lunge: 70, kb: 360, stun: 0.6, mp: 6, hop: 180, launch: true, shake: 15, arc: '#ffb347', frames: ['p0', 'j3', 'p4', 'p5', 'p5', 'p4', 'p2'] }),
    'LLL': mv({ name: 'KICK STORM', dur: 0.5, dmg: 24, hit: [0.2, 0.85], cancel: 0.64, reach: 104, y: 40, h: 46, lunge: 48, kb: 260, shake: 8, spin: true, arc: '#7dd3fc', frames: ['k2', 'k3', 'k2', 'k3', 'k3', 'k2'] })
};
// Đòn thứ 3 mặc định (khi chuỗi chưa có tên riêng) — theo phím cuối
const COMBO_FALLBACK3 = {
    'J': mv({ name: 'FLURRY', dur: 0.34, dmg: 18, hit: [0.25, 0.65], cancel: 0.5, reach: 80, lunge: 48, kb: 190, shake: 6, frames: ['p1', 'p3', 'p4', 'p5', 'p6'] }),
    'H': mv({ name: 'HEAVY FINISH', dur: 0.5, dmg: 28, hit: [0.3, 0.7], cancel: 0.62, reach: 90, lunge: 60, kb: 320, stun: 0.5, mp: 5, shake: 12, arc: '#ff8a3d', frames: ['p0', 'p3', 'p4', 'p5', 'p5', 'p5', 'p2'] }),
    'L': mv({ name: 'RISING KICK', dur: 0.46, dmg: 24, hit: [0.28, 0.72], cancel: 0.6, reach: 98, y: 34, h: 52, lunge: 36, kb: 260, stun: 0.5, hop: 200, launch: true, shake: 9, arc: '#7dd3fc', frames: ['k1', 'k2', 'k3', 'k3', 'j4', 'k4'] })
};
// Đòn thứ 4 = FINISHER (theo phím cuối) — kết thúc chuỗi
const COMBO_FINALE = {
    'J': mv({ name: 'UPPERCUT!', dur: 0.56, dmg: 30, hit: [0.3, 0.7], cancel: 9, reach: 80, y: 8, h: 80, lunge: 26, kb: 200, stun: 0.7, mp: 8, hop: 380, launch: true, shake: 14, arc: '#ffd45a', frames: ['p0', 'j2', 'j3', 'j3', 'j4', 'j4'] }),
    'H': mv({ name: 'MEME SLAM!', dur: 0.64, dmg: 40, hit: [0.35, 0.75], cancel: 9, reach: 104, y: 20, h: 70, lunge: 50, kb: 420, stun: 0.7, mp: 8, shake: 20, arc: '#ff5a5a', frames: ['p0', 'j3', 'j3', 'p4', 'p5', 'p5', 'p2'] }),
    'L': mv({ name: 'DRAGON KICK!', dur: 0.6, dmg: 36, hit: [0.3, 0.8], cancel: 9, reach: 122, y: 18, h: 72, lunge: 44, kb: 400, stun: 0.7, mp: 8, hop: 320, launch: true, shake: 18, lean: -0.12, arc: '#7dd3fc', frames: ['k1', 'k2', 'k3', 'k3', 'k3', 'j5', 'k4'] })
};
// Chuỗi 4 đòn có tên riêng
COMBO_MOVES['JJHL'] = mv({ name: 'BRAZILIAN FINISH!!', dur: 0.72, dmg: 48, hit: [0.2, 0.85], cancel: 9, reach: 132, y: 14, h: 80, lunge: 40, kb: 460, stun: 0.8, mp: 12, hop: 360, launch: true, shake: 24, spin: true, arc: '#ff6ec7', frames: ['d1', 'd2', 'd3', 'k3', 'k3', 'k3', 'd4'] });
// Danh sách hiển thị trong bảng hướng dẫn
const COMBO_LIST = [
    ['J J J J', 'Jab › Cross › Hook › Uppercut'],
    ['J J L', 'Jab › Cross › Tornado Kick'],
    ['J J H L', 'Brazilian Finish (chiêu mạnh nhất)'],
    ['J H L', 'Straight › Ricardo Special (hất tung)'],
    ['H H H', 'Triple Smash (hất tung)'],
    ['L L L', 'Kick Storm (xoay tròn)'],
    ['L H', 'Axe Kick (bổ chân)'],
    ['J L H', 'Jab-Kick › Smash › Meme Slam']
];

// ============================================================
// RIG / POSES / FX / PLAYER / ENEMIES / COMBAT (module chiến đấu mới)
// ============================================================
// ============================================================
// HEADS — ảnh đầu meme (cắt từ ảnh người dùng cung cấp: Ricardo, Gigachad, Trollface, Swole Doge)
// ============================================================
const Heads = {
    imgs: {}, whites: {},
    load(base, names) {
        for (const n of names) {
            const im = new Image();
            im.onerror = () => { im._failed = true; };     // thiếu file -> dùng hình vẽ dự phòng, không crash
            im.src = `${base}${n}.png`;
            this.imgs[n] = im;
        }
    },
    get(n) { const im = this.imgs[n]; return (im && im.complete && im.naturalWidth && !im._failed) ? im : null; }
};

// ============================================================
// RIG — nhân vật dạng "rối giấy" có xương: thân, đầu, 2 tay (2 khúc), 2 chân (2 khúc), bàn chân.
// Tay/chân dùng IK 2 khúc nên bàn chân luôn đặt đúng vị trí mục tiêu (không bao giờ mất chân / chìm xuống đất).
// Toạ độ thiết kế: gốc (0,0) = mặt đất giữa hai bàn chân, x dương = hướng đang nhìn, y âm = lên trên.
// ============================================================
const POSE0 = {
    h: 0.98, bx: 0, by: 0, tilt: 0, head: 0, lean: 0, sx: 1, sy: 1, flex: 0,
    hf: [4, 46], hb: [-4, 46], ff: [18, 0], fb: [-16, 0], face: 'normal'
};
function ik2(ax, ay, tx, ty, l1, l2, pref) {
    let dx = tx - ax, dy = ty - ay, d = Math.hypot(dx, dy);
    const maxd = l1 + l2 - 0.01, mind = Math.abs(l1 - l2) + 0.5;
    if (d > maxd) { const k = maxd / d; dx *= k; dy *= k; d = maxd; }
    else if (d < mind) { if (d < 0.001) { dx = 0; dy = mind; } else { const k = mind / d; dx *= k; dy *= k; } d = mind; }
    const a0 = Math.atan2(dy, dx);
    const A = Math.acos(clamp((l1 * l1 + d * d - l2 * l2) / (2 * l1 * d), -1, 1));
    const c1 = { x: ax + Math.cos(a0 + A) * l1, y: ay + Math.sin(a0 + A) * l1 };
    const c2 = { x: ax + Math.cos(a0 - A) * l1, y: ay + Math.sin(a0 - A) * l1 };
    // chọn nghiệm theo ưu tiên: 'down' = khuỷu thấp hơn, 'fwd' = đầu gối hướng về phía trước
    const pickFirst = pref === 'down' ? c1.y >= c2.y : c1.x >= c2.x;
    return { j: pickFirst ? c1 : c2, e: { x: ax + dx, y: ay + dy } };
}
function lerpPose(a, b, t) {
    const o = {};
    for (const k in POSE0) {
        const va = a[k] !== undefined ? a[k] : POSE0[k], vb = b[k] !== undefined ? b[k] : POSE0[k];
        if (Array.isArray(POSE0[k])) o[k] = [va[0] + (vb[0] - va[0]) * t, va[1] + (vb[1] - va[1]) * t];
        else if (typeof POSE0[k] === 'number') o[k] = va + (vb - va) * t;
        else o[k] = t < 0.5 ? va : vb;
    }
    return o;
}
const RIG_STYLES = {
    ricardo: { name: 'RICARDO MILOS', pixel: true, scale: 0.74, thigh: 40, shin: 40, torso: 46, neck: 6, shW: 50, ww: 15, cw: 27, hipW: 18,
        upperArm: 28, foreArm: 26, armW: 16, foreW: 13, thighW: 18, shinW: 13,
        skin: '#c98a5b', shade: '#a96d43', hi: '#e8ae7c', outline: '#2a160c', outfit: 'bare',
        pants: '#1f4fa8', pantsHi: '#3b74d8', shorts: true, belt: '#f5c542', shoe: '#d62839', sole: '#f1f1f1',
        headKey: 'ricardo', headSize: 60, headHurt: 'ricardo_hurt', headSide: 'ricardo_side', headOy: 4, aura: '#ffd45a' },
    chad: { name: 'GIGACHAD', scale: 0.98, thigh: 42, shin: 42, torso: 52, neck: 8, shW: 64, ww: 18, cw: 34, hipW: 22,
        upperArm: 32, foreArm: 28, armW: 21, foreW: 17, thighW: 22, shinW: 15,
        skin: '#cfcfcf', shade: '#9a9a9a', hi: '#f0f0f0', outline: '#101010', outfit: 'bare',
        pants: '#18181c', pantsHi: '#34343c', shorts: false, belt: '#d4af37', shoe: '#0d0d0d', sole: '#444',
        headKey: 'chad', headFlip: true, headSize: 66, headOy: 6, aura: '#e5e7eb', sprite: 'chad' },
    troll: { name: 'TROLLFACE', pixel: 'troll', scale: 0.74, thigh: 34, shin: 34, torso: 40, neck: 2, shW: 36, ww: 13, cw: 19, hipW: 14,
        upperArm: 24, foreArm: 22, armW: 11, foreW: 9, thighW: 12, shinW: 9,
        skin: '#f1f1f1', shade: '#bbbbbb', hi: '#ffffff', outline: '#0c0c0c', outfit: 'hoodie',
        cloth: '#6d28d9', clothHi: '#8b5cf6', pants: '#16161a', pantsHi: '#2a2a32', shorts: false, shoe: '#f43f5e', sole: '#fff',
        headKey: 'troll', headSize: 78, headOy: 10, aura: '#a78bfa' },
    wojak: { name: 'NPC WOJAK', pixel: 'wojak', scale: 0.8, thigh: 38, shin: 38, torso: 44, neck: 5, shW: 40, ww: 15, cw: 21, hipW: 16,
        upperArm: 27, foreArm: 25, armW: 12, foreW: 10, thighW: 14, shinW: 11,
        skin: '#b9b9be', shade: '#8f8f96', hi: '#d6d6da', outline: '#16161a', outfit: 'shirt',
        cloth: '#9ca3af', clothHi: '#d1d5db', pants: '#3b4a63', pantsHi: '#5b6e8c', shorts: false, shoe: '#e5e7eb', sole: '#6b7280',
        headKey: 'npc', headSize: 54, headOy: 3, aura: '#9ca3af' },
    dancer: { name: 'DANCING MEME', pixel: 'dancer', scale: 0.8, thigh: 40, shin: 40, torso: 44, neck: 5, shW: 42, ww: 14, cw: 22, hipW: 16,
        upperArm: 27, foreArm: 25, armW: 13, foreW: 11, thighW: 14, shinW: 11,
        skin: '#d6a070', shade: '#b07a4d', hi: '#efc193', outline: '#241018', outfit: 'disco',
        cloth: '#a21caf', clothHi: '#f0abfc', pants: '#fbbf24', pantsHi: '#fde68a', flare: true, shorts: false, shoe: '#f472b6', sole: '#fff',
        headKey: 'disco', headSize: 62, headOy: 8, aura: '#f0abfc' },
    sigma: { name: 'SIGMA MEME', pixel: 'sigma', scale: 0.84, thigh: 42, shin: 42, torso: 48, neck: 6, shW: 46, ww: 15, cw: 24, hipW: 17,
        upperArm: 29, foreArm: 27, armW: 13, foreW: 11, thighW: 15, shinW: 12,
        skin: '#c8c8cc', shade: '#8d8d95', hi: '#e8e8ec', outline: '#0a0a0e', outfit: 'suit',
        cloth: '#17171d', clothHi: '#34343f', pants: '#17171d', pantsHi: '#34343f', shorts: false, shoe: '#050507', sole: '#2a2a33',
        headKey: 'sigma', headSize: 56, headOy: 4, aura: '#cbd5e1' },
    lord: { name: 'ULTIMATE MEME LORD', scale: 1.5, thigh: 42, shin: 42, torso: 54, neck: 4, shW: 62, ww: 18, cw: 33, hipW: 22,
        upperArm: 32, foreArm: 30, armW: 20, foreW: 17, thighW: 21, shinW: 16,
        skin: '#e8c15a', shade: '#b8902a', hi: '#fff0a8', outline: '#2a1a05', outfit: 'armor',
        cloth: '#d4a017', clothHi: '#ffe27a', pants: '#5b1580', pantsHi: '#8b3fb8', shorts: false, shoe: '#d4a017', sole: '#5b1580',
        headKey: 'troll', headSize: 64, headOy: 8, aura: '#fbbf24', crown: true, cape: '#7a0f2e', sprite: 'lord' }
};
function _limb(ctx, a, j, e, w1, w2, color, outline) {
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.strokeStyle = outline;
    ctx.lineWidth = w1 + 4; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(j.x, j.y); ctx.stroke();
    ctx.lineWidth = w2 + 4; ctx.beginPath(); ctx.moveTo(j.x, j.y); ctx.lineTo(e.x, e.y); ctx.stroke();
    ctx.strokeStyle = color;
    ctx.lineWidth = w1; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(j.x, j.y); ctx.stroke();
    ctx.lineWidth = w2; ctx.beginPath(); ctx.moveTo(j.x, j.y); ctx.lineTo(e.x, e.y); ctx.stroke();
}
const Rig = {
    _buf: null,
    // Vẽ trực tiếp (không có hiệu ứng nháy trắng). o = {x, y, facing, scale, alpha, t}
    render(ctx, st, pose, o) {
        if (st.pixel === true && o.spr && RicardoSprite.render(ctx, st, pose, o)) return;      // Ricardo dạng sprite (khung hình)
        if (st.sprite === 'chad' && o.spr && ChadSprite.render(ctx, st, pose, o)) return;     // Gigachad dạng sprite (khung hình)
        if (st.sprite === 'lord' && o.spr && LordSprite.render(ctx, st, pose, o)) return;     // Trollface Meme Lord dạng sprite (khung hình)
        if (st.pixel && (PIXEL_PUPPETS[st.pixel] || (st.pixel === 'troll' ? TrollPuppet : RicardoPuppet)).render(ctx, st, pose, o)) return;     // Ricardo pixel-art (nếu ảnh đã tải)
        const P = Object.assign({}, POSE0, pose);
        const S = st.scale * (o.scale || 1), t = o.t || 0;
        const leg = st.thigh + st.shin;
        ctx.save();
        ctx.translate(o.x, o.y);
        ctx.scale((o.facing < 0 ? -1 : 1) * S * P.sx, S * P.sy);
        if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
        const px = P.bx, py = -(leg * P.h) + P.by;
        if (P.lean) { ctx.translate(px, py - st.torso * 0.4); ctx.rotate(P.lean); ctx.translate(-px, -(py - st.torso * 0.4)); }
        const ct = Math.cos(P.tilt), sn = Math.sin(P.tilt);
        const rot = (x, y) => ({ x: px + x * ct - y * sn, y: py + x * sn + y * ct });
        const shF = rot(st.shW / 2 - 3, -st.torso + 4), shB = rot(-st.shW / 2 + 3, -st.torso + 4);
        const neckBase = rot(0, -st.torso), neckTop = rot(0, -st.torso - st.neck);
        const hipF = { x: px + st.hipW / 2, y: py + 3 }, hipB = { x: px - st.hipW / 2, y: py + 3 };
        const lf = ik2(hipF.x, hipF.y, P.ff[0], P.ff[1] - 2, st.thigh, st.shin, 'fwd');
        const lb = ik2(hipB.x, hipB.y, P.fb[0], P.fb[1] - 2, st.thigh, st.shin, 'fwd');
        const af = ik2(shF.x, shF.y, shF.x + P.hf[0], shF.y + P.hf[1], st.upperArm, st.foreArm, 'down');
        const ab = ik2(shB.x, shB.y, shB.x + P.hb[0], shB.y + P.hb[1], st.upperArm, st.foreArm, 'down');
        const ol = st.outline;
        // ---- hào quang phía sau ----
        if (P.mirror !== undefined && P.mirror !== 1) { ctx.translate(px, 0); ctx.scale(P.mirror, 1); ctx.translate(-px, 0); }
        if (o.aura) {
            ctx.save(); ctx.globalCompositeOperation = 'lighter';
            const g = ctx.createRadialGradient(px, py - 40, 10, px, py - 40, 140);
            g.addColorStop(0, o.aura + 'aa'); g.addColorStop(1, o.aura + '00');
            ctx.fillStyle = g; ctx.fillRect(px - 150, py - 190, 300, 300); ctx.restore();
        }
        // ---- áo choàng (boss) ----
        if (st.cape) {
            ctx.fillStyle = st.cape; ctx.strokeStyle = ol; ctx.lineWidth = 3;
            const sw = Math.sin(t * 3) * 6;
            ctx.beginPath(); ctx.moveTo(shB.x - 4, shB.y); ctx.lineTo(shF.x + 4, shF.y);
            ctx.quadraticCurveTo(shF.x + 40 + sw, py - 10, px - 30 + sw * 2, -4); ctx.lineTo(px - 70 + sw * 2, -6);
            ctx.quadraticCurveTo(px - 52, py - 20, shB.x - 4, shB.y); ctx.closePath(); ctx.fill(); ctx.stroke();
        }
        const legColor = (st.shorts ? st.skin : st.pants), thighColor = st.pants;
        // ---- chân sau, chân trước ----
        const drawLeg = (hip, l, back) => {
            const col = back ? st.shade : legColor;
            _limb(ctx, hip, l.j, l.e, st.thighW, st.shinW, st.shorts ? st.skin : thighColor, ol);
            if (st.shorts) {   // ống quần short che nửa đùi
                const mx = hip.x + (l.j.x - hip.x) * 0.62, my = hip.y + (l.j.y - hip.y) * 0.62;
                ctx.lineCap = 'round'; ctx.strokeStyle = ol; ctx.lineWidth = st.thighW + 6; ctx.beginPath(); ctx.moveTo(hip.x, hip.y); ctx.lineTo(mx, my); ctx.stroke();
                ctx.strokeStyle = st.pants; ctx.lineWidth = st.thighW + 2; ctx.beginPath(); ctx.moveTo(hip.x, hip.y); ctx.lineTo(mx, my); ctx.stroke();
            }
            if (st.flare) {   // ống loe (disco)
                ctx.fillStyle = st.pants; ctx.strokeStyle = ol; ctx.lineWidth = 3;
                ctx.beginPath(); ctx.moveTo(l.j.x - st.shinW * 0.5, l.j.y + 2); ctx.lineTo(l.e.x - st.shinW * 1.2, l.e.y + 2); ctx.lineTo(l.e.x + st.shinW * 1.2, l.e.y + 2); ctx.lineTo(l.j.x + st.shinW * 0.5, l.j.y + 2); ctx.closePath(); ctx.fill(); ctx.stroke();
            }
            // giày
            const sh = st.shoe;
            ctx.fillStyle = sh; ctx.strokeStyle = ol; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.ellipse(l.e.x + 7, l.e.y - 3, 15, 8, 0, 0, 6.283); ctx.fill(); ctx.stroke();
            ctx.fillStyle = st.sole; ctx.fillRect(l.e.x - 7, l.e.y + 1, 28, 3);
        };
        drawLeg(hipB, lb, true); drawLeg(hipF, lf, false);
        // ---- quần / hông ----
        ctx.fillStyle = st.pants; ctx.strokeStyle = ol; ctx.lineWidth = 3;
        const hw = st.ww + 5;
        ctx.beginPath(); ctx.moveTo(px - hw, py - 10); ctx.lineTo(px + hw, py - 10); ctx.lineTo(px + hw + 3, py + 12); ctx.lineTo(px - hw - 3, py + 12); ctx.closePath(); ctx.fill(); ctx.stroke();
        if (st.belt) { ctx.fillStyle = st.belt; ctx.fillRect(px - hw, py - 12, hw * 2, 5); ctx.fillStyle = '#fff'; ctx.fillRect(px - 3, py - 12, 6, 5); }
        // ---- tay sau ----
        this._arm(ctx, st, shB, ab, true);
        // ---- thân ----
        this._torso(ctx, st, P, px, py, ct, sn, t);
        // ---- cổ + đầu ----
        ctx.lineCap = 'round'; ctx.strokeStyle = ol; ctx.lineWidth = 15; ctx.beginPath(); ctx.moveTo(neckBase.x, neckBase.y); ctx.lineTo(neckTop.x, neckTop.y); ctx.stroke();
        ctx.strokeStyle = st.skin; ctx.lineWidth = 11; ctx.beginPath(); ctx.moveTo(neckBase.x, neckBase.y); ctx.lineTo(neckTop.x, neckTop.y); ctx.stroke();
        this._head(ctx, st, P, neckTop, o);
        // ---- tay trước ----
        this._arm(ctx, st, shF, af, false);
        ctx.restore();
    },
    _arm(ctx, st, sh, a, back) {
        const ol = st.outline, long = st.outfit === 'suit' || st.outfit === 'hoodie' || st.outfit === 'armor' || st.outfit === 'disco';
        const half = st.outfit === 'shirt';
        const base = back ? st.shade : st.skin;
        // khúc trên / dưới
        const cloth = st.cloth;
        const upperCol = (cloth && st.outfit !== 'bare') ? cloth : base;
        const foreCol = (cloth && long) ? cloth : base;
        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.strokeStyle = ol; ctx.lineWidth = st.armW + 4; ctx.beginPath(); ctx.moveTo(sh.x, sh.y); ctx.lineTo(a.j.x, a.j.y); ctx.stroke();
        ctx.lineWidth = st.foreW + 4; ctx.beginPath(); ctx.moveTo(a.j.x, a.j.y); ctx.lineTo(a.e.x, a.e.y); ctx.stroke();
        ctx.strokeStyle = upperCol; ctx.lineWidth = st.armW; ctx.beginPath(); ctx.moveTo(sh.x, sh.y); ctx.lineTo(a.j.x, a.j.y); ctx.stroke();
        ctx.strokeStyle = foreCol; ctx.lineWidth = st.foreW; ctx.beginPath(); ctx.moveTo(a.j.x, a.j.y); ctx.lineTo(a.e.x, a.e.y); ctx.stroke();
        if (st.outfit === 'bare' && !back) {   // vệt sáng cơ bắp
            ctx.strokeStyle = st.hi; ctx.globalAlpha *= 0.55; ctx.lineWidth = 3;
            const mx = (sh.x + a.j.x) / 2, my = (sh.y + a.j.y) / 2;
            ctx.beginPath(); ctx.moveTo(sh.x + 1, sh.y - 2); ctx.lineTo(mx, my - 3); ctx.stroke(); ctx.globalAlpha /= 0.55;
        }
        // bàn tay / nắm đấm
        const hr = st.foreW * 0.62 + 2;
        ctx.fillStyle = (st.outfit === 'armor') ? st.cloth : base; ctx.strokeStyle = ol; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(a.e.x, a.e.y, hr, 0, 6.283); ctx.fill(); ctx.stroke();
        if (st.outfit === 'suit' || st.outfit === 'hoodie') { ctx.fillStyle = '#fff'; ctx.fillRect(a.e.x - hr - 1, a.e.y - hr - 1, 0, 0); }
    },
    _torso(ctx, st, P, px, py, ct, sn, t) {
        const TL = st.torso, ww = st.ww, cw = st.cw, ol = st.outline;
        ctx.save();
        ctx.translate(px, py); ctx.rotate(P.tilt);
        const fl = 1 + P.flex * 0.12;
        const cwf = cw * fl;
        ctx.beginPath();
        ctx.moveTo(-ww, 2);
        ctx.bezierCurveTo(-ww - 2, -TL * 0.3, -cwf - 2, -TL * 0.62, -cwf, -TL + 9);
        ctx.quadraticCurveTo(-cwf, -TL + 1, -cwf + 12, -TL - 1);
        ctx.lineTo(cwf - 12, -TL - 1);
        ctx.quadraticCurveTo(cwf, -TL + 1, cwf, -TL + 9);
        ctx.bezierCurveTo(cwf + 2, -TL * 0.62, ww + 2, -TL * 0.3, ww, 2);
        ctx.closePath();
        const outfit = st.outfit;
        const baseCol = (outfit === 'bare') ? st.skin : st.cloth;
        const g = ctx.createLinearGradient(-cwf, 0, cwf, 0);
        const hiCol = (outfit === 'bare') ? st.hi : st.clothHi, shCol = (outfit === 'bare') ? st.shade : st.cloth;
        g.addColorStop(0, shCol); g.addColorStop(0.35, baseCol); g.addColorStop(0.6, hiCol); g.addColorStop(1, shCol);
        ctx.fillStyle = g; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = ol; ctx.stroke();
        ctx.save(); ctx.clip();
        if (outfit === 'bare') {
            ctx.strokeStyle = st.shade; ctx.lineWidth = 2.5; ctx.lineCap = 'round';
            ctx.beginPath(); ctx.moveTo(0, -TL + 8); ctx.lineTo(0, -TL * 0.12); ctx.stroke();                       // rãnh giữa ngực-bụng
            ctx.beginPath(); ctx.arc(-cwf * 0.45, -TL * 0.62, cwf * 0.42, 0.15, 1.9); ctx.stroke();                 // cơ ngực
            ctx.beginPath(); ctx.arc(cwf * 0.45, -TL * 0.62, cwf * 0.42, 1.2, 2.99); ctx.stroke();
            for (let i = 0; i < 3; i++) { const y = -TL * 0.42 + i * (TL * 0.14); ctx.beginPath(); ctx.moveTo(-ww * 0.7, y); ctx.lineTo(-2, y); ctx.moveTo(2, y); ctx.lineTo(ww * 0.7, y); ctx.stroke(); }
            ctx.fillStyle = st.hi; ctx.globalAlpha = 0.35; ctx.beginPath(); ctx.ellipse(-cwf * 0.45, -TL * 0.7, cwf * 0.28, 5, 0.2, 0, 6.283); ctx.fill(); ctx.globalAlpha = 1;
        } else if (outfit === 'hoodie') {
            ctx.fillStyle = st.clothHi; ctx.globalAlpha = 0.5; ctx.fillRect(-ww * 0.8, -TL * 0.28, ww * 1.6, TL * 0.26); ctx.globalAlpha = 1;
            ctx.strokeStyle = ol; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-ww * 0.8, -TL * 0.28); ctx.lineTo(ww * 0.8, -TL * 0.28); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(-3, -TL + 6); ctx.lineTo(-3, -TL * 0.55); ctx.moveTo(3, -TL + 6); ctx.lineTo(3, -TL * 0.55); ctx.stroke();
            ctx.font = `bold ${Math.round(TL * 0.3)}px Arial`; ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.fillText(':)', 0, -TL * 0.58);
        } else if (outfit === 'shirt') {
            ctx.strokeStyle = ol; ctx.lineWidth = 2; ctx.globalAlpha = 0.5; ctx.beginPath(); ctx.moveTo(-cw, -TL + 12); ctx.quadraticCurveTo(0, -TL + 22, cw, -TL + 12); ctx.stroke(); ctx.globalAlpha = 1;
        } else if (outfit === 'suit') {
            ctx.fillStyle = '#f3f4f6'; ctx.beginPath(); ctx.moveTo(-9, -TL); ctx.lineTo(9, -TL); ctx.lineTo(3, -TL * 0.2); ctx.lineTo(-3, -TL * 0.2); ctx.closePath(); ctx.fill();
            ctx.fillStyle = '#b91c1c'; ctx.beginPath(); ctx.moveTo(-3, -TL + 4); ctx.lineTo(3, -TL + 4); ctx.lineTo(5, -TL * 0.4); ctx.lineTo(0, -TL * 0.25); ctx.lineTo(-5, -TL * 0.4); ctx.closePath(); ctx.fill();
            ctx.strokeStyle = ol; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-9, -TL); ctx.lineTo(-3, -TL * 0.2); ctx.moveTo(9, -TL); ctx.lineTo(3, -TL * 0.2); ctx.stroke();
            ctx.fillStyle = '#e5e7eb'; ctx.font = 'bold 13px Arial'; ctx.textAlign = 'center'; ctx.fillText('\u03A3', -cwf * 0.55, -TL * 0.55);
        } else if (outfit === 'disco') {
            const gl = 0.5 + 0.5 * Math.sin(t * 8);
            for (let i = 0; i < 9; i++) { ctx.fillStyle = `rgba(255,255,255,${0.25 + 0.5 * Math.abs(Math.sin(t * 6 + i))})`; ctx.fillRect(-cwf + (i * 7) % (cwf * 2), -TL + 6 + ((i * 11) % (TL - 10)), 3, 3); }
            ctx.fillStyle = '#fde047'; ctx.fillRect(-cwf, -TL * 0.3, cwf * 2, 4);
            ctx.fillStyle = `rgba(255,240,150,${0.4 + gl * 0.4})`; ctx.beginPath(); ctx.moveTo(-8, -TL); ctx.lineTo(0, -TL * 0.7); ctx.lineTo(8, -TL); ctx.closePath(); ctx.fill();
        } else if (outfit === 'armor') {
            ctx.fillStyle = st.clothHi; ctx.globalAlpha = 0.6; ctx.fillRect(-cwf, -TL * 0.9, cwf * 2, 6); ctx.globalAlpha = 1;
            ctx.strokeStyle = ol; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(0, -TL + 6); ctx.lineTo(0, -TL * 0.1); ctx.stroke();
            ctx.fillStyle = '#e11d48'; ctx.beginPath(); ctx.arc(0, -TL * 0.55, 8, 0, 6.283); ctx.fill(); ctx.stroke();
            ctx.fillStyle = '#fff'; ctx.font = 'bold 10px Arial'; ctx.textAlign = 'center'; ctx.fillText('M', 0, -TL * 0.55 + 3.5);
        }
        ctx.restore();
        if (outfit === 'armor') {   // giáp vai
            ctx.fillStyle = st.cloth; ctx.strokeStyle = ol; ctx.lineWidth = 3;
            for (const sgn of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sgn * (cw - 2), -TL + 6, 15, 10, 0, 0, 6.283); ctx.fill(); ctx.stroke(); }
        }
        ctx.restore();
    },
    _head(ctx, st, P, neckTop, o) {
        const key = P.face === 'hurt' && st.headHurt ? st.headHurt : (P.face === 'side' && st.headSide ? st.headSide : st.headKey);
        let img = Heads.get(key) || Heads.get(st.headKey);
        const hs = st.headSize, ang = P.tilt + P.head;
        const cx = neckTop.x + Math.sin(ang) * hs * 0.42, cy = neckTop.y - Math.cos(ang) * hs * 0.42 + (st.headOy || 0) * 0.3;
        ctx.save(); ctx.translate(cx, cy); ctx.rotate(ang);
        if (st.crown) {   // vương miện boss
            ctx.fillStyle = '#ffd45a'; ctx.strokeStyle = st.outline; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.moveTo(-24, -hs * 0.42); ctx.lineTo(-30, -hs * 0.42 - 26); ctx.lineTo(-14, -hs * 0.42 - 12); ctx.lineTo(0, -hs * 0.42 - 32); ctx.lineTo(14, -hs * 0.42 - 12); ctx.lineTo(30, -hs * 0.42 - 26); ctx.lineTo(24, -hs * 0.42); ctx.closePath(); ctx.fill(); ctx.stroke();
        }
        if (img) {
            const ar = img.naturalWidth / img.naturalHeight;
            let dh = hs, dw = dh * ar;
            if (dw > hs * 1.35) { dw = hs * 1.35; dh = dw / ar; }
            if (st.headFlip) ctx.scale(-1, 1);
            ctx.shadowColor = 'rgba(0,0,0,0.35)'; ctx.shadowBlur = 6;
            ctx.drawImage(img, -dw / 2, -dh / 2, dw, dh);
        } else {   // hình dự phòng nếu thiếu ảnh đầu
            ctx.fillStyle = st.skin; ctx.strokeStyle = st.outline; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.arc(0, 0, hs * 0.4, 0, 6.283); ctx.fill(); ctx.stroke();
            ctx.fillStyle = '#d62839'; ctx.fillRect(-hs * 0.4, -hs * 0.36, hs * 0.8, hs * 0.2);
            ctx.fillStyle = '#111'; ctx.fillRect(-hs * 0.18, -hs * 0.05, 4, 4); ctx.fillRect(hs * 0.1, -hs * 0.05, 4, 4);
        }
        ctx.restore();
    },
    // Vẽ có hiệu ứng nháy trắng (đi qua bộ đệm ngoài màn hình)
    draw(ctx, st, pose, o) {
        if (!o.flash || o.flash <= 0) { this.render(ctx, st, pose, o); return; }
        const BW = 420, BH = 420, OX = 210, OY = 330;
        if (!this._buf) { this._buf = document.createElement('canvas'); this._buf.width = BW; this._buf.height = BH; }
        const b = this._buf, bc = b.getContext('2d');
        bc.setTransform(1, 0, 0, 1, 0, 0); bc.clearRect(0, 0, BW, BH); bc.globalCompositeOperation = 'source-over';
        this.render(bc, st, pose, Object.assign({}, o, { x: OX, y: OY, alpha: undefined }));
        bc.globalCompositeOperation = 'source-atop'; bc.fillStyle = `rgba(255,255,255,${clamp(o.flash, 0, 1) * 0.85})`; bc.fillRect(0, 0, BW, BH);
        ctx.save(); if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
        ctx.drawImage(b, o.x - OX, o.y - OY); ctx.restore();
    },
    // Chụp một nhân vật ra canvas riêng (dùng cho hiệu ứng vỡ, chân dung...)
    snapshot(st, pose, w, h, ox, oy, scale, spr) {
        const c = document.createElement('canvas'); c.width = w; c.height = h;
        this.render(c.getContext('2d'), st, pose, { x: ox, y: oy, facing: 1, scale: scale || 1, spr });
        return c;
    }
};

// ============================================================
// RICARDO PIXEL PUPPET — nhân vật Ricardo pixel-art (ảnh người dùng) tách thành đầu / thân / 2 tay / 2 chân.
// Dùng lại toàn bộ pose của Rig (đòn đánh, chạy, nhảy, skill...) nên mọi chuyển động cũ vẫn hoạt động.
// Mỗi bộ phận là ảnh full-khung 96x237 (nền trong suốt), xoay quanh khớp (toạ độ ảnh).
// ============================================================
const RicardoPuppet = {
    KEYS: ['rp_head', 'rp_torso', 'rp_armBu', 'rp_armBf', 'rp_armFu', 'rp_armFf', 'rp_legBt', 'rp_legBs', 'rp_legFt', 'rp_legFs'],
    BU: 190 / 237,                        // 1 pixel ảnh = BU đơn vị rig (cao ~190 đơn vị, giống Rig cũ)
    // Khớp (toạ độ ảnh 96x237): cổ, vai, khuỷu, hông, gối. rest = góc nghỉ của từng đoạn trong ảnh gốc (rad, 0 = thẳng xuống)
    NECK: [48.2, 32.7], CEN: [48.5, 113.2],
    ARM: {
        B: { sh: [17.7, 49.8], el: [11.5, 88.2], restU: -0.160, restF: -0.053, key: ['rp_armBu', 'rp_armBf'] },
        F: { sh: [82.7, 49.8], el: [86.5, 88.2], restU: 0.099, restF: 0.032, key: ['rp_armFu', 'rp_armFf'] }
    },
    LEG: {
        B: { hip: [34.3, 113.2], kn: [29.8, 153.2], restT: -0.112, restS: -0.047, key: ['rp_legBt', 'rp_legBs'] },
        F: { hip: [62.7, 113.2], kn: [66.0, 153.2], restT: 0.083, restS: 0.077, key: ['rp_legFt', 'rp_legFs'] }
    },
    ready: false, P: null,
    build() {
        if (this.ready) return true;
        const p = {};
        for (const k of this.KEYS) { const im = Heads.get(k); if (!im) return false; p[k] = im; }
        this.P = p; this.ready = true; return true;
    },
    render(ctx, st, pose, o) {
        if (!this.build()) return false;
        const P = Object.assign({}, POSE0, pose), pp = this.P, BU = this.BU, CEN = this.CEN;
        const S = st.scale * (o.scale || 1);
        const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]) * BU;
        const LEGLEN = 122 * BU, c = LEGLEN / 78.4;                  // c: đổi toạ độ Rig cũ -> toạ độ puppet
        ctx.save();
        ctx.translate(o.x, o.y);
        ctx.scale((o.facing < 0 ? -1 : 1) * S * P.sx, S * P.sy);
        if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
        ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
        const px = P.bx, py = -LEGLEN * (P.h / 0.98) + P.by;
        if (P.lean) { const ly = py - 40; ctx.translate(px, ly); ctx.rotate(P.lean); ctx.translate(-px, -ly); }
        if (o.aura) {
            ctx.save(); ctx.globalCompositeOperation = 'lighter';
            const g = ctx.createRadialGradient(px, py - 40, 10, px, py - 40, 140);
            g.addColorStop(0, o.aura + 'aa'); g.addColorStop(1, o.aura + '00');
            ctx.fillStyle = g; ctx.fillRect(px - 150, py - 190, 300, 300); ctx.restore();
        }
        // vẽ 1 bộ phận: đặt khớp (pivot ảnh) tại (wx,wy), xoay ang
        const piece = (img, piv, wx, wy, ang) => {
            ctx.save(); ctx.translate(wx, wy); ctx.rotate(ang); ctx.scale(BU, BU); ctx.drawImage(img, -piv[0], -piv[1]); ctx.restore();
        };
        // ---- chân: IK 2 khúc (đùi + cẳng chân), gối hướng ra trước ----
        const leg = (L, hx, tx, ty) => {
            const l1 = dist(L.hip, L.kn), l2 = LEGLEN - l1;
            const ik = ik2(hx, py, tx * c, ty * c, l1, l2, 'fwd');
            const at = Math.atan2(ik.j.x - hx, ik.j.y - py), as = Math.atan2(ik.e.x - ik.j.x, ik.e.y - ik.j.y);
            piece(pp[L.key[1]], L.kn, ik.j.x, ik.j.y, -(as - L.restS));      // cẳng chân + ủng (dưới)
            piece(pp[L.key[0]], L.hip, hx, py, -(at - L.restT));             // đùi (đè lên gối)
        };
        const hw = 14.2 * BU;
        const lsc = f => f[0] - f[1] * 0.5;                          // chân đá ra trước / giơ cao thì vẽ sau (nằm trên)
        if (lsc(P.fb) > lsc(P.ff) + 8) { leg(this.LEG.F, px + hw, P.ff[0], P.ff[1] - 2); leg(this.LEG.B, px - hw, P.fb[0], P.fb[1] - 2); }
        else { leg(this.LEG.B, px - hw, P.fb[0], P.fb[1] - 2); leg(this.LEG.F, px + hw, P.ff[0], P.ff[1] - 2); }
        // ---- vai theo thân nghiêng (tilt quanh hông) ----
        const ct = Math.cos(P.tilt), sn = Math.sin(P.tilt);
        const shoulder = A => {
            const ox = (A.sh[0] - CEN[0]) * BU, oy = (A.sh[1] - CEN[1]) * BU;
            return { x: px + ox * ct - oy * sn, y: py + ox * sn + oy * ct };
        };
        // ---- tay: IK 2 khúc (bắp tay + cẳng tay), khuỷu hướng xuống ----
        const sm = v => v * v * (3 - 2 * v);
        const HANG = { B: [-7.0, 68.9], F: [4.2, 68.9] };            // vị trí bàn tay khi buông thả (theo ảnh gốc)
        const arm = (A, h) => {
            const sh = shoulder(A), l1 = dist(A.sh, A.el), l2 = 38.2;
            const hg = A === this.ARM.B ? HANG.B : HANG.F;
            const hx = hg[0] * ct - hg[1] * sn, hy = hg[0] * sn + hg[1] * ct;     // buông thả, xoay theo thân
            // pose chỉ giơ/vươn tay khi bàn tay thật sự rời khỏi vai (đấm, đỡ, giơ cao...), còn lại tay thả tự nhiên
            const reach = Math.hypot(h[0], h[1]), ext = sm(clamp((reach / 54 - 0.5) / 0.45, 0, 1));
            const tx = hx + (h[0] * c - hx) * ext, ty = hy + (h[1] * c - hy) * ext;
            const ik = ik2(sh.x, sh.y, sh.x + tx, sh.y + ty, l1, l2, 'down');
            const au = Math.atan2(ik.j.x - sh.x, ik.j.y - sh.y), af = Math.atan2(ik.e.x - ik.j.x, ik.e.y - ik.j.y);
            piece(pp[A.key[1]], A.el, ik.j.x, ik.j.y, -(af - A.restF));      // cẳng tay
            piece(pp[A.key[0]], A.sh, sh.x, sh.y, -(au - A.restU));          // bắp tay
        };
        const asc = h => h[0] - h[1] * 0.3;                          // tay đang vươn ra (đấm) thì vẽ sau thân (nằm trên)
        const backOnTop = asc(P.hb) > asc(P.hf) + 8;
        if (backOnTop) arm(this.ARM.F, P.hf); else arm(this.ARM.B, P.hb);
        // ---- thân + đầu ----
        ctx.save(); ctx.translate(px, py); ctx.rotate(P.tilt); ctx.scale(BU, BU); ctx.translate(-CEN[0], -CEN[1]);
        ctx.save();
        if (P.flex) { ctx.translate(48, 62); ctx.scale(1 + P.flex * 0.07, 1 + P.flex * 0.025); ctx.translate(-48, -62); }
        ctx.drawImage(pp.rp_torso, 0, 0);
        ctx.restore();
        ctx.translate(this.NECK[0], this.NECK[1]); ctx.rotate(P.head); ctx.drawImage(pp.rp_head, -this.NECK[0], -this.NECK[1]);
        ctx.restore();
        if (backOnTop) arm(this.ARM.B, P.hb); else arm(this.ARM.F, P.hf);
        ctx.restore();
        return true;
    }
};

// ============================================================
// RICARDO SPRITE — Ricardo pixel-art dạng KHUNG HÌNH (sprite sheet mới: idle / walk / run / jump / attack / hurt / skill).
// Mỗi khung là 1 file PNG trong assets/sprites/ricardo/ (đã cắt từ sprite sheet), toạ độ neo (ax, ay) = giữa hông / đáy ủng
// nằm trong assets/sprites/ricardo_meta.js. Nếu thiếu file thì tự quay về RicardoPuppet (rối xương) như cũ.
// Chọn khung theo trạng thái ở Player._sprite(); menu / cutscene dùng RicardoSprite.idle(t) / .dance(t).
// ============================================================
const RicardoSprite = {
    BASE: 'assets/sprites/ricardo/',
    U: 0.88,                                  // 1 pixel ảnh = U đơn vị rig (khớp chiều cao rối xương cũ ~190 đơn vị)
    RUN_N: 12, RUN_K: 30 / 20,                // chạy nhanh: 12 khung / chu kỳ, ~30 khung/giây (runPhase tăng 20/giây khi chạy)
    WALK_N: 12, WALK_K: 24 / 13,              // dáng đi: 12 khung / chu kỳ 2 bước, ~24 khung/giây (runPhase tăng 13/giây khi đi bộ)
    imgs: null, meta: null,
    load() {
        if (this.imgs) return true;
        if (typeof RICARDO_SPRITE_META === 'undefined') return false;
        this.meta = RICARDO_SPRITE_META; this.imgs = {};
        for (const k in this.meta) {
            const im = new Image(); im.onerror = () => { im._failed = true; };
            im.src = `${this.BASE}${k}.png`; this.imgs[k] = im;
        }
        return true;
    },
    ok(k) { const im = this.imgs && this.imgs[k]; return !!(im && im.complete && im.naturalWidth && !im._failed); },
    // chuyển tiếp mượt giữa hai khung: a -> b theo tiến độ p (0..1)
    bl(a, b, p, extra) { p = Math.max(0, Math.min(1, p)); return Object.assign({ k: a, k2: b, b: p * p * (3 - 2 * p) }, extra || {}); },
    idle(t) { return { k: 'idle_' + [0, 1, 2, 3, 2, 1][Math.floor(t * 5) % 6] }; },
    // điệu nhảy meme: nhịp 0.5s, đổi dáng + lật hướng mỗi nhịp, nảy lên xuống
    dance(t) {
        const beat = t / 0.5, i = Math.floor(beat), ph = beat - i;
        const seq = ['skill_0', 'attack_0', 'skill_0', 'attack_3'];
        return { k: seq[i % 4], fl: i % 2 === 1, by: -Math.abs(Math.sin(Math.PI * ph)) * 12, rot: Math.sin(Math.PI * beat) * 0.09 };
    },
    render(ctx, st, pose, o) {
        const sp = o.spr;
        if (!sp || !this.load() || !this.ok(sp.k)) return false;
        const im = this.imgs[sp.k], m = this.meta[sp.k];
        const P = Object.assign({}, POSE0, pose || {});
        const S0 = st.scale * (o.scale || 1), S = S0 * this.U;
        ctx.save();
        ctx.translate(o.x, o.y);
        if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
        if (o.aura) {
            ctx.save(); ctx.scale(S0, S0); ctx.globalCompositeOperation = 'lighter';
            const g = ctx.createRadialGradient(0, -130, 10, 0, -130, 140);
            g.addColorStop(0, o.aura + 'aa'); g.addColorStop(1, o.aura + '00');
            ctx.fillStyle = g; ctx.fillRect(-150, -280, 300, 300); ctx.restore();
        }
        ctx.translate(0, (sp.by || 0) * S0);
        const mir = (sp.fl ? -1 : 1) * (o.facing < 0 ? -1 : 1);      // KHÔNG dùng P.mirror: đòn đánh luôn quay mặt cùng một hướng
        ctx.scale(mir * S * (sp.sx || 1), S * (sp.sy || 1));
        ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
        if (sp.rot) {
            const py = sp.feet ? 0 : -m.ay * 0.5;                 // xoay quanh giữa thân (hoặc quanh bàn chân khi ngã)
            ctx.translate(0, py); ctx.rotate(sp.rot); ctx.translate(0, -py);
            if (sp.lift) ctx.translate(0, -sp.lift * clamp(Math.abs(sp.rot) / 1.45, 0, 1));
        }
        if (sp.k2 && sp.b > 0.004 && this.ok(sp.k2)) {          // hòa trộn mượt sang khung kế tiếp (cross-fade)
            const m2 = this.meta[sp.k2];
            ctx.save(); ctx.globalAlpha *= 1 - Math.max(0, sp.b - 0.5) * 2; ctx.drawImage(im, -m.ax, -m.ay); ctx.restore();
            ctx.save(); ctx.globalAlpha *= Math.min(1, sp.b * 2); ctx.drawImage(this.imgs[sp.k2], -m2.ax, -m2.ay); ctx.restore();
        } else ctx.drawImage(im, -m.ax, -m.ay);
        ctx.restore();
        return true;
    }
};
// ============================================================
// CHAD SPRITE — Gigachad pixel-art dạng KHUNG HÌNH, cùng cách làm với RicardoSprite (dùng chung hàm render()).
// Khung nằm ở assets/sprites/chad/ (idle_0-3, walk_0-3, run_0-2, jump_0-3, attack_0-2, hurt_0-2, skill_0-2, fx_*),
// toạ độ neo (ax, ay) = giữa hông / đáy bàn chân trong assets/sprites/chad_meta.js. Thiếu file thì tự quay về khung xương cũ.
// ============================================================
const ChadSprite = Object.assign(Object.create(RicardoSprite), {
    BASE: 'assets/sprites/chad/',
    U: 0.9,                                   // cao ~232px ảnh x 0.82 (scale ChadEnemy) x 0.9 ≈ 171 = chiều cao hitbox
    imgs: null, meta: null,
    load() {
        if (this.imgs) return true;
        if (typeof CHAD_SPRITE_META === 'undefined') return false;
        this.meta = CHAD_SPRITE_META; this.imgs = {};
        for (const k in this.meta) {
            const im = new Image(); im.onerror = () => { im._failed = true; };
            im.src = `${this.BASE}${k}.png`; this.imgs[k] = im;
        }
        return true;
    },
    idle(t) { return { k: 'idle_' + [0, 1, 2, 1][Math.floor(t * 3.2) % 4] }; },
    walk(t, rate) { return { k: 'walk_' + (Math.floor(t * (rate || 7)) % 4) }; },
    run(t, rate) { return { k: 'run_' + (Math.floor(t * (rate || 9)) % 3) }; },
    // vẽ một khung hiệu ứng (fx_*) neo theo (x, y) màn hình
    fx(ctx, key, x, y, s, alpha, flip) {
        if (!this.load() || !this.ok(key)) return;
        const im = this.imgs[key], m = this.meta[key];
        ctx.save(); ctx.translate(x, y); ctx.globalAlpha *= alpha; ctx.scale((flip ? -1 : 1) * s, s);
        ctx.imageSmoothingEnabled = true; ctx.drawImage(im, -m.ax, -m.ay); ctx.restore();
    }
});
// ============================================================
// LORD SPRITE — Trollface "Ultimate Meme Lord" pixel-art dạng KHUNG HÌNH (cùng cách làm với Ricardo / Gigachad).
// Khung ở assets/sprites/lord/: idle_0-4, walk_0-5, run_0-3, jump_0-3, attack_0-2, hurt_0-2, skill_0-2 (niệm phép / cầu ma thuật / lao tới),
// FX: fx_slash, fx_beam, fx_circle (trận pháp), fx_pillar (cột sét), fx_burst (nổ đất), portrait. Neo (ax, ay) trong assets/sprites/lord_meta.js.
// ============================================================
const LordSprite = Object.assign(Object.create(RicardoSprite), {
    BASE: 'assets/sprites/lord/',
    U: 1.05,                                  // cao ~195px ảnh x 1.05 x style.scale 1.1 ≈ 225 = chiều cao hitbox boss
    imgs: null, meta: null,
    load() {
        if (this.imgs) return true;
        if (typeof LORD_SPRITE_META === 'undefined') return false;
        this.meta = LORD_SPRITE_META; this.imgs = {};
        for (const k in this.meta) {
            const im = new Image(); im.onerror = () => { im._failed = true; };
            im.src = `${this.BASE}${k}.png`; this.imgs[k] = im;
        }
        return true;
    },
    // Hoạt ảnh mượt: mỗi khung được hòa trộn (cross-fade) sang khung kế tiếp theo pha liên tục thay vì nhảy khung.
    cyc(seq, f, extra) { const n = seq.length, i = Math.floor(f), b = f - i; return Object.assign({ k: seq[((i % n) + n) % n], k2: seq[(((i + 1) % n) + n) % n], b }, extra || {}); },
    idle(t) { return this.cyc(['idle_0', 'idle_1', 'idle_2', 'idle_3', 'idle_4', 'idle_3', 'idle_2', 'idle_1'], t * 3.6, { by: Math.sin(t * 2.2) * 1.2 }); },
    // pha đi bộ tính theo QUÃNG ĐƯỜNG đã đi (dist, px) nên chân không bị trượt / đứng hình khi tốc độ đổi
    walk(dist) { const f = dist / 19; return this.cyc(['walk_0', 'walk_1', 'walk_2', 'walk_3', 'walk_4', 'walk_5'], f, { by: -Math.abs(Math.sin(Math.PI * f / 3)) * 3 }); },
    run(dist) { const f = dist / 34; return this.cyc(['run_0', 'run_1', 'run_2', 'run_3'], f, { by: -Math.abs(Math.sin(Math.PI * f / 2)) * 4 }); },
    // chuyển tiếp giữa hai khung: a -> b theo tiến độ p (0..1)
    bl(a, b, p, extra) { return Object.assign({ k: a, k2: b, b: clamp(p, 0, 1) }, extra || {}); },
    render(ctx, st, pose, o) {
        const sp = o.spr;
        if (!sp || !this.load() || !this.ok(sp.k)) return false;
        const list = (sp.k2 && sp.b > 0.004 && this.ok(sp.k2)) ? [[sp.k, 1 - Math.max(0, sp.b - 0.5) * 2], [sp.k2, Math.min(1, sp.b * 2)]] : [[sp.k, 1]];
        const S0 = st.scale * (o.scale || 1), S = S0 * this.U;
        ctx.save();
        ctx.translate(o.x, o.y);
        if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
        if (o.aura) {
            ctx.save(); ctx.scale(S0, S0); ctx.globalCompositeOperation = 'lighter';
            const g = ctx.createRadialGradient(0, -130, 10, 0, -130, 140);
            g.addColorStop(0, o.aura + 'aa'); g.addColorStop(1, o.aura + '00');
            ctx.fillStyle = g; ctx.fillRect(-150, -280, 300, 300); ctx.restore();
        }
        ctx.translate(0, (sp.by || 0) * S0);
        const mir = (sp.fl ? -1 : 1) * (o.facing < 0 ? -1 : 1);
        ctx.scale(mir * S * (sp.sx || 1), S * (sp.sy || 1));
        ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
        if (sp.rot) {
            const py = sp.feet ? 0 : -this.meta[sp.k].ay * 0.5;
            ctx.translate(0, py); ctx.rotate(sp.rot); ctx.translate(0, -py);
            if (sp.lift) ctx.translate(0, -sp.lift * clamp(Math.abs(sp.rot) / 1.45, 0, 1));
        }
        for (const [k, al] of list) {
            if (al <= 0.003) continue;
            const m = this.meta[k]; ctx.save(); ctx.globalAlpha *= al; ctx.drawImage(this.imgs[k], -m.ax, -m.ay); ctx.restore();
        }
        ctx.restore();
        return true;
    },
    // vẽ khung hiệu ứng (fx_*) neo theo (x, y) màn hình, cộng sáng (additive)
    fx(ctx, key, x, y, s, alpha, flip) {
        if (!this.load() || !this.ok(key) || alpha <= 0) return;
        const im = this.imgs[key], m = this.meta[key];
        ctx.save(); ctx.translate(x, y); ctx.globalAlpha *= clamp(alpha, 0, 1); ctx.globalCompositeOperation = 'lighter'; ctx.scale((flip ? -1 : 1) * s, s);
        ctx.imageSmoothingEnabled = true; ctx.drawImage(im, -m.ax, -m.ay); ctx.restore();
    },
    // vẽ khung vừa chiều cao h (cutscene / chụp vỡ điểm ảnh)
    drawFit(ctx, key, x, feetY, h, flip, alpha) {
        if (!this.load() || !this.ok(key)) return false;
        const m = this.meta[key], s = h / 195;
        ctx.save(); ctx.translate(x, feetY); if (alpha !== undefined) ctx.globalAlpha *= alpha; ctx.scale((flip ? -1 : 1) * s, s);
        ctx.imageSmoothingEnabled = true; ctx.drawImage(this.imgs[key], -m.ax, -m.ay); ctx.restore(); return true;
    }
});
// Token tư thế đòn đánh (p* = đấm, k* = đá, d* / j* = đòn đặc biệt) -> khung hình sprite.
// Sprite sheet chưa có khung đá nên đòn đá dùng khung gối co (run_2 / run_3) + khung lao tới.
const SPR_TOK = {
    p0: 'attack_0', p1: 'attack_1', p2: 'attack_2', p3: 'attack_2', p4: 'attack_1', p5: 'attack_2', p6: 'attack_3',
    k0: 'attack_0', k1: 'run_2', k2: 'run_2', k3: 'run_3', k4: 'attack_3',
    d1: 'skill_0', d2: 'skill_1', d3: 'skill_0', d4: 'attack_3',
    j2: 'attack_0', j3: 'attack_0', j4: 'attack_2', j5: 'attack_2'
};

// ============================================================
// TROLL PUPPET — Trollface cơ bắp pixel-art (ảnh người dùng), tách đầu / thân / 2 tay (bắp tay + cẳng tay) / 2 chân (đùi + cẳng chân).
// Cùng cách hoạt động với RicardoPuppet nhưng giữ nguyên dáng gốc của ảnh làm tư thế nghỉ (tay co, chân dang).
// Ảnh bộ phận 200x245 (nền trong suốt); toạ độ khớp tính theo pixel ảnh.
// ============================================================
const TrollPuppet = {
    KEYS: ['tp_head', 'tp_torso', 'tp_armBu', 'tp_armBf', 'tp_armFu', 'tp_armFf', 'tp_legBt', 'tp_legBs', 'tp_legFt', 'tp_legFs'],
    BU: 0.70,                              // 1 pixel ảnh = BU đơn vị rig (cao ~170 đơn vị)
    NECK: [96, 63], CEN: [103, 169],
    ARM: {
        B: { sh: [40, 75], el: [11, 123], hand: [62, 139], key: ['tp_armBu', 'tp_armBf'] },
        F: { sh: [141, 82], el: [152, 134], hand: [193, 132], key: ['tp_armFu', 'tp_armFf'] }
    },
    LEG: {
        B: { hip: [70, 168], kn: [51, 195], foot: [38, 241], key: ['tp_legBt', 'tp_legBs'], stand: -16 },
        F: { hip: [136, 170], kn: [132, 200], foot: [150, 240], key: ['tp_legFt', 'tp_legFs'], stand: 18 }
    },
    ready: false, P: null,
    build() {
        if (this.ready) return true;
        const p = {};
        for (const k of this.KEYS) { const im = Heads.get(k); if (!im) return false; p[k] = im; }
        const ang = (a, b) => Math.atan2(b[0] - a[0], b[1] - a[1]), d = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]) * this.BU;
        for (const A of [this.ARM.B, this.ARM.F]) { A.restU = ang(A.sh, A.el); A.restF = ang(A.el, A.hand); A.l1 = d(A.sh, A.el); A.l2 = d(A.el, A.hand); A.hang = [(A.hand[0] - A.sh[0]) * this.BU, (A.hand[1] - A.sh[1]) * this.BU]; }
        for (const L of [this.LEG.B, this.LEG.F]) {
            // đặt khớp gối nằm trên đường hông -> bàn chân: chân đứng thẳng khớp đúng ảnh, gối chỉ gập khi pose cần
            const vx = L.foot[0] - L.hip[0], vy = L.foot[1] - L.hip[1], k = ((L.kn[0] - L.hip[0]) * vx + (L.kn[1] - L.hip[1]) * vy) / (vx * vx + vy * vy);
            L.kn = [L.hip[0] + vx * k, L.hip[1] + vy * k];
            L.restT = ang(L.hip, L.kn); L.restS = ang(L.kn, L.foot); L.l1 = d(L.hip, L.kn); L.l2 = d(L.kn, L.foot); }
        this.hipH0 = ((this.LEG.B.foot[1] - this.LEG.B.hip[1]) + (this.LEG.F.foot[1] - this.LEG.F.hip[1])) / 2 * this.BU;
        this.cL = this.hipH0 / 78.4;
        this.cA = ((this.ARM.B.l1 + this.ARM.B.l2) + (this.ARM.F.l1 + this.ARM.F.l2)) / 2 / 54;
        this.P = p; this.ready = true; return true;
    },
    render(ctx, st, pose, o) {
        if (!this.build()) return false;
        const P = Object.assign({}, POSE0, pose), pp = this.P, BU = this.BU, CEN = this.CEN, cL = this.cL, cA = this.cA;
        const S = st.scale * (o.scale || 1);
        const sm = v => v * v * (3 - 2 * v);
        ctx.save();
        ctx.translate(o.x, o.y);
        ctx.scale((o.facing < 0 ? -1 : 1) * S * P.sx, S * P.sy);
        if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
        ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
        const px = P.bx, py = -this.hipH0 * (P.h / 0.98) + P.by;
        if (P.lean) { const ly = py - 40; ctx.translate(px, ly); ctx.rotate(P.lean); ctx.translate(-px, -ly); }
        if (P.mirror !== undefined && P.mirror !== 1) { ctx.translate(px, 0); ctx.scale(P.mirror, 1); ctx.translate(-px, 0); }
        if (o.aura) {
            ctx.save(); ctx.globalCompositeOperation = 'lighter';
            const g = ctx.createRadialGradient(px, py - 40, 10, px, py - 40, 140);
            g.addColorStop(0, o.aura + 'aa'); g.addColorStop(1, o.aura + '00');
            ctx.fillStyle = g; ctx.fillRect(px - 150, py - 190, 300, 300); ctx.restore();
        }
        const piece = (img, piv, wx, wy, ang) => {
            ctx.save(); ctx.translate(wx, wy); ctx.rotate(ang); ctx.scale(BU, BU); ctx.drawImage(img, -piv[0], -piv[1]); ctx.restore();
        };
        // ---- chân: IK đùi + cẳng chân; bàn chân mặc định đứng đúng chỗ như ảnh gốc, pose chỉ dịch chuyển so với tư thế đứng ----
        const leg = (L, f) => {
            const hx = px + (L.hip[0] - CEN[0]) * BU, hy = py + (L.hip[1] - CEN[1]) * BU;
            const tx = px + (L.foot[0] - CEN[0]) * BU + (f[0] - L.stand) * cL, ty = (f[1] - 2) * cL;
            const ik = ik2(hx, hy, tx, ty, L.l1, L.l2, 'fwd');
            const at = Math.atan2(ik.j.x - hx, ik.j.y - hy), as = Math.atan2(ik.e.x - ik.j.x, ik.e.y - ik.j.y);
            piece(pp[L.key[1]], L.kn, ik.j.x, ik.j.y, -(as - L.restS));
            piece(pp[L.key[0]], L.hip, hx, hy, -(at - L.restT));
        };
        const lsc = f => f[0] - f[1] * 0.5;
        if (lsc(P.fb) > lsc(P.ff) + 8) { leg(this.LEG.F, P.ff); leg(this.LEG.B, P.fb); } else { leg(this.LEG.B, P.fb); leg(this.LEG.F, P.ff); }
        // ---- vai theo thân nghiêng ----
        const ct = Math.cos(P.tilt), sn = Math.sin(P.tilt);
        const shoulder = A => {
            const ox = (A.sh[0] - CEN[0]) * BU, oy = (A.sh[1] - CEN[1]) * BU;
            return { x: px + ox * ct - oy * sn, y: py + ox * sn + oy * ct };
        };
        // ---- tay: bình thường giữ dáng co tay của ảnh gốc; chỉ vươn/giơ khi pose đưa tay ra khỏi vai ----
        const arm = (A, h) => {
            const sh = shoulder(A);
            const hx = A.hang[0] * ct - A.hang[1] * sn, hy = A.hang[0] * sn + A.hang[1] * ct;
            const reach = Math.hypot(h[0], h[1]), ext = sm(clamp((reach / 54 - 0.5) / 0.45, 0, 1));
            const tx = hx + (h[0] * cA - hx) * ext, ty = hy + (h[1] * cA - hy) * ext;
            const ik = ik2(sh.x, sh.y, sh.x + tx, sh.y + ty, A.l1, A.l2, 'down');
            const au = Math.atan2(ik.j.x - sh.x, ik.j.y - sh.y), af = Math.atan2(ik.e.x - ik.j.x, ik.e.y - ik.j.y);
            piece(pp[A.key[1]], A.el, ik.j.x, ik.j.y, -(af - A.restF));
            piece(pp[A.key[0]], A.sh, sh.x, sh.y, -(au - A.restU));
        };
        const asc = h => h[0] - h[1] * 0.3;
        const backOnTop = asc(P.hb) > asc(P.hf) + 8;
        if (backOnTop) arm(this.ARM.F, P.hf); else arm(this.ARM.B, P.hb);
        // ---- thân + đầu ----
        ctx.save(); ctx.translate(px, py); ctx.rotate(P.tilt); ctx.scale(BU, BU); ctx.translate(-CEN[0], -CEN[1]);
        ctx.save();
        if (P.flex) { const FC = this.FLEXC || [103, 110]; ctx.translate(FC[0], FC[1]); ctx.scale(1 + P.flex * 0.06, 1 + P.flex * 0.02); ctx.translate(-FC[0], -FC[1]); }
        ctx.drawImage(pp[this.KEYS[1]], 0, 0);
        ctx.restore();
        ctx.translate(this.NECK[0], this.NECK[1]); ctx.rotate(P.head); ctx.drawImage(pp[this.KEYS[0]], -this.NECK[0], -this.NECK[1]);
        ctx.restore();
        if (backOnTop) arm(this.ARM.B, P.hb); else arm(this.ARM.F, P.hf);
        ctx.restore();
        return true;
    }
};

// ---- Nhân bản rối pixel-art (cùng cơ chế IK với Troll/Ricardo) cho NPC WOJAK, DANCING MEME, SIGMA MEME ----
// Bộ phận vẽ pixel-art ở assets/heads/{wk,dc,sg}_*.png (khung 200x270, cùng bộ khớp cho cả ba nhân vật).
function makePixelPuppet(prefix) {
    const kk = a => a.map(k => prefix + '_' + k);
    return Object.assign({}, TrollPuppet, {
        KEYS: kk(['head', 'torso', 'armBu', 'armBf', 'armFu', 'armFf', 'legBt', 'legBs', 'legFt', 'legFs']),
        BU: 0.65, NECK: [100, 76], CEN: [100, 160], FLEXC: [100, 110],
        ARM: { B: { sh: [64, 92], el: [52, 132], hand: [50, 168], key: kk(['armBu', 'armBf']) }, F: { sh: [136, 92], el: [148, 132], hand: [150, 168], key: kk(['armFu', 'armFf']) } },
        LEG: { B: { hip: [84, 160], kn: [82, 208], foot: [80, 260], key: kk(['legBt', 'legBs']), stand: -16 }, F: { hip: [116, 160], kn: [118, 208], foot: [120, 260], key: kk(['legFt', 'legFs']), stand: 18 } },
        ready: false, P: null
    });
}
const PIXEL_PUPPETS = { wojak: makePixelPuppet('wk'), dancer: makePixelPuppet('dc'), sigma: makePixelPuppet('sg') };

// ============================================================
// DOGE PUPPET — Swole Doge (ảnh người dùng) tách thành đầu / thân / 2 tay / 2 chân để cử động riêng
// ============================================================
const DogePuppet = {
    ready: false, parts: null,
    build() {
        const im = Heads.get('doge_full');
        if (!im || this.ready) return this.ready;
        const mk = (w, h, fn) => { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); fn(x); return c; };
        const IW = im.naturalWidth, IH = im.naturalHeight;
        const cut = (rx, ry, rw, rh) => mk(rw, rh, x => x.drawImage(im, rx, ry, rw, rh, 0, 0, rw, rh));
        const head = cut(112, 0, 96, 98);
        const armB = cut(0, 140, 102, 190), armF = cut(198, 140, 88, 190);
        const legB = cut(92, 258, 66, IH - 258), legF = cut(152, 258, 56, IH - 258);
        const torso = mk(IW, IH, x => {
            x.drawImage(im, 0, 0);
            x.globalCompositeOperation = 'destination-out';
            x.fillRect(112, 0, 96, 90); x.fillRect(0, 190, 100, IH - 190); x.fillRect(200, 190, 90, IH - 190); x.fillRect(90, 262, 120, IH - 262);
        });
        this.parts = { head, armB, armF, legB, legF, torso, IW, IH };
        this.ready = true; return true;
    },
    // pose: {bx,by,tilt,head,armF,armB,legF,legB,sx,sy}; (x,y)=gốc dưới chân, h = chiều cao vẽ mong muốn
    draw(ctx, pose, o) {
        if (!this.build()) return false;
        const P = Object.assign({ bx: 0, by: 0, tilt: 0, head: 0, armF: 0, armB: 0, legF: 0, legB: 0, sx: 1, sy: 1, lean: 0 }, pose);
        const pr = this.parts, k = (o.h || 130) / pr.IH;
        ctx.save();
        ctx.translate(o.x, o.y); ctx.scale((o.facing < 0 ? -1 : 1) * k * P.sx, k * P.sy);
        if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
        ctx.translate(-pr.IW / 2 + P.bx, -pr.IH + P.by);
        if (P.lean) { ctx.translate(pr.IW / 2, pr.IH * 0.6); ctx.rotate(P.lean); ctx.translate(-pr.IW / 2, -pr.IH * 0.6); }
        if (o.aura) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; const g = ctx.createRadialGradient(pr.IW / 2, pr.IH * 0.5, 10, pr.IW / 2, pr.IH * 0.5, 230); g.addColorStop(0, o.aura + '88'); g.addColorStop(1, o.aura + '00'); ctx.fillStyle = g; ctx.fillRect(-100, -80, pr.IW + 200, pr.IH + 160); ctx.restore(); }
        const part = (img, px, py, ang, dx, dy) => { ctx.save(); ctx.translate(px, py); ctx.rotate(ang); ctx.drawImage(img, dx - px, dy - py); ctx.restore(); };
        part(pr.legB, 125, 266, P.legB, 92, 258);
        part(pr.legF, 180, 266, P.legF, 152, 258);
        part(pr.armB, 52, 150, P.armB, 0, 140);
        part(pr.armF, 240, 150, P.armF, 198, 140);
        ctx.save(); ctx.rotate(P.tilt * 0.4); ctx.drawImage(pr.torso, 0, 0); ctx.restore();
        part(pr.head, 160, 92, P.head + P.tilt * 0.5, 112, 0);
        ctx.restore();
        return true;
    }
};

// ============================================================
// RICARDO POSES — tên token khớp với bảng combo (p=đấm, k=đá, j=nhảy/uppercut, d=nhảy múa)
// hf/hb = vị trí bàn tay trước/sau so với vai; ff/fb = vị trí bàn chân trước/sau so với mặt đất
// ============================================================
const RPOSE = {
    stand: { h: 0.98, hf: [30, -4], hb: [12, 4], ff: [18, 0], fb: [-16, 0] },
    p0: { h: 0.96, tilt: 0.06, hf: [32, -6], hb: [14, 2], ff: [20, 0], fb: [-18, 0] },
    p1: { h: 0.95, tilt: 0.12, hf: [56, -8], hb: [12, 0], ff: [26, 0], fb: [-22, 0] },
    p2: { h: 0.95, tilt: -0.04, hf: [24, 8], hb: [34, -8], ff: [20, 0], fb: [-20, 0] },
    p3: { h: 0.94, tilt: 0.2, head: 0.05, hf: [44, -24], hb: [10, 4], ff: [26, 0], fb: [-22, 0] },
    p4: { h: 0.92, tilt: 0.3, flex: 0.3, hf: [58, -4], hb: [8, 6], ff: [32, 0], fb: [-28, 0] },
    p5: { h: 0.9, tilt: 0.36, hf: [54, 8], hb: [6, 10], ff: [36, 0], fb: [-32, 0] },
    p6: { h: 0.96, tilt: 0.0, hf: [30, 8], hb: [10, 6], ff: [14, 0], fb: [-22, 0] },
    k0: { h: 0.95, tilt: -0.05, hf: [30, -2], hb: [12, 4], ff: [24, -22], fb: [-16, 0] },
    k1: { h: 0.95, tilt: -0.1, hf: [28, 6], hb: [8, -4], ff: [34, -46], fb: [-14, 0] },
    k2: { h: 0.96, tilt: -0.24, head: -0.05, hf: [22, 14], hb: [-8, -10], ff: [70, -64], fb: [-12, 0] },
    k3: { h: 0.96, tilt: -0.32, hf: [16, 22], hb: [-14, -14], ff: [76, -88], fb: [-10, 0] },
    k4: { h: 0.9, tilt: -0.1, hf: [28, 4], hb: [10, 0], ff: [28, -26], fb: [-16, 0] },
    j2: { h: 0.9, tilt: 0.05, hf: [26, -8], hb: [10, 10], ff: [22, 0], fb: [-20, 0] },
    j3: { h: 0.98, tilt: -0.1, hf: [18, -68], hb: [8, -4], ff: [22, -4], fb: [-14, 0] },
    j4: { h: 1, tilt: -0.14, hf: [14, -70], hb: [-6, -64], ff: [20, -30], fb: [-10, -22] },
    j5: { h: 1, tilt: -0.1, hf: [30, 0], hb: [-26, 0], ff: [26, -40], fb: [-24, -44] },
    d1: { h: 0.97, bx: 6, tilt: 0.04, hf: [26, -62], hb: [-14, 14], ff: [22, 0], fb: [-12, -10] },
    d2: { h: 0.97, bx: -4, tilt: -0.06, hf: [8, 16], hb: [26, -60], ff: [16, -10], fb: [-20, 0] },
    d3: { h: 0.92, bx: -6, flex: 0.5, hf: [28, -52], hb: [-2, -54], ff: [26, 0], fb: [-26, 0] },
    d4: { h: 0.9, bx: 8, tilt: 0.2, hf: [42, -8], hb: [-12, -6], ff: [28, 0], fb: [-6, -14] },
    block: { h: 0.8, tilt: 0.12, hf: [24, -30], hb: [14, -32], ff: [22, 0], fb: [-18, 0] },
    perfect: { h: 0.92, tilt: -0.1, flex: 0.8, hf: [44, -26], hb: [-30, -26], ff: [24, 0], fb: [-22, 0] },
    hit: { h: 0.9, tilt: -0.36, head: -0.2, face: 'hurt', hf: [6, -24], hb: [-8, -16], ff: [26, 0], fb: [-26, 0] },
    down: { h: 0.35, lean: -1.5, by: 14, face: 'hurt', hf: [30, 10], hb: [24, 14], ff: [34, -6], fb: [18, -2] },
    dashRun: { h: 0.92, tilt: 0.5, hf: [30, 26], hb: [-10, 36], ff: [-6, -16], fb: [-34, -8] },
    thrustWind: { h: 0.85, tilt: -0.3, flex: 0.4, hf: [-10, 6], hb: [-20, 12], ff: [26, 0], fb: [-30, 0] },
    thrust: { h: 1, tilt: 0.95, flex: 0.4, hf: [60, -10], hb: [54, 2], ff: [-40, -34], fb: [-54, -20] },
    slamWind: { h: 0.62, tilt: 0.5, hf: [20, 20], hb: [10, 24], ff: [28, 0], fb: [-14, 0] },
    slamAir: { h: 1, tilt: 1.0, by: -24, hf: [26, 26], hb: [14, 30], ff: [10, -40], fb: [-10, -50] },
    slam: { h: 0.5, tilt: 0.9, hf: [20, 24], hb: [10, 28], ff: [40, -6], fb: [30, 0] },
    victory: { h: 0.97, flex: 1, hf: [24, -44], hb: [-10, -46], ff: [20, 0], fb: [-18, 0] },
    jumpUp: { h: 0.85, tilt: 0.05, hf: [24, -32], hb: [-6, -36], ff: [20, -46], fb: [-10, -30] },
    jumpFall: { h: 1, hf: [30, -4], hb: [-28, -4], ff: [14, -8], fb: [-12, -16] },
    tuck: { h: 0.7, hf: [10, 10], hb: [0, 14], ff: [10, -40], fb: [-4, -40] },
    chuongGather: { h: 0.88, tilt: -0.08, flex: 0.3, hf: [30, 6], hb: [24, 10], ff: [30, 0], fb: [-30, 0] },
    chuongFire: { h: 0.9, tilt: 0.14, hf: [62, -12], hb: [58, -8], ff: [38, 0], fb: [-34, 0] },
    flexUlt: { h: 0.9, flex: 1, tilt: -0.08, hf: [30, -50], hb: [-8, -52], ff: [26, 0], fb: [-24, 0] }
};
function rpose(token) { return RPOSE[token] || RPOSE.stand; }
// Chu kỳ chạy: pha ph (rad) -> chân/tay luân phiên, thân nghiêng về phía trước
function runPose(ph) {
    const s = Math.sin(ph), c = Math.cos(ph);
    return { h: 0.93, by: -Math.abs(Math.sin(ph)) * 3, tilt: 0.16, hf: [s * 24 + 18, -2 + 6], hb: [-s * 24 + 6, 6],
        ff: [s * 34 + 6, -Math.max(0, c) * 26], fb: [-s * 34 - 6, -Math.max(0, -c) * 26] };
}
function idlePose(t) {
    const b = Math.sin(t * 3);
    return { h: 0.98 - b * 0.01, tilt: 0.03 + b * 0.01, head: b * 0.02, hf: [30, -4 + b * 2], hb: [12, 4 - b * 2], ff: [18, 0], fb: [-16, 0] };
}
function dancePose(t) {
    // Điệu nhảy meme Ricardo: nhịp 0.5s, mỗi động tác = 2 nhịp, 8 động tác = 1 vòng (~8 giây), chuyển động tác mượt.
    const BEAT = 0.5, NM = 8, PI = Math.PI;
    const bt = t / BEAT, mi = Math.floor(bt / 2) % NM, u = (bt % 2) / 2;
    const sw = Math.sin(bt * PI), cw = Math.cos(bt * PI), bn = Math.abs(cw);     // sw: lắc trái/phải mỗi nhịp, bn: nảy gối
    const sm = x => x * x * (3 - 2 * x), mix = (p, q, k) => [p[0] + (q[0] - p[0]) * k, p[1] + (q[1] - p[1]) * k];
    const base = () => ({
        h: 0.96 - bn * 0.05, bx: sw * 8, by: 0, tilt: sw * 0.1, head: -sw * 0.12, flex: 0.3, mirror: 1,
        ff: [18 + sw * 8, -Math.max(0, sw) * 7], fb: [-16 + sw * 8, -Math.max(0, -sw) * 7],
        hf: [10, 30], hb: [-10, 30], face: 'side'
    });
    const move = (i, u) => {
        const o = base(), k = 0.5 + 0.5 * sw;
        switch (i) {
            case 0:   // chỉ trời luân phiên (disco)
                o.hf = mix([10, 24], [26, -62], k); o.hb = mix([-26, -62], [-8, 24], k); break;
            case 1:   // hai tay giơ cao lắc lư
                o.hf = [10 + sw * 14, -62]; o.hb = [-24 + sw * 14, -62]; o.flex = 0.5; break;
            case 2:   // khoe bắp tay đôi, đứng rộng, nảy theo nhịp
                o.hf = [16, -42]; o.hb = [-30, -42]; o.flex = 0.7 + 0.3 * bn; o.h = 0.91 - bn * 0.04;
                o.ff = [26, 0]; o.fb = [-24, 0]; o.bx = sw * 4; o.tilt = sw * 0.04; o.head = 0; break;
            case 3:   // hai tay sau gáy, lắc hông mạnh
                o.hf = [4, -44]; o.hb = [-14, -44]; o.bx = sw * 13; o.tilt = -sw * 0.14; o.head = sw * 0.1;
                o.ff = [26 + sw * 6, 0]; o.fb = [-24 + sw * 6, 0]; o.h = 0.92 - bn * 0.04; break;
            case 4:   // xoay một vòng tại chỗ, nhảy lên
                o.mirror = Math.cos(u * 2 * PI); o.hf = [14, -58]; o.hb = [-24, -58]; o.by = -Math.sin(u * PI) * 16;
                o.ff = [8, -6]; o.fb = [-8, -6]; o.bx = 0; o.tilt = 0; o.head = 0; o.h = 0.98; break;
            case 5: { // ngồi xuống - bật lên 2 lần, tay quét từ dưới lên
                const d = 0.5 - 0.5 * Math.cos(u * 4 * PI);
                o.h = 0.98 - 0.22 * d; o.hf = mix([22, -60], [38, 26], d); o.hb = mix([-30, -60], [-46, 26], d);
                o.ff = [24, 0]; o.fb = [-22, 0]; o.bx = 0; o.tilt = 0; o.head = 0; break; }
            case 6:   // khoe cơ luân phiên từng bên
                o.hf = mix([10, 26], [14, -44], k); o.hb = mix([-28, -44], [-10, 26], k); o.flex = 1; break;
            default:  // vỗ cánh: hai tay dang rộng lên xuống luân phiên
                o.hf = [32, -6 + 38 * sw]; o.hb = [-34, -6 - 38 * sw]; o.flex = 0.5; break;
        }
        return o;
    };
    const a = move(mi, u);
    if (u <= 0.8) return a;
    const w = sm((u - 0.8) / 0.2), b2 = move((mi + 1) % NM, 0), out = lerpPose(a, b2, w);
    out.mirror = a.mirror + (b2.mirror - a.mirror) * w;
    return out;
}

// ============================================================
// FX SYSTEM — vòng năng lượng, tia sáng, chữ comic "POW!", sóng xung kích...
// Tất cả được vẽ bằng Canvas (không dùng ảnh tĩnh)
// ============================================================
class FxSystem {
    constructor() { this.list = []; }
    clear() { this.list.length = 0; }
    ring(x, y, o = {}) {
        this.list.push({ type: 'ring', x, y, r0: o.r0 || 8, r1: o.r1 || 90, life: o.life || 0.35, t: 0, color: o.color || '#fff', w: o.w || 5, sq: o.sq === undefined ? 1 : o.sq });
    }
    burst(x, y, o = {}) {
        this.list.push({ type: 'burst', x, y, n: o.n || 10, len: o.len || 46, life: o.life || 0.26, t: 0, color: o.color || '#ffe27a', w: o.w || 4, rot: Math.random() * 6.28 });
    }
    star(x, y, o = {}) {
        this.list.push({ type: 'star', x, y, r: o.r || 40, life: o.life || 0.22, t: 0, color: o.color || '#ffe27a', rot: Math.random() * 6.28 });
    }
    comic(x, y, text, o = {}) {
        this.list.push({ type: 'comic', x, y, text, color: o.color || '#ffe27a', size: o.size || 26, life: o.life || 0.5, t: 0, rot: (Math.random() - 0.5) * 0.5 });
    }
    // sóng xung kích lan trên mặt đất: nhiều vòng + vệt bụi
    shock(x, y, o = {}) {
        const R = o.r1 || 320, life = o.life || 0.5, c = o.color || '#ffb347';
        this.ring(x, y, { r0: 12, r1: R, life, color: c, w: 9, sq: 0.26 });
        this.ring(x, y, { r0: 6, r1: R * 0.78, life: life * 0.9, color: '#fff', w: 4, sq: 0.26 });
        this.ring(x, y, { r0: 4, r1: R * 0.55, life: life * 0.8, color: c, w: 3, sq: 0.26 });
        this.list.push({ type: 'crack', x, y, r: R * 0.5, life: life * 1.6, t: 0, seed: Math.random() * 99 });
    }
    update(dt) {
        for (let i = this.list.length - 1; i >= 0; i--) { const f = this.list[i]; f.t += dt; if (f.t >= f.life) this.list.splice(i, 1); }
    }
    draw(ctx, cam) {
        for (const f of this.list) {
            const p = clamp(f.t / f.life, 0, 1), sx = cam.screenX(f.x), sy = cam.screenY(f.y), a = 1 - p;
            ctx.save();
            if (f.type === 'ring') {
                const r = f.r0 + (f.r1 - f.r0) * (1 - Math.pow(1 - p, 2.2));
                ctx.globalAlpha = a; ctx.strokeStyle = f.color; ctx.lineWidth = Math.max(1, f.w * a); ctx.shadowColor = f.color; ctx.shadowBlur = 14;
                ctx.beginPath(); ctx.ellipse(sx, sy, r, r * f.sq, 0, 0, 6.283); ctx.stroke();
            } else if (f.type === 'burst') {
                ctx.globalAlpha = a; ctx.strokeStyle = f.color; ctx.lineWidth = f.w * a + 1; ctx.lineCap = 'round'; ctx.shadowColor = f.color; ctx.shadowBlur = 10;
                const l0 = f.len * 0.3 * p, l1 = f.len * (0.35 + 0.65 * p);
                for (let k = 0; k < f.n; k++) { const an = f.rot + k * 6.283 / f.n; ctx.beginPath(); ctx.moveTo(sx + Math.cos(an) * l0, sy + Math.sin(an) * l0); ctx.lineTo(sx + Math.cos(an) * l1, sy + Math.sin(an) * l1); ctx.stroke(); }
            } else if (f.type === 'star') {
                ctx.globalAlpha = a * 0.9; ctx.fillStyle = f.color; ctx.translate(sx, sy); ctx.rotate(f.rot);
                const r = f.r * (0.5 + 0.7 * Math.sin(p * Math.PI * 0.8 + 0.3));
                ctx.beginPath(); for (let k = 0; k < 16; k++) { const rr = k % 2 ? r * 0.45 : r; const an = k * Math.PI / 8; ctx.lineTo(Math.cos(an) * rr, Math.sin(an) * rr); } ctx.closePath(); ctx.fill();
            } else if (f.type === 'comic') {
                const sc = p < 0.2 ? 0.4 + p / 0.2 * 1.1 : 1.5 - (p - 0.2) * 0.4;
                ctx.globalAlpha = p > 0.7 ? (1 - p) / 0.3 : 1; ctx.translate(sx, sy - p * 18); ctx.rotate(f.rot); ctx.scale(sc, sc);
                ctx.font = `900 ${f.size}px Impact, "Arial Black", system-ui`; ctx.textAlign = 'center'; ctx.lineJoin = 'round';
                ctx.strokeStyle = '#1a0a00'; ctx.lineWidth = 7; ctx.strokeText(f.text, 0, 0);
                ctx.fillStyle = f.color; ctx.fillText(f.text, 0, 0);
            } else if (f.type === 'crack') {
                ctx.globalAlpha = a * 0.8; ctx.strokeStyle = '#1a0f08'; ctx.lineWidth = 3; ctx.lineCap = 'round';
                let s = f.seed * 1000 + 7; const r = () => (s = (s * 9301 + 49297) % 233280) / 233280;
                for (let k = 0; k < 9; k++) {
                    const dir = k < 5 ? 1 : -1; let x = sx, y = sy; ctx.beginPath(); ctx.moveTo(x, y);
                    const len = f.r * (0.5 + r() * 0.5) * clamp(p * 4, 0, 1);
                    for (let n = 0; n < 4; n++) { x += dir * len / 4; y += (r() - 0.4) * 10; ctx.lineTo(x, y); }
                    ctx.stroke();
                }
            }
            ctx.restore();
        }
    }
}

// Phân loại đòn: đòn mạnh (heavy) khi sát thương >= 22, còn lại là đòn thường (light)
for (const tbl of [COMBO_MOVES, COMBO_FALLBACK3, COMBO_FINALE]) for (const k in tbl) if (!tbl[k].kind) tbl[k].kind = tbl[k].dmg >= 22 ? 'heavy' : 'light';

// ============================================================
// PLAYER (Ricardo Milos) — nhân vật vẽ bằng khung xương (Rig), có Block / Perfect Block,
// Double Jump, 4 kỹ năng (DACNE, THRUST, CHƯỞNG, ETERNAL DANCE) và hệ combo J / H / L
// ============================================================
const SKILL_DEF = {
    skill1:   { key: 'U', name: 'DACNE',         cd: 14, mp: 20,  color: '#4ade80' },
    skill2:   { key: 'I', name: 'THRUST',        cd: 7,  mp: 15,  color: '#f472b6' },
    skill3:   { key: 'O', name: 'CHUONG',        cd: 9,  mp: 25,  color: '#38bdf8' },      // phím D: CHƯỞNG — nạp khí rồi bắn tia năng lượng
    ultimate: { key: 'P', name: 'ETERNAL DANCE', cd: 45, mp: 100, color: '#ffd45a' }
};
const PERFECT_WINDOW = 0.2;      // giây đầu sau khi giơ đỡ: đỡ trúng lúc này = Perfect Block
const THRUST_DUR = 0.66, SLAM_DUR = 1.15, ULT_DUR = 4.4, DACNE_DUR = 2.0;
// CHƯỞNG: nạp khí (0 -> CHUONG_FIRE) -> bắn tia (BEAM_DUR giây) -> thu thế
const CHUONG_DUR = 1.3, CHUONG_FIRE = 0.56, BEAM_DUR = 0.62, BEAM_LEN = 800;
const smooth01 = t => { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); };

class Player {
    constructor() {
        this.x = 200; this.y = GROUND_Y - 128;
        this.w = 60; this.h = 128;
        this.vx = 0; this.vy = 0;
        this.facingRight = true;
        this.hp = 100; this.maxHp = 100;
        this.mp = 0; this.maxMp = 100;
        this.speed = 300;
        this.jumpForce = -620;
        this.style = RIG_STYLES.ricardo;
        this.hitTargets = new Set();
        this.afterImages = [];
        this.waves = [];
        this.reset(200);
    }
    reset(x) {
        this.x = x || 200; this.y = GROUND_Y - this.h;
        this.vx = this.vy = 0;
        this.hp = this.maxHp; this.mp = 0;
        this.grounded = true; this.state = 'idle';
        this.t = 0; this.runPhase = 0;
        this.stateTimer = 0; this.eternalTimer = 0;
        this.attackId = 0; this.move = null; this.moveName = ''; this.moveDur = 1;
        this.chain = ''; this.chainTimer = 0; this.buffer = [];
        this.invulnTimer = 0; this.hitFlash = 0; this.stunTimer = 0;
        this.combo = 0; this.comboTimer = 0; this.maxCombo = 0; this.totalDamageDealt = 0; this.killCount = 0;
        this.dashCooldown = 0; this.dashTimer = 0; this.dashDir = 0;
        this.blocking = false; this.blockTime = 0; this.blockCd = 0; this.shieldFlash = 0; this.perfectFlash = 0; this.counterTimer = 0;
        this.jumpsUsed = 0; this.flipTimer = 0; this.landT = 0; this.takeoffT = 0; this.stateAge = 0; this._psState = '';
        this.defeated = false; this.victory = false; this.hidden = false; this.suck = null; this.entr = null; this.auraT = 0;
        this.cooldowns = { skill1: 0, skill2: 0, skill3: 0, ultimate: 0 };
        this.readyFlash = { skill1: 0, skill2: 0, skill3: 0, ultimate: 0 };
        this.denyFlash = { skill1: 0, skill2: 0, skill3: 0, ultimate: 0 };
        this.skill2Active = false; this.healDone = 0; this.slamDone = true; this.slamHop = false; this.slamAt = 0;
        this.beam = null; this.beamFired = false; this.hitFx = [];
        this.ultT = 0; this.ultWaves = 0; this.ultFinal = false;
        this.hitTargets.clear(); this.afterImages = []; this.waves = [];
    }
    isBusy() { return ['skill1', 'skill2', 'skill3', 'ultimate'].includes(this.state); }

    // ------------------------------------------------------------------
    update(dt, input, groundY, mapWidth, audio, particles, floatText, world) {
        this.t += dt;
        if (this.state !== this._psState) { this._psState = this.state; this.stateAge = 0; }
        this.stateAge += dt; if (this.landT > 0) this.landT -= dt; if (this.takeoffT > 0) this.takeoffT -= dt;
        if (this.victory && !this.defeated) {       // chiến thắng: Ricardo khoe cơ bắp
            this.state = 'victory'; this.vx = 0; this.vy += GRAVITY * dt; this.y = Math.min(this.y + this.vy * dt, groundY - this.h); if (this.y >= groundY - this.h) this.vy = 0; return;
        }
        if (this.defeated) {
            this.state = 'defeat';
            this.vy += GRAVITY * dt; this.y += this.vy * dt; this.x += this.vx * dt; this.vx *= 0.9;
            if (this.y + this.h >= groundY) { this.y = groundY - this.h; this.vy = 0; this.grounded = true; }
            return;
        }
        // ---- bộ đếm thời gian ----
        this.invulnTimer = Math.max(0, this.invulnTimer - dt);
        this.hitFlash = Math.max(0, this.hitFlash - dt);
        this.stunTimer = Math.max(0, this.stunTimer - dt);
        this.dashCooldown = Math.max(0, this.dashCooldown - dt);
        this.dashTimer = Math.max(0, this.dashTimer - dt);
        this.blockCd = Math.max(0, this.blockCd - dt);
        this.shieldFlash = Math.max(0, this.shieldFlash - dt);
        this.perfectFlash = Math.max(0, this.perfectFlash - dt);
        this.counterTimer = Math.max(0, this.counterTimer - dt);
        this.flipTimer = Math.max(0, this.flipTimer - dt);
        for (const k in this.cooldowns) {
            const before = this.cooldowns[k];
            this.cooldowns[k] = Math.max(0, before - dt);
            if (before > 0 && this.cooldowns[k] === 0) {        // kỹ năng vừa hồi xong -> báo sẵn sàng
                this.readyFlash[k] = 1; audio.playReady();
                floatText.show(this.x + this.w / 2, this.y - 36, SKILL_DEF[k].name + ' READY', SKILL_DEF[k].color, 15, 1.0);
            }
            this.readyFlash[k] = Math.max(0, this.readyFlash[k] - dt * 1.6);
            this.denyFlash[k] = Math.max(0, this.denyFlash[k] - dt * 2.5);
        }
        this.chainTimer = Math.max(0, this.chainTimer - dt);
        if (this.chainTimer <= 0 && this.state !== 'attack') this.chain = '';
        this.comboTimer -= dt;
        if (this.comboTimer <= 0) { if (this.combo > this.maxCombo) this.maxCombo = this.combo; this.combo = 0; }
        // đòn liên tiếp đổi bên: lật ngang nhân vật nhanh để tay/chân còn lại ra trước (tay phải -> tay trái, chân phải -> chân trái)
        if (this.mirrorK === undefined) this.mirrorK = 1;
        const mt = (this.state === 'attack' && this.limbSwap) ? -1 : 1;
        this.mirrorK += clamp(mt - this.mirrorK, -dt * 18, dt * 18);
        this.mp = Math.min(this.maxMp, this.mp + 4 * dt);
        if (this.eternalTimer > 0) {
            this.eternalTimer = Math.max(0, this.eternalTimer - dt);
            this.mp = this.maxMp;
            this._eAI = (this._eAI || 0) - dt;
            if (this._eAI <= 0) { this._eAI = 0.06; this._ghost(0.7, 0.35); }
        }
        // ---- chuyển trạng thái khi hết thời gian ----
        this.stateTimer -= dt;
        const ACTIONS = ['attack', 'skill1', 'skill2', 'skill3', 'ultimate', 'hurt', 'knockback', 'knockdown', 'getup'];
        let inAction = ACTIONS.includes(this.state);
        if (inAction && this.stateTimer <= 0) {
            if (this.state === 'knockdown') { this.state = 'getup'; this.stateTimer = 0.4; this.invulnTimer = 0.6; }
            else {
                if (this.state === 'attack') {
                    if (this.hitTargets.size === 0 && this.move && this.move.kind === 'heavy') {     // đòn mạnh đánh trượt
                        audio.playWhiff(); floatText.show(this.x + this.w / 2, this.y - 8, 'MISS', '#94a3b8', 13, 0.5);
                    }
                    this.chainTimer = CHAIN_GRACE;
                    if (this.chain.length >= 4) this.chain = '';
                    this.move = null;
                }
                if (this.state === 'skill3' && !this.slamDone) this._slam(world, particles, audio, floatText);
                if (this.state === 'ultimate') { audio.duck(1); world.timeScale = 1; world.camZoomTarget = 1; }
                this.state = 'idle'; this.hitTargets.clear(); this.skill2Active = false;
            }
            inAction = ACTIONS.includes(this.state);
        }
        // ---- đệm phím đánh để nối combo ----
        if (this.state === 'attack' && this.move) {
            for (const k of ['j', 'h', 'l']) if (input.pressed(k) && this.buffer.length < 2) this.buffer.push({ key: k.toUpperCase(), t: 0.45 });
            for (const b of this.buffer) b.t -= dt;
            this.buffer = this.buffer.filter(b => b.t > 0);
            const prog = 1 - this.stateTimer / this.moveDur;
            if (this.buffer.length && prog >= this.move.cancel && this.chain.length < 4) this._startMove(this.buffer.shift().key, input, audio, floatText);
        }
        if (inAction && this.grounded && !this.skill2Active && ['attack', 'skill1', 'skill3', 'ultimate'].includes(this.state) && !(this.state === 'skill3')) {
            this.vx -= this.vx * Math.min(1, 14 * dt);
        }
        // ---- điều khiển khi không bận hành động ----
        if (!inAction) {
            const mx = input.moveX();
            const wantBlock = (input.isDown('k') || input.crouchBtn()) && this.grounded && this.blockCd <= 0 && this.dashTimer <= 0;
            if (wantBlock) {                                    // ĐỠ ĐÒN: không đánh / dùng kỹ năng khi đang giữ
                if (!this.blocking) { this.blocking = true; this.blockTime = 0; audio.playBlockUp(); }
                this.blockTime += dt; this.state = 'block'; this.vx = 0;
                if (mx !== 0) this.facingRight = mx > 0;        // xoay mặt để đỡ đúng hướng
            } else {
                if (this.blocking) { this.blocking = false; this.blockCd = 0.22; }
                if (input.dashBtn() && this.dashCooldown <= 0 && mx !== 0) {
                    this.dashTimer = 0.2; this.dashDir = mx; this.dashCooldown = 1.2; audio.playDash();
                    world.fx.ring(this.x + this.w / 2, this.y + this.h, { r1: 50, life: 0.25, color: '#7dd3fc', sq: 0.3 });
                }
                if (this.dashTimer > 0) {
                    this.vx = this.dashDir * 700; this.facingRight = this.dashDir > 0; this.state = 'run';
                    this._eAI2 = (this._eAI2 || 0) - dt; if (this._eAI2 <= 0) { this._eAI2 = 0.04; this._ghost(0.5, 0.25); }
                } else if (mx !== 0) {
                    const sprint = input.sprintDir() === mx;                     // nhấn đúp A/D -> chạy nhanh
                    this.vx = mx * this.speed * (this.eternalTimer > 0 ? 1.2 : 1) * (sprint ? 1.75 : 1);
                    if (this.state !== 'run' && this.grounded && !sprint) this.runPhase = 3.5 / RicardoSprite.WALK_K;   // bắt đầu đi từ khung 'chân chụm' (không giật từ thế đứng)
                    this.facingRight = mx > 0; this.state = 'run';
                    this.runPhase += dt * (sprint ? 20 : 13);
                    if (sprint && this.grounded) {
                        this._sprintFx = (this._sprintFx || 0) - dt;
                        if (this._sprintFx <= 0) { this._sprintFx = 0.07; particles.dust(this.x + this.w / 2 - mx * 16, this.y + this.h); }
                    }
                } else { this.vx *= 0.7; if (this.grounded) this.state = 'idle'; }
                // ---- NHẢY / NHẢY ĐÔI ----
                if (input.jumpBtn()) {
                    if (this.grounded) {
                        this.vy = this.jumpForce; this.grounded = false; this.jumpsUsed = 1; this.state = 'jump'; this.takeoffT = 0.09; audio.playJump();
                        particles.dust(this.x + this.w / 2, this.y + this.h);
                    } else if (this.jumpsUsed < 2) {
                        this.vy = this.jumpForce * 0.95; this.jumpsUsed = 2; this.flipTimer = 0.55; this.state = 'jump';
                        audio.playDoubleJump();
                        world.fx.ring(this.x + this.w / 2, this.y + this.h + 6, { r1: 64, life: 0.35, color: '#a5f3fc', w: 5, sq: 0.3 });
                        world.fx.ring(this.x + this.w / 2, this.y + this.h + 6, { r1: 40, life: 0.28, color: '#fff', w: 3, sq: 0.3 });
                        particles.energyBurst(this.x + this.w / 2, this.y + this.h, '#a5f3fc');
                        floatText.show(this.x + this.w / 2, this.y - 14, 'DOUBLE JUMP', '#a5f3fc', 14, 0.6);
                    }
                }
                // ---- ĐÁNH THƯỜNG ----
                let atkKey = null;
                if (input.pressed('j')) atkKey = 'J'; else if (input.pressed('h')) atkKey = 'H'; else if (input.pressed('l')) atkKey = 'L';
                else if (this.buffer.length) atkKey = this.buffer.shift().key;
                if (atkKey) this._startMove(atkKey, input, audio, floatText);
                else if (input.pressed('u')) this._trySkill('skill1', audio, floatText, world, particles);
                else if (input.pressed('i')) this._trySkill('skill2', audio, floatText, world, particles);
                else if (input.pressed('o')) this._trySkill('skill3', audio, floatText, world, particles);
                else if (input.pressed('p')) this._trySkill('ultimate', audio, floatText, world, particles);
            }
        } else if (this.blocking) { this.blocking = false; }
        // ---- cập nhật từng kỹ năng ----
        this._updateSkills(dt, audio, particles, floatText, world);
        // ---- vật lý ----
        this.vy += GRAVITY * dt;
        this.x += this.vx * dt; this.y += this.vy * dt;
        if (this.y + this.h >= groundY) {
            if (!this.grounded) {
                this.grounded = true; this.jumpsUsed = 0; this.flipTimer = 0;
                if (this.state === 'jump' || this.state === 'fall') { this.state = 'idle'; this.landT = 0.12; }
                particles.dust(this.x + this.w / 2, groundY); audio.playLand();
                if (this.state === 'skill3' && !this.slamDone && this.slamHop) this._slam(world, particles, audio, floatText);
            }
            this.y = groundY - this.h; this.vy = 0;
        } else this.grounded = false;
        const ceil = groundY - this.h - 430;                   // giới hạn chiều cao màn chơi
        if (this.y < ceil) { this.y = ceil; this.vy = Math.max(0, this.vy); }
        this.x = clamp(this.x, 10, mapWidth - this.w - 10);
        if (!this.grounded && this.jumpsUsed === 0) this.jumpsUsed = 1;     // rơi/bị hất lên: chỉ còn 1 lần nhảy
        if (!this.grounded && !inAction) this.state = this.vy < 0 ? 'jump' : 'fall';
        // ---- hậu ảnh ----
        for (let i = this.afterImages.length - 1; i >= 0; i--) {
            const a = this.afterImages[i]; a.timer -= dt; a.alpha -= dt * 2.2; if (a.timer <= 0) this.afterImages.splice(i, 1);
        }
    }
    _ghost(alpha, life) { this.afterImages.push({ x: this.x, y: this.y, alpha, timer: life, face: this.facingRight, spr: this._sprite(), pose: (() => { const q = Object.assign({}, this._pose()); q.mirror = (q.mirror === undefined ? 1 : q.mirror) * (this.mirrorK === undefined ? 1 : this.mirrorK); return q; })() }); }

    // ------------------------------------------------------------------
    _trySkill(k, audio, floatText, world, particles) {
        const d = SKILL_DEF[k];
        if (this.cooldowns[k] > 0 || this.mp < d.mp || (k === 'ultimate' && world.enemyManager.getAliveCount() === 0)) {
            this.denyFlash[k] = 1; audio.playDeny();
            const msg = this.cooldowns[k] > 0 ? 'HỒI CHIÊU' : (this.mp < d.mp ? 'THIẾU MP' : 'KHÔNG CÓ MỤC TIÊU');
            floatText.show(this.x + this.w / 2, this.y - 8, msg, '#94a3b8', 13, 0.5);
            return;
        }
        this.mp -= d.mp; this.cooldowns[k] = d.cd; this.attackId++; this.hitTargets.clear(); this.frame = 0;
        const cx = this.x + this.w / 2;
        this.chain = ''; this.chainTimer = 0; this.move = null; this.buffer = [];
        if (k === 'skill1') {
            this.state = 'skill1'; this.stateTimer = DACNE_DUR; this.healDone = 0; this.vx = 0;
            audio.playSkill('skill1');
            floatText.show(cx, this.y - 30, 'DACNE!', '#4ade80', 30, 0.9);
            world.fx.ring(cx, this.y + this.h, { r1: 90, life: 0.5, color: '#4ade80', w: 6, sq: 0.3 });
        } else if (k === 'skill2') {
            this.state = 'skill2'; this.stateTimer = THRUST_DUR; this.skill2Active = false; this.vx = 0;
            audio.playSkill('skill2');
            floatText.show(cx, this.y - 30, 'THRUST!', '#f472b6', 30, 0.9);
        } else if (k === 'skill3') {
            this.state = 'skill3'; this.stateTimer = CHUONG_DUR; this.slamDone = true; this.slamHop = false; this.vx = 0;
            this.beam = null; this.beamFired = false;
            audio.playSkill('skill3');
            floatText.show(cx, this.y - 30, 'CHUONG!', '#38bdf8', 30, 0.9);
            world.fx.ring(cx, this.y + this.h, { r1: 80, life: 0.55, color: '#38bdf8', w: 5, sq: 0.3 });
        } else {
            this.state = 'ultimate'; this.stateTimer = ULT_DUR; this.ultT = 0; this.ultWaves = 0; this.ultFinal = false; this._ultRune = false; this._ultImp = 0; this._ultBeat = 0;
            this.vx = 0; this.invulnTimer = ULT_DUR + 0.3; this.blocking = false;
            audio.playSkill('ult'); audio.duck(0.55);
            world.flash(0.7); world.camZoomTarget = 1.3; world.timeScale = 0.08;
            world.fx.ring(cx, this.y + this.h * 0.5, { r1: 200, life: 0.8, color: '#ffd45a', w: 8, sq: 1 });
        }
    }
    // vị trí bàn tay (toạ độ thế giới) khi tung CHƯỞNG; k = 0..1 tiến độ (tay đưa dần ra trước)
    _hand(dir, k) { const q = smooth01(k); return { x: this.x + this.w / 2 + dir * (44 + 30 * q), y: this.y + this.h - (77 + 26 * q) }; }
    _updateChuong(dt, audio, particles, floatText, world) {
        const e = CHUONG_DUR - this.stateTimer, dir = this.facingRight ? 1 : -1, cx = this.x + this.w / 2;
        this.vx = (e >= CHUONG_FIRE && e < CHUONG_FIRE + 0.25) ? -dir * 130 * (1 - (e - CHUONG_FIRE) / 0.25) : 0;   // giật lùi nhẹ khi bắn
        if (e < CHUONG_FIRE) {                           // nạp khí: hạt năng lượng bị hút về bàn tay
            const p = e / CHUONG_FIRE, hp = this._hand(dir, p * 0.4), n = 1 + Math.floor(p * 3);
            for (let i = 0; i < n; i++) {
                const a = Math.random() * 6.283, r = 60 + Math.random() * 70 * (1 - p * 0.4), px = hp.x + Math.cos(a) * r, py = hp.y + Math.sin(a) * r;
                particles.emit(px, py, 1, { vx: (hp.x - px) / 0.27, vy: (hp.y - py) / 0.27, life: 0.27, color: ['#7dd3fc', '#38bdf8', '#ffffff'], size: 3, gravity: 0 });
            }
            if (Math.random() < 0.25) particles.dust(cx - dir * 10, this.y + this.h);
        } else if (!this.beamFired) {                    // BẮN
            this.beamFired = true;
            const hp = this._hand(dir, 1);
            this.beam = { t: 0, dir, ox: hp.x, oy: hp.y, len: 0, alpha: 1, thick: 1, hits: new Map(), seed: Math.random() * 10 };
            audio.playSkill('chuong_fire');
            world.flash(0.35); world.camera.shake(10, 0.55);
            world.fx.ring(hp.x, hp.y, { r1: 130, life: 0.42, color: '#7dd3fc', w: 9, sq: 1 });
            world.fx.ring(hp.x, hp.y, { r1: 70, life: 0.3, color: '#ffffff', w: 5, sq: 1 });
            world.fx.star(hp.x, hp.y, { r: 90, life: 0.28, color: '#e0f2fe' });
            particles.emit(hp.x, hp.y, 22, { vx: dir * 420, vxRand: 380, vyRand: 260, life: 0.45, color: ['#7dd3fc', '#38bdf8', '#fff'], size: 4, gravity: 0 });
        }
    }
    _updateBeam(dt, audio, particles, floatText, world) {
        const B = this.beam; if (!B) return;
        B.t += dt;
        if (B.t >= BEAM_DUR) { this.beam = null; return; }
        const dir = B.dir, hp = this._hand(dir, 1); B.ox = hp.x; B.oy = hp.y;       // tia bám theo bàn tay
        const gr = clamp(B.t / 0.13, 0, 1); B.len = BEAM_LEN * (1 - Math.pow(1 - gr, 3));
        B.alpha = B.t < 0.42 ? 1 : clamp(1 - (B.t - 0.42) / 0.2, 0, 1);
        B.thick = (0.25 + 0.75 * smooth01(B.t / 0.1)) * (B.t < 0.42 ? 1 : (0.35 + 0.65 * B.alpha)) * (1 + 0.05 * Math.sin(B.t * 70 + B.seed));
        if (Math.random() < 0.8) particles.emit(B.ox + dir * Math.random() * B.len, B.oy + (Math.random() - 0.5) * 50 * B.thick, 1, { vx: dir * 200, vxRand: 200, vyRand: 90, life: 0.3, color: ['#7dd3fc', '#e0f2fe', '#38bdf8'], size: 3, gravity: 0 });
        // sát thương: trúng đầu tiên mạnh + choáng; ở lại trong tia thì chịu thêm sát thương nhỏ mỗi 0.16s
        const half = 38 * B.thick, rect = { x: dir > 0 ? B.ox : B.ox - B.len, y: B.oy - half, w: B.len, h: half * 2 };
        for (const e of world.enemyManager.enemies) {
            if (e.dead || !overlap(rect, e.getHurtbox())) continue;
            const last = B.hits.get(e.id);
            if (last !== undefined && B.t - last < 0.16) continue;
            const first = last === undefined; B.hits.set(e.id, B.t);
            const dmg = Math.round((first ? 38 : 9) * (this.eternalTimer > 0 ? 1.6 : 1));
            const res = e.takeDamage(dmg, dir, first ? 380 : 40, particles, floatText, audio, { kind: 'skill', stun: first ? 0.9 : 0.35, launch: 0 });
            if (res === 'hit') {
                this.combo++; this.comboTimer = 2.4; this.totalDamageDealt += dmg; this.mp = Math.min(this.maxMp, this.mp + 4);
                if (e.dead) this.killCount++;
                const ex = e.cx(), ey = e.y + e.h * 0.5;
                world.fx.burst(ex, ey, { n: 10, len: 60, color: '#7dd3fc', w: 4 });
                this.hitFx.push({ x: ex, y: ey, t: 0, seed: Math.random() * 6.28 });
                if (first) { world.hitStop(0.05); world.camera.shake(7, 0.2); audio.playBigImpact(); world.fx.ring(ex, ey, { r1: 70, life: 0.3, color: '#38bdf8', w: 6 }); }
                if (e.isBoss && e.dead) world.slowMo(0.9, 0.3);
            }
        }
    }
    _updateSkills(dt, audio, particles, floatText, world) {
        const cx = this.x + this.w / 2, dir = this.facingRight ? 1 : -1;
        if (this.beam && this.state !== 'skill3') this.beam = null;                        // bị ngắt giữa chừng -> tia tắt
        if (this.beam) this._updateBeam(dt, audio, particles, floatText, world);
        for (const h of this.hitFx) h.t += dt;
        if (this.hitFx.length) this.hitFx = this.hitFx.filter(h => h.t < 0.4);
        if (this.state === 'skill1') {              // DACNE: nhảy tại chỗ, hồi máu theo nhịp
            const e = DACNE_DUR - this.stateTimer;
            this.vx = 0;
            if (this.healDone < 4 && e >= 0.4 * (this.healDone + 1)) {
                this.healDone++;
                const heal = Math.min(9, this.maxHp - this.hp); this.hp += heal;
                floatText.show(cx, this.y - 6, heal > 0 ? `+${heal}` : 'MAX', '#4ade80', 20, 0.7);
                world.fx.ring(cx, this.y + this.h, { r1: 80 + this.healDone * 10, life: 0.45, color: '#86efac', w: 5, sq: 0.3 });
                particles.emit(cx, this.y + this.h * 0.7, 10, { vxRand: 160, vy: -140, vyRand: 80, life: 0.7, color: ['#4ade80', '#bbf7d0', '#fde047'], size: 3, gravity: -40 });
                audio.playHeal();
            }
            this._noteT = (this._noteT || 0) - dt;
            if (this._noteT <= 0) { this._noteT = 0.28; particles.emit(cx, this.y + 10, 1, { spreadX: 50, vy: -80, life: 0.8, color: ['#f9a8d4', '#fde68a', '#a5f3fc'], size: 5, gravity: -20 }); }
        } else if (this.state === 'skill2') {       // THRUST: lấy đà -> lao tới -> hồi
            const e = THRUST_DUR - this.stateTimer;
            if (e < 0.18) { this.vx = 0; this.skill2Active = false; if (Math.random() < 0.4) particles.trail(cx - dir * 20, this.y + this.h * 0.5, '#f472b6'); }
            else if (e < 0.46) {
                if (!this.skill2Active) { this.skill2Active = true; world.camera.shake(7, 0.2); }
                this.vx = dir * 1360;
                this._eAI2 = (this._eAI2 || 0) - dt; if (this._eAI2 <= 0) { this._eAI2 = 0.025; this._ghost(0.75, 0.3); }
                particles.trail(cx - dir * 30, this.y + this.h * 0.5, '#f9a8d4'); particles.trail(cx - dir * 50, this.y + this.h * 0.6, '#ec4899');
            } else { this.skill2Active = false; this.vx *= Math.pow(0.001, dt); }
        } else if (this.state === 'skill3') this._updateChuong(dt, audio, particles, floatText, world);
        else if (this.state === 'ultimate') this._updateUltimate(dt, audio, particles, floatText, world);
    }
    _slam(world, particles, audio, floatText) {
        this.slamDone = true; this.slamAt = SLAM_DUR - this.stateTimer;
        const cx = this.x + this.w / 2, gy = this.y + this.h;
        world.addWave({ x: cx, y: gy, dmg: 34, stun: 1.0, kb: 380, maxR: 340, speed: 900, kind: 'skill', color: '#fb923c', launch: 0, near: true });
        world.fx.shock(cx, gy, { r1: 340, color: '#fb923c', life: 0.5 });
        world.fx.burst(cx, gy - 10, { n: 14, len: 70, color: '#ffe27a' });
        world.fx.comic(cx, gy - 70, 'BOOM!', { color: '#fb923c', size: 34 });
        for (let i = 0; i < 4; i++) particles.dust(cx + (i - 1.5) * 40, gy);
        particles.emit(cx, gy, 26, { vxRand: 620, vy: -160, vyRand: 160, life: 0.6, color: ['#8a7a6a', '#a09080', '#fb923c'], size: 5, gravity: 500 });
        world.camera.shake(16, 0.4); world.hitStop(0.07); audio.playBigImpact();
    }
    _updateUltimate(dt, audio, particles, floatText, world) {
        this.ultT += dt;
        const T = this.ultT, cx = this.x + this.w / 2, cy = this.y + this.h * 0.5, gy = this.y + this.h;
        this.vx = 0; this.invulnTimer = Math.max(this.invulnTimer, 0.2);
        if (T < 0.7) { world.timeScale = 0.08; world.camZoomTarget = 1.3; if (Math.random() < 0.6) particles.emit(cx, gy, 1, { spreadX: 90, vy: -240, vyRand: 80, life: 0.7, color: ['#ffd45a', '#fff'], size: 4, gravity: -50 }); }
        else {
            if (world.timeScale < 0.5) { world.timeScale = 0.55; world.banner('ETERNAL DANCE', '', 1.3, '#ffd45a'); world.flash(0.4); audio.playCine('reveal'); }
            this._eAI = (this._eAI || 0) - dt; if (this._eAI <= 0) { this._eAI = 0.05; this._ghost(0.6, 0.3); }
        }
        const times = [0.95, 1.5, 2.05, 2.6, 3.1], F = pfx(), groundY = gy;
        // ---- đứng yên một chỗ nhảy điệu DACNE; mỗi nhịp phát vòng sóng pixel dưới chân (như DACNE nhưng mạnh hơn) ----
        this.vy = 0;
        if (F && T >= 0.7 && T < 3.3 && (this._ultBeat = (this._ultBeat || 0) - dt) <= 0) {
            this._ultBeat = 0.27; const bc = Math.floor(T / 0.27) % 2 ? '#ff6ec7' : '#ffd45a';
            F.ring(cx, world.map.getGroundY(), 20, 150, 0.5, bc, { n: 40, sq: 0.3, size: 3 });
        }
        if (F && T < 0.7 && (this._ultImp = (this._ultImp || 0) - dt) <= 0) { this._ultImp = 0.09; F.implode(cx, cy, 280, ['#ffffff', '#ffd45a', '#ff9ad5'], 12, 0.35); }   // hút khí về thân khi gồng
        if (F && T >= 0.7 && !this._ultRune) { this._ultRune = true; F.circle(cx, world.map.getGroundY(), 400, 2.7, '#ffd45a', '#ff6ec7', { grow: 0.1, fade: 0.4, spin: 1.6 }); }   // trận pháp dưới chân
        while (this.ultWaves < 5 && T >= times[this.ultWaves]) {          // chuỗi dance attack: 5 đợt sóng năng lượng
            const i = this.ultWaves++; const col = i % 2 ? '#ff6ec7' : '#ffd45a'; const lgy = world.map.getGroundY();
            world.addWave({ x: cx, y: lgy, dmg: 26, stun: 0.7, kb: 260, maxR: 470, speed: 1100, kind: 'ult', color: col, launch: 280, air: true });
            if (F) {                                                      // sóng đã được vẽ pixel theo bán kính thật (PXFX.drawShockWave); thêm tia lửa + cột sáng + bụi đá lúc đáp
                F.sparks(cx, lgy - 8, 34, { col: ['#ffffff', col, mix2(col)], angle: -Math.PI / 2, cone: 2.9, min: 180, max: 620, g: 700, life: 0.6, size: 6 });
                F.groundBlast(cx, lgy, 200, ['#ffffff', col]);
            } else { world.fx.ring(cx, lgy, { r1: 470, life: 0.45, color: col, w: 8, sq: 0.3 }); world.fx.burst(cx, cy, { n: 16, len: 90, color: col, w: 5 }); }
            world.camera.shake(8, 0.2); audio.playBigImpact(); if (!F) particles.energyBurst(cx, cy, col);
            if (i === 0) floatText.show(cx, this.y - 30, 'DANCE ATTACK!', '#ffd45a', 24, 1);
        }
        if (T >= 3.35 && !this.ultFinal) {                                   // đòn kết thúc
            this.ultFinal = true; world.timeScale = 1; world.camZoomTarget = 1.0; const lgy = world.map.getGroundY();
            world.addWave({ x: cx, y: lgy, dmg: 60, stun: 1.2, kb: 520, maxR: 780, speed: 1500, kind: 'ult', color: '#ffffff', launch: 520, air: true, final: true });
            if (F) {
                F.hit(cx, cy, 230, '#fff3a0', 0.4);
                F.ring(cx, cy, 20, 520, 0.6, '#ffffff', { n: 80, size: 6 }); F.ring(cx, lgy, 10, 760, 0.7, '#ffd45a', { sq: 0.2, n: 90 });
                F.groundBlast(cx, lgy, 520, ['#ffffff', '#ffd45a', '#ff6ec7']);
                F.sparks(cx, cy, 140, { col: ['#ffffff', '#ffd45a', '#ff6ec7'], min: 240, max: 900, g: 0, life: 1.0, drag: 0.03 });
            } else { world.fx.shock(cx, lgy, { r1: 780, color: '#ffd45a', life: 0.7 }); world.fx.ring(cx, cy, { r1: 420, life: 0.6, color: '#fff', w: 12, sq: 1 }); world.fx.star(cx, cy, { r: 160, life: 0.4, color: '#fff3a0' }); }
            world.flash(1); world.camera.shake(30, 0.7); world.hitStop(0.14);
            world.banner('THE DANCE NEVER DIES', '', 2.0, '#ffffff', true);
            audio.playCine('impact'); audio.playCine('eternal');
        }
        if (T >= 3.4 && world.timeScale < 1) world.timeScale = 1;
    }
    activateEternal(particles, camera, audio, hpFrac) {
        this.eternalTimer = 20; this.hp = Math.max(this.hp, this.maxHp * (hpFrac || 0.6)); this.mp = this.maxMp; this.invulnTimer = 1.5;
        camera.shake(16, 0.6);
        for (let i = 0; i < 4; i++) particles.energyBurst(this.x + this.w / 2, this.y + this.h * 0.5, ['#ffd45a', '#ff6ec7', '#7dd3fc', '#ffffff'][i]);
    }
    _startMove(key, input, audio, floatText) {
        let seq = (this.state === 'attack' || this.chainTimer > 0) ? this.chain + key : key;
        if (seq.length > 4) seq = key;
        let spec = COMBO_MOVES[seq];
        if (!spec) spec = seq.length === 3 ? COMBO_FALLBACK3[key] : seq.length === 4 ? COMBO_FINALE[key] : COMBO_MOVES[key];
        this.chain = seq; this.chainTimer = 0;
        this.move = spec; this.moveName = spec.name; this.moveDur = spec.dur;
        this.state = 'attack'; this.stateTimer = spec.dur; this.attackId++;
        this.limbSwap = !this.limbSwap;      // đòn liên tiếp luân phiên tay trái/phải, chân trái/phải
        this.hitTargets.clear(); this.skill2Active = false;
        const mx = input.moveX(); if (mx !== 0) this.facingRight = mx > 0;
        const dir = this.facingRight ? 1 : -1;
        this.vx = dir * spec.lunge * 14;
        if (spec.hop) { this.vy = -spec.hop; this.grounded = false; }
        audio.playSwing(spec);
        const big = seq.length >= 3;
        floatText.show(this.x + this.w / 2, this.y - 18, spec.name, big ? '#ffd45a' : '#e2e8f0', big ? 20 + seq.length * 2 : 15, 0.75);
    }

    // ------------------------------------------------------------------
    getHitbox() {
        const dir = this.facingRight ? 1 : -1, cx = this.x + this.w / 2;
        if (this.state === 'attack' && this.move) {
            const m = this.move, prog = 1 - this.stateTimer / this.moveDur;
            if (prog >= m.hit[0] && prog <= m.hit[1]) {
                if (m.spin) return { x: cx - m.reach, y: this.y + m.y, w: m.reach * 2, h: m.h };
                return { x: dir > 0 ? cx - 10 : cx - m.reach, y: this.y + m.y, w: m.reach + 10, h: m.h };
            }
        } else if (this.state === 'skill2' && this.skill2Active) {
            return { x: dir > 0 ? cx - 24 : cx - 76, y: this.y, w: 100, h: this.h };
        }
        return null;
    }
    getHurtbox() { return { x: this.x + 10, y: this.y + 5, w: this.w - 20, h: this.h - 10 }; }
    getDamage() {
        if (this.state === 'attack') return this.move ? this.move.dmg : 0;
        if (this.state === 'skill2') return 28;
        return 0;
    }
    // loại đòn đang tung: light / heavy / skill
    attackKind() { if (this.state === 'attack' && this.move) return this.move.kind; return 'skill'; }
    // Trả về: 'hit' | 'block' | 'perfect' | 'guardbreak' | 'none'
    takeDamage(amount, kbDir = 0, kbForce = 200, particles, floatText, audio, info = {}) {
        if (this.invulnTimer > 0 || this.defeated) return 'none';
        const cx = this.x + this.w / 2;
        const facingAttacker = this.facingRight ? kbDir < 0 : kbDir > 0;
        if (this.blocking && facingAttacker && !info.unblockable) {
            this.shieldFlash = 0.3;
            if (this.blockTime <= PERFECT_WINDOW) {              // PERFECT BLOCK
                this.perfectFlash = 0.4; this.counterTimer = 1.4; this.invulnTimer = 0.25;
                this.mp = Math.min(this.maxMp, this.mp + 12);
                this.vx = kbDir * 40;
                floatText.show(cx, this.y - 20, 'PERFECT BLOCK!', '#ffd45a', 24, 0.9);
                return 'perfect';
            }
            if (info.pierce) {                                    // đòn xuyên giáp: phá thế đỡ
                amount = Math.ceil(amount * 0.6); this.hp -= amount; this.blocking = false; this.blockCd = 0.8;
                this.state = 'hurt'; this.stateTimer = 0.35; this.vx = kbDir * kbForce * 0.6; this.hitFlash = 0.12; this.invulnTimer = 0.35;
                audio.playHit(1); floatText.show(cx, this.y - 14, `GUARD BREAK -${amount}`, '#fb923c', 18, 0.9);
                if (this.hp <= 0) this._die(kbDir);
                return 'guardbreak';
            }
            amount = Math.ceil(amount * 0.2);                     // đỡ thường: giảm 80%
            this.hp -= amount; this.vx = kbDir * kbForce * 0.15; this.invulnTimer = 0.12;
            floatText.show(cx, this.y - 14, amount > 0 ? `BLOCK -${amount}` : 'BLOCK', '#60a5fa', 18, 0.7);
            if (this.hp <= 0) this._die(kbDir);
            return 'block';
        }
        this.hp -= amount;
        this.chain = ''; this.chainTimer = 0; this.move = null; this.buffer = []; this.blocking = false; this.skill2Active = false;
        this.invulnTimer = 0.5; this.hitFlash = 0.15; this.vx = kbDir * kbForce;
        if (info.stun) { this.stunTimer = info.stun; this.state = 'hurt'; this.stateTimer = info.stun; }
        else if (amount >= 20) { this.state = 'knockback'; this.stateTimer = 0.3; this.vy = -150; }
        else { this.state = 'hurt'; this.stateTimer = 0.2; }
        audio.playHit(amount / 20); audio.playHurt();
        particles.hitSpark(cx, this.y + this.h * 0.4, '#ff5577');
        floatText.show(cx, this.y - 10, `-${amount}`, '#ff5577', 22);
        if (this.hp <= 0) this._die(kbDir);
        return 'hit';
    }
    // Hồi sinh bằng ETERNAL DANCE: đứng dậy ngay, bất tử vài giây cho tới khi hiệu ứng nổ
    revive() {
        this.defeated = false; this.hp = Math.max(1, this.hp); this.state = 'idle'; this.stateTimer = 0; this.vx = 0; this.vy = 0;
        this.stunTimer = 0; this.invulnTimer = 4; this.hitFlash = 0; this.blocking = false; this.chain = ''; this.move = null; this.skill2Active = false;
    }
    _die(kbDir) { this.hp = 0; this.defeated = true; this.state = 'knockdown'; this.stateTimer = 999; this.vy = -300; this.vx = kbDir * 300; }

    // ------------------------------------------------------------------
    // Tư thế khung xương theo trạng thái
    _pose() {
        const t = this.t, st = this.state;
        const tok = (n) => rpose(n);
        switch (st) {
            case 'run': return this.dashTimer > 0 ? RPOSE.dashRun : runPose(this.runPhase);
            case 'jump': {
                if (this.flipTimer > 0) { const p = 1 - this.flipTimer / 0.55; return Object.assign({}, RPOSE.tuck, { lean: p * Math.PI * 2 * (this.facingRight ? 1 : 1) }); }
                return lerpPose(RPOSE.jumpUp, RPOSE.jumpFall, clamp(0.5 + this.vy / 1200, 0, 1));
            }
            case 'fall': return lerpPose(RPOSE.jumpUp, RPOSE.jumpFall, clamp(0.5 + this.vy / 900, 0.5, 1));
            case 'block': return this.perfectFlash > 0 ? RPOSE.perfect : lerpPose(RPOSE.stand, RPOSE.block, smooth01(this.blockTime / 0.1));
            case 'attack': {
                const m = this.move; if (!m) return RPOSE.stand;
                const p = clamp(1 - this.stateTimer / this.moveDur, 0, 0.999), n = m.frames.length, f = p * n, i = Math.floor(f);
                const a = tok(m.frames[i]), b = tok(m.frames[Math.min(n - 1, i + 1)]);
                const pose = lerpPose(a, b, smooth01(f - i));
                if (m.spin) pose.lean = clamp((p - m.hit[0] + 0.05) / (m.hit[1] - m.hit[0] + 0.1), 0, 1) * Math.PI * 2;
                else if (m.lean) pose.lean = m.lean;
                return pose;
            }
            case 'skill1': return dancePose(t);
            case 'skill2': {
                const e = THRUST_DUR - this.stateTimer;
                if (e < 0.18) return lerpPose(RPOSE.stand, RPOSE.thrustWind, smooth01(e / 0.18));
                if (e < 0.46) return RPOSE.thrust;
                return lerpPose(RPOSE.thrust, RPOSE.stand, smooth01((e - 0.46) / 0.2));
            }
            case 'skill3': {
                const e = CHUONG_DUR - this.stateTimer, F = CHUONG_FIRE;
                if (e < 0.16) return lerpPose(RPOSE.stand, RPOSE.chuongGather, smooth01(e / 0.16));
                if (e < F) return RPOSE.chuongGather;
                if (e < F + 0.1) return lerpPose(RPOSE.chuongGather, RPOSE.chuongFire, smooth01((e - F) / 0.1));
                if (e < 1.12) return RPOSE.chuongFire;
                return lerpPose(RPOSE.chuongFire, RPOSE.stand, smooth01((e - 1.12) / 0.18));
            }
            case 'ultimate': {
                const T = this.ultT;
                if (T < 0.7) return lerpPose(RPOSE.stand, RPOSE.flexUlt, smooth01(T / 0.5));
                if (T < 3.3) { const d = dancePose(t * 1.2); d.flex = 0.8; return d; }
                return lerpPose(RPOSE.j4, RPOSE.victory, smooth01((T - 3.3) / 0.4));
            }
            case 'hurt': case 'knockback': {
                if (this.stunTimer > 0) { const w = Math.sin(t * 14); return Object.assign({}, RPOSE.hit, { tilt: w * 0.25, head: -w * 0.3, hf: [10, 30 + w * 6], hb: [-10, 30 - w * 6] }); }
                return RPOSE.hit;
            }
            case 'knockdown': case 'defeat': return RPOSE.down;
            case 'getup': return lerpPose(RPOSE.down, RPOSE.stand, smooth01(1 - this.stateTimer / 0.4));
            case 'victory': return Object.assign({}, RPOSE.victory, { by: -Math.abs(Math.sin(t * 5)) * 6 });
            default: return idlePose(t);
        }
    }
    // Chọn khung hình sprite (sprite sheet pixel-art mới) theo trạng thái hiện tại.
    // Trả về { k: tên khung, rot, by, sx, sy, fl, feet, lift } — xem RicardoSprite.render().
    _sprite() {
        if (this.entr) return this.entr.spr;      // cảnh ra mắt khi vào màn: khung hình do Game điều khiển
        const t = this.t, st = this.state, age = this.stateAge || 0;
        switch (st) {
            case 'run': {
                if (this.dashTimer > 0) return { k: 'skill_2' };                          // lướt: khung lao tới có vệt gió
                const fast = Math.abs(this.vx) > this.speed * 1.4;                         // chạy nhanh (nhấn đúp A/D) dùng khung RUN
                return fast ? { k: 'sprint_' + (Math.floor(this.runPhase * RicardoSprite.RUN_K) % RicardoSprite.RUN_N) } : { k: 'walk_' + (Math.floor(this.runPhase * RicardoSprite.WALK_K) % RicardoSprite.WALK_N) };
            }
            case 'jump': case 'fall': {
                if (this.flipTimer > 0) { const p = 1 - this.flipTimer / 0.55; return { k: 'jump_1', rot: p * Math.PI * 2, sx: 0.94, sy: 0.94 }; }   // nhảy đôi: lộn vòng
                if (this.takeoffT > 0) return { k: 'jump_0' };
                return { k: 'jump_1' };
            }
            case 'block': return { k: 'attack_0', sx: this.perfectFlash > 0 ? 1.05 : 1, sy: 0.97 };       // thế thủ: hai tay giơ
            case 'attack': {
                const m = this.move; if (!m) return { k: 'attack_0' };
                const p = clamp(1 - this.stateTimer / this.moveDur, 0, 0.999), n = m.frames.length, tok = m.frames[Math.floor(p * n)];
                const r = { k: SPR_TOK[tok] || 'attack_0' };
                if (m.spin) r.rot = clamp((p - m.hit[0] + 0.05) / (m.hit[1] - m.hit[0] + 0.1), 0, 1) * Math.PI * 2;
                else if (m.lean) r.rot = m.lean;
                return r;
            }
            case 'skill1': return RicardoSprite.dance(t);                                      // DACNE: nhảy meme
            case 'skill2': {                                                                   // THRUST: lấy đà -> lao tới -> thu thế
                const e = THRUST_DUR - this.stateTimer;
                if (e < 0.18) return { k: 'attack_0', sx: 1.03 };
                if (e < 0.46) return { k: 'skill_2' };
                return { k: 'attack_3' };
            }
            case 'skill3': {                                                                   // SHOCKWAVE: ngồi nén -> xoay trên không -> đập xuống
                const e = CHUONG_DUR - this.stateTimer, F = CHUONG_FIRE, R = RicardoSprite;      // mọi chuyển khung đều hòa trộn mượt
                if (e < 0.2) return R.bl('idle_0', 'attack_0', e / 0.2);                          // vào thế
                if (e < F) return R.bl('attack_0', 'attack_2', (e - 0.2) / (F - 0.2), { by: Math.sin(this.t * 55) * 0.8 });   // hạ thấp, nạp khí
                if (e < F + 0.1) return R.bl('attack_2', 'attack_1', (e - F) / 0.1, { sx: 1.06 });     // đẩy tay ra bắn
                if (e < 1.12) return { k: 'attack_1', sx: 1.03, by: Math.sin(this.t * 70) * 0.6 };      // giữ tia
                return R.bl('attack_1', 'idle_0', (e - 1.12) / 0.18);                              // thu thế
            }
            case 'ultimate': {                                                                 // ETERNAL DANCE
                const T = this.ultT;
                if (T < 0.7) return { k: 'skill_1', by: Math.sin(t * 40) * 1.5 };
                if (T < 3.3) { const d = RicardoSprite.dance(t * 1.2); d.k = (Math.floor(t * 2.4) % 2) ? 'skill_1' : d.k; return d; }     // đứng yên nhảy điệu DACNE
                return { k: 'attack_1', sx: 1.08, sy: 1.08 };
            }
            case 'hurt': case 'knockback': {
                const r = { k: age < 0.14 ? 'hurt_0' : (this.stateTimer < 0.08 ? 'hurt_2' : 'hurt_1') };
                if (this.stunTimer > 0) r.rot = Math.sin(t * 14) * 0.07;
                return r;
            }
            case 'knockdown': case 'defeat': return { k: 'hurt_0', rot: -clamp(age * 6, 0, 1) * 1.45, feet: true, lift: 18 };   // ngã ngửa
            case 'getup': return { k: 'hurt_0', rot: -(1 - clamp(age / 0.4, 0, 1)) * 1.45, feet: true, lift: 18 };
            case 'victory': return { k: 'skill_0', by: -Math.abs(Math.sin(t * 5)) * 6 };
            default:
                if (this.landT > 0) return { k: 'jump_2' };                                    // tiếp đất
                return RicardoSprite.idle(t);
        }
    }
    draw(ctx, cam) {
        if (this.hidden) return;
        const sx = cam.screenX(this.x + this.w / 2), feetY = cam.screenY(this.y + this.h);
        if (sx < -150 || sx > W + 150) return;
        const dir = this.facingRight ? 1 : -1;
        // hậu ảnh
        for (const a of this.afterImages) {
            ctx.save(); ctx.globalAlpha = clamp(a.alpha, 0, 1) * 0.5;
            Rig.render(ctx, this.style, a.pose, { x: cam.screenX(a.x + this.w / 2), y: cam.screenY(a.y + this.h), facing: a.face ? 1 : -1, t: this.t, aura: null, spr: a.spr });
            ctx.restore();
        }
        // bóng dưới chân (nhỏ dần khi nhảy cao)
        const gh = clamp(1 - (GROUND_Y - (this.y + this.h)) / 400, 0.3, 1);
        ctx.fillStyle = '#00000055'; ctx.beginPath(); ctx.ellipse(sx, cam.screenY(GROUND_Y) + 2, 40 * gh, 9 * gh, 0, 0, 6.283); ctx.fill();
        // hào quang ETERNAL DANCE
        const aura = (this.eternalTimer > 0 || this.state === 'ultimate' || this.auraT > 0 || this.entr) ? '#ffd45a' : null;
        ctx.save();
        if (this.invulnTimer > 0 && this.state !== 'ultimate' && Math.floor(this.invulnTimer * 12) % 2 === 0 && this.hitFlash <= 0) ctx.globalAlpha = 0.82;   // nháy nhẹ khi bất tử tạm (không làm nhân vật biến mất)
        const _pz = this._pose(); _pz.mirror = (_pz.mirror === undefined ? 1 : _pz.mirror) * (this.mirrorK === undefined ? 1 : this.mirrorK);
        if (this.suck) { const m = feetY - 64; ctx.translate(sx, m); ctx.rotate(this.suck.rot); ctx.scale(this.suck.s, this.suck.s); ctx.translate(-sx, -m); }      // bị hút vào cổng: xoay + thu nhỏ
        Rig.draw(ctx, this.style, _pz, { x: sx, y: feetY, facing: dir, t: this.t, flash: this.hitFlash > 0 ? this.hitFlash / 0.15 : 0, aura, spr: this._sprite() });
        ctx.restore();
        this._drawEffects(ctx, cam, sx, feetY, dir);
    }
    // nổ tia sáng tại kẻ địch trúng chưởng
    _chuongHit(ctx, x, y, h) {
        const p = h.t / 0.4, a = (1 - p) * (1 - p * 0.3), r = 26 + 60 * p;
        ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = a;
        const g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(255,255,255,0.95)'); g.addColorStop(0.4, 'rgba(125,211,252,0.6)'); g.addColorStop(1, 'rgba(56,189,248,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, 6.283); ctx.fill();
        ctx.strokeStyle = 'rgba(224,242,254,0.9)'; ctx.lineWidth = 3;
        for (let i = 0; i < 10; i++) { const an = h.seed + i * 0.628, r0 = r * 0.5, r1 = r * (1.2 + (i % 3) * 0.25); ctx.beginPath(); ctx.moveTo(x + Math.cos(an) * r0, y + Math.sin(an) * r0); ctx.lineTo(x + Math.cos(an) * r1, y + Math.sin(an) * r1); ctx.stroke(); }
        ctx.restore();
    }
    // tia CHƯỞNG vẽ bằng gradient nhiều lớp (cộng sáng) + dòng năng lượng chảy
    _beamGfx(ctx, bx, by, dir, len, th, alpha, t) {
        if (len < 4 || alpha <= 0.004) return;
        ctx.save(); ctx.translate(bx, by); ctx.scale(dir, 1); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = clamp(alpha, 0, 1);
        const H = 44 * th;
        for (const [k, col] of [[1.55, 'rgba(37,99,235,0.30)'], [1.0, 'rgba(56,189,248,0.55)'], [0.55, 'rgba(186,230,253,0.85)'], [0.24, 'rgba(255,255,255,0.98)']]) {
            const h = H * k * (1 + 0.04 * Math.sin(t * 60 + k * 5));
            ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(0, -h * 0.45); ctx.lineTo(Math.max(0, len - h * 1.1), -h); ctx.quadraticCurveTo(len + h * 0.9, 0, Math.max(0, len - h * 1.1), h); ctx.lineTo(0, h * 0.45); ctx.closePath(); ctx.fill();
        }
        ctx.lineCap = 'round';                                                              // vệt năng lượng chạy dọc tia
        for (let i = 0; i < 12; i++) {
            const yy = (((i * 0.6180339) % 1) - 0.5) * H * 1.6, sp = 700 + (i % 4) * 160, L = 50 + (i % 3) * 40, x0 = ((t * sp + i * 131) % (len + L)) - L;
            ctx.strokeStyle = i % 2 ? 'rgba(255,255,255,0.7)' : 'rgba(125,211,252,0.7)'; ctx.lineWidth = 2 + (i % 2);
            ctx.beginPath(); ctx.moveTo(Math.max(0, x0), yy); ctx.lineTo(Math.min(len, x0 + L), yy); ctx.stroke();
        }
        const g = ctx.createRadialGradient(len, 0, 0, len, 0, H * 2.2); g.addColorStop(0, 'rgba(255,255,255,0.9)'); g.addColorStop(0.4, 'rgba(125,211,252,0.5)'); g.addColorStop(1, 'rgba(56,189,248,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(len, 0, H * 2.2, 0, 6.283); ctx.fill();   // đầu tia
        ctx.restore();
    }
    // CHƯỞNG: quả cầu nạp khí ở bàn tay + vòng hút khí dưới chân + tia năng lượng
    _drawChuong(ctx, cam, sx, feetY, dir) {
        const e = CHUONG_DUR - this.stateTimer, t = this.t;
        const hp = this._hand(dir, e < CHUONG_FIRE ? clamp(e / CHUONG_FIRE, 0, 1) * 0.4 : 1), hx = cam.screenX(hp.x), hy = cam.screenY(hp.y);
        if (e < CHUONG_FIRE + 0.12) {
            const p = clamp(e / CHUONG_FIRE, 0, 1), fade = e < CHUONG_FIRE ? 1 : 1 - (e - CHUONG_FIRE) / 0.12;
            ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = fade;
            const r = 8 + 36 * smooth01(p) + Math.sin(t * 40) * 2, g = ctx.createRadialGradient(hx, hy, 0, hx, hy, r * 2.2);
            g.addColorStop(0, 'rgba(255,255,255,0.95)'); g.addColorStop(0.3, 'rgba(125,211,252,0.7)'); g.addColorStop(1, 'rgba(56,189,248,0)');
            ctx.fillStyle = g; ctx.beginPath(); ctx.arc(hx, hy, r * 2.2, 0, 6.283); ctx.fill();
            ctx.strokeStyle = 'rgba(186,230,253,0.85)'; ctx.lineWidth = 2;
            for (let k = 0; k < 2; k++) { ctx.beginPath(); ctx.ellipse(hx, hy, r * (1.1 + k * 0.45), r * (0.5 + k * 0.2), t * (6 + k * 3) * (k ? -1 : 1), 0, 6.283); ctx.stroke(); }
            const q = 1 - p; ctx.strokeStyle = 'rgba(56,189,248,' + (0.6 * p + 0.15) + ')'; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.ellipse(sx, feetY, 30 + q * 90, 7 + q * 16, 0, 0, 6.283); ctx.stroke();
            ctx.restore();
        }
        const B = this.beam;
        if (B) {
            const bx = cam.screenX(B.ox), by = cam.screenY(B.oy);
            this._beamGfx(ctx, bx, by, B.dir, B.len, B.thick, B.alpha, B.t);
            ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = B.alpha;
            const mr = 70 * (0.6 + 0.4 * B.thick), g = ctx.createRadialGradient(bx, by, 0, bx, by, mr);
            g.addColorStop(0, 'rgba(255,255,255,0.9)'); g.addColorStop(0.35, 'rgba(125,211,252,0.55)'); g.addColorStop(1, 'rgba(56,189,248,0)');
            ctx.fillStyle = g; ctx.beginPath(); ctx.arc(bx, by, mr, 0, 6.283); ctx.fill();
            ctx.restore();
        }
    }
    _drawEffects(ctx, cam, sx, feetY, dir) {
        const cy = feetY - 70;
        if (this.blocking || this.shieldFlash > 0) {        // khiên năng lượng pixel kiểu huy hiệu lục giác
            const hit = this.shieldFlash > 0;
            const perfect = this.perfectFlash > 0;
            const f = perfect ? 1 : (hit ? 0.9 : 0.72);
            const pulse = 1 + Math.sin(this.t * 8) * 0.018;
            ctx.save();
            ctx.translate(sx + dir * 43, cy);
            ctx.scale(dir * pulse, pulse);
            ctx.globalAlpha = f;
            ctx.globalCompositeOperation = 'lighter';
            const edge = perfect ? '#ffe08a' : '#31dfff';
            const edgeSoft = perfect ? 'rgba(255,190,70,0.42)' : 'rgba(0,170,255,0.42)';
            const pts = [[0,-65],[39,-48],[48,-8],[37,37],[0,66],[-37,37],[-48,-8],[-39,-48]];
            const shieldPath = () => { ctx.beginPath(); pts.forEach((p,i) => i ? ctx.lineTo(p[0],p[1]) : ctx.moveTo(p[0],p[1])); ctx.closePath(); };

            // Quầng sáng và lớp khiên ngoài.
            ctx.shadowColor = edge; ctx.shadowBlur = perfect ? 30 : 24;
            const halo = ctx.createRadialGradient(0,0,8,0,0,82);
            halo.addColorStop(0,'rgba(35,190,255,0.04)'); halo.addColorStop(0.68,edgeSoft); halo.addColorStop(1,'rgba(0,90,255,0)');
            ctx.fillStyle = halo; ctx.beginPath(); ctx.ellipse(0,0,62,79,0,0,Math.PI*2); ctx.fill();
            shieldPath(); ctx.fillStyle = 'rgba(4,24,74,0.82)'; ctx.fill();
            ctx.strokeStyle = perfect ? 'rgba(255,245,190,0.95)' : 'rgba(24,224,255,0.95)'; ctx.lineWidth = 7; ctx.stroke();

            // Lõi quốc kỳ Mỹ, được cắt gọn bên trong mặt khiên.
            ctx.save(); shieldPath(); ctx.clip();
            ctx.globalCompositeOperation = 'source-over';
            ctx.fillStyle = '#102d83'; ctx.fillRect(-48,-66,96,132);
            for (let i=0;i<13;i++) {
                const yy=-64+i*10.1;
                ctx.fillStyle = i%2===0 ? '#f5f7ff' : '#ed3154';
                ctx.fillRect(-49,yy,98,10.1);
            }
            ctx.fillStyle = '#1245a5'; ctx.fillRect(-48,-65,48,70);
            // Sao pixel nhỏ xếp hàng trên nền xanh.
            ctx.fillStyle = '#ffffff';
            for (let r=0;r<5;r++) for (let c=0;c<5;c++) {
                const x=-41+c*9.1+(r%2)*3.8, y=-57+r*12.2;
                ctx.fillRect(Math.round(x),Math.round(y),3,3);
                ctx.fillRect(Math.round(x+1),Math.round(y-1),1,5);
            }
            // Ánh phản quang chéo trên mặt khiên.
            const sheen=ctx.createLinearGradient(-45,-45,42,45);
            sheen.addColorStop(0,'rgba(160,250,255,0.30)'); sheen.addColorStop(0.45,'rgba(70,210,255,0.05)'); sheen.addColorStop(1,'rgba(255,255,255,0.18)');
            ctx.fillStyle=sheen; ctx.fillRect(-50,-70,100,140);
            ctx.restore();

            // Hai vòng viền cyan tạo cảm giác khiên nhiều lớp.
            ctx.globalCompositeOperation = 'lighter';
            shieldPath(); ctx.strokeStyle = 'rgba(145,250,255,0.95)'; ctx.lineWidth = 3; ctx.stroke();
            ctx.save(); ctx.scale(0.84,0.88); shieldPath(); ctx.strokeStyle = 'rgba(35,170,255,0.82)'; ctx.lineWidth = 3; ctx.stroke(); ctx.restore();
            ctx.strokeStyle = 'rgba(255,255,255,0.75)'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.moveTo(-27,-43); ctx.lineTo(-8,-55); ctx.lineTo(12,-53); ctx.stroke();

            // Các ô pixel năng lượng chạy quanh cạnh khiên.
            for (let i=0;i<14;i++) {
                const a=this.t*1.8+i*Math.PI*2/14;
                const x=Math.cos(a)*46, y=Math.sin(a)*61;
                ctx.fillStyle = i%3===0 ? '#ffffff' : (perfect ? '#ffe08a' : '#66f5ff');
                ctx.fillRect(Math.round(x/3)*3-2,Math.round(y/3)*3-2,4,4);
            }
            // Tia nứt lóe ra khi đỡ trúng đòn; Perfect Block sáng mạnh hơn.
            if (hit) {
                const strength = perfect ? 1 : clamp(this.shieldFlash/0.3,0,1);
                ctx.globalAlpha *= strength;
                ctx.strokeStyle = '#ffffff'; ctx.lineWidth = perfect ? 4 : 2;
                for (let k=0;k<5;k++) {
                    const yy=-34+k*17, len=12+(k%3)*5;
                    ctx.beginPath(); ctx.moveTo(34,yy); ctx.lineTo(42+len,yy-7+(k%2)*13); ctx.lineTo(47+len,yy-3+(k%2)*13); ctx.stroke();
                }
                for (let k=0;k<8;k++) {
                    const a=k*Math.PI/4+this.t*2, x=49+Math.cos(a)*9, y=Math.sin(a)*24;
                    ctx.fillStyle='#ffffff'; ctx.fillRect(Math.round(x),Math.round(y),4,4);
                }
            }
            ctx.restore();
        }
        if (this.stunTimer > 0.1) {                         // sao choáng
            ctx.save(); ctx.fillStyle = '#ffd45a'; ctx.strokeStyle = '#7a4c0c'; ctx.lineWidth = 1.5;
            for (let k = 0; k < 3; k++) {
                const a = this.t * 9 + k * 2.094, px = sx + Math.cos(a) * 24, py = feetY - 150 + Math.sin(a) * 6;
                ctx.beginPath(); for (let q = 0; q < 8; q++) { const r = q % 2 ? 2.5 : 6; const an = q * Math.PI / 4; ctx.lineTo(px + Math.cos(an) * r, py + Math.sin(an) * r); } ctx.closePath(); ctx.fill(); ctx.stroke();
            }
            ctx.restore();
        }
        if (this.counterTimer > 0 && Math.floor(this.t * 10) % 2 === 0) {       // cơ hội phản công
            ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = 'rgba(255,212,90,0.4)';
            ctx.beginPath(); ctx.arc(sx + dir * 30, feetY - 100, 24, 0, 6.283); ctx.fill(); ctx.restore();
        }
        if (this.state === 'attack' && this.move) {         // vệt chém theo từng đòn
            const m = this.move, p = 1 - this.stateTimer / this.moveDur, t0 = m.hit[0] - 0.05, t1 = m.hit[1] + 0.1;
            if (p >= t0 && p <= t1) {
                const t = clamp((p - t0) / (t1 - t0), 0, 1), wy = this.y + m.y + m.h / 2, ay = cam.screenY(wy), ez = 1 - Math.pow(1 - t, 2.2), F = pfx();
                const fade = t < 0.72 ? 1 : (1 - t) / 0.28, light = !m.spin && !m.launch && m.dmg < 14, seed = this.attackId * 13;
                if (light) {                                   // đòn nhẹ: vạch gió pixel lao tới trước nắm đấm
                    PXFX.drawThrust(ctx, sx + dir * 14, ay, dir, m.reach * 0.95, t, m.arc);
                } else if (m.spin) {                           // đòn xoay: vòng elip ô vuông quét quanh thân (+ vòng thứ 2 lệch pha)
                    const hd = ez * Math.PI * 3.2, R = m.reach * (0.62 + t * 0.38);
                    PXFX.drawSwing(ctx, sx, ay, dir, R, 16 + m.dmg / 3, hd - 3.0, hd, m.arc, fade, 0.3, seed);
                    PXFX.drawSwing(ctx, sx, ay, dir, R * 0.78, 8, hd - 1.8 + 3.14, hd + 3.14, '#ffffff', fade * 0.8, 0.3, seed + 5);
                } else {                                       // đòn nặng: trăng khuyết quét; đòn hất (uppercut/rising) quét từ dưới lên
                    const up = m.launch ? -1 : 1, a0 = -1.0 * up, a1 = 1.0 * up, head = a0 + (a1 - a0) * ez, tail = head - up * 1.5, R = m.reach * 0.78, th = 16 + m.dmg / 2.2;
                    PXFX.drawSwing(ctx, sx, ay, dir, R, th, tail, head, m.arc, fade, 1, seed);
                    if (m.dmg >= 24) PXFX.drawSwing(ctx, sx, ay, dir, R * 0.84, th * 0.4, tail - up * 0.2, head - up * 0.3, '#ffffff', fade * 0.85, 1, seed + 9);
                    if (F && Math.random() < 0.6) { const hx = this.x + this.w / 2 + dir * Math.cos(head) * R, hy = wy + Math.sin(head) * R; F.sparks(hx, hy, 1, { col: ['#ffffff', m.arc], min: 20, max: 110, g: 120, life: 0.3, size: 3 }); }   // tàn lửa ở đầu vệt
                }
            }
        }
        if (this.state === 'skill1') {                      // vòng năng lượng DACNE
            const p = (this.t * 1.5) % 1;
            ctx.save(); ctx.globalAlpha = 0.6 * (1 - p); ctx.strokeStyle = '#4ade80'; ctx.shadowColor = '#4ade80'; ctx.shadowBlur = 14; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.ellipse(sx, feetY, 50 + p * 70, 14 + p * 14, 0, 0, 6.283); ctx.stroke(); ctx.restore();
        }
        if (this.state === 'skill3') this._drawChuong(ctx, cam, sx, feetY, dir);
        for (const h of (this.hitFx || [])) this._chuongHit(ctx, cam.screenX(h.x), cam.screenY(h.y), h);
        if (this.state === 'skill2' && !this.skill2Active && THRUST_DUR - this.stateTimer < 0.18) {   // gồng lấy đà
            const p = (THRUST_DUR - this.stateTimer) / 0.18;
            ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = `rgba(244,114,182,${p})`; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.arc(sx, cy, 70 * (1.2 - p), 0, 6.283); ctx.stroke(); ctx.restore();
        }
    }
}

// ============================================================
// ENEMY PROJECTILE — đạn của quái meme (nốt nhạc, bong bóng COPE, vỏ chuối, quả cầu meme, sóng đất...)
// ============================================================
class EnemyProjectile {
    constructor(x, y, vx, vy, w, h, damage, life, color, glowColor, o = {}) {
        this.x = x; this.y = y; this.vx = vx; this.vy = vy; this.w = w; this.h = h;
        this.damage = damage; this.life = life; this.maxLife = life;
        this.color = color || '#ff3366'; this.glowColor = glowColor || '#ff0033';
        this.kind = o.kind || 'orb'; this.label = o.label || ''; this.headKey = o.headKey || null;
        this.gravity = o.gravity || 0; this.ground = !!o.ground; this.pierce = !!o.pierce; this.slip = !!o.slip;
        this.kb = o.kb || 180; this.stun = o.stun || 0; this.spin = o.spin || 0; this.rot = 0;
        this.dead = false; this.armT = o.armT || 0; this.cols = o.cols || null; this.age = 0;
    }
    update(dt, particles, groundY) {
        this.age += dt;
        this.life -= dt; if (this.life <= 0) this.dead = true;
        this.vy += this.gravity * dt;
        this.x += this.vx * dt; this.y += this.vy * dt; this.rot += this.spin * dt;
        if (this.kind === 'banana' && groundY !== undefined && this.y + this.h > groundY) { this.y = groundY - this.h; this.vy = 0; this.vx *= 0.9; }
        const F = pfx();
        if (this.kind === 'meteor') {
            if (groundY !== undefined && this.y + this.h >= groundY) {      // thiên thạch chạm đất: nổ pixel + vùng sát thương ngắn
                this.y = groundY - this.h; this.vx = this.vy = 0; this.kind = 'meteorImpact'; this.life = Math.min(this.life, 0.28);
                if (F) { F.groundBlast(this.x + this.w / 2, groundY, 150, ['#fff7ae', '#ffb02e', '#ff5a1f']); F.pop(this.x + this.w / 2, groundY - 20, 110, '#fff7ae', 0.3); }
                return;
            }
            if (F && Math.random() < 0.7) F.sparks(this.x + this.w / 2, this.y + 6, 1, { col: ['#fff7ae', '#ffb02e', '#ff5a1f'], angle: -Math.PI / 2, cone: 0.7, min: 30, max: 120, g: 0, life: 0.4 });
            return;
        }
        if (this.kind === 'meteorImpact') { this.vx = this.vy = 0; return; }
        if (F && (this.kind === 'orb' || this.kind === 'wave')) {          // vệt hạt vuông phía sau đạn
            if (Math.random() > (this.kind === 'wave' ? 0.7 : 0.45)) F.sparks(this.x + this.w / 2, this.y + this.h / 2, 1, { col: [this.glowColor, '#ffffff'], min: 10, max: 60, g: 0, life: 0.35, size: 3 });
            return;
        }
        if (Math.random() > 0.5 && this.kind !== 'banana') particles.emit(this.x + this.w / 2, this.y + this.h / 2, 1, { vxRand: 20, vyRand: 20, life: 0.25, color: this.glowColor, size: 3, gravity: 0 });
    }
    draw(ctx, cam) {
        const cx = cam.screenX(this.x + this.w / 2), cy = cam.screenY(this.y + this.h / 2);
        ctx.save(); ctx.translate(cx, cy);
        if (this.kind === 'note') {
            ctx.shadowColor = this.glowColor; ctx.shadowBlur = 14; ctx.fillStyle = this.color; ctx.font = 'bold 34px Arial'; ctx.textAlign = 'center'; ctx.rotate(Math.sin(this.rot) * 0.3);
            ctx.strokeStyle = '#000'; ctx.lineWidth = 4; ctx.strokeText('\u266A', 0, 10); ctx.fillText('\u266A', 0, 10);
        } else if (this.kind === 'cope') {
            ctx.rotate(Math.sin(this.rot) * 0.15);
            ctx.fillStyle = '#f8fafc'; ctx.strokeStyle = '#111'; ctx.lineWidth = 3;
            roundRect(ctx, -38, -17, 76, 34, 12); ctx.fill(); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(-14, 16); ctx.lineTo(-24, 28); ctx.lineTo(-4, 16); ctx.closePath(); ctx.fill(); ctx.stroke();
            ctx.fillStyle = '#111'; ctx.font = 'bold 15px Arial'; ctx.textAlign = 'center'; ctx.fillText(this.label || 'COPE', 0, 5);
        } else if (this.kind === 'banana') {      // vỏ chuối pixel-art: xoay khi bay, nằm yên lấp lánh + dấu ! khi đã rơi xuống đất
            const still = Math.abs(this.vy) < 5 && Math.abs(this.vx) < 30;
            PXFX.blit(ctx, PXFX.spr.banana, 0, 0, 2.5, { rot: still ? 0.5 : this.rot * 0.9 });
            if (still) {
                const k = Math.floor(performance.now() / 260) % 2;
                PXFX.blit(ctx, PXFX.spr.bang, 0, -30 - k * 3, 2, {});
                if (k) PXFX.blit(ctx, PXFX.spr.spark, 14, -8, 2, {});
            }
        } else if (this.kind === 'orb') {        // cầu meme: đầu pixel hoá trong đĩa năng lượng
            PXFX.drawOrb(ctx, 0, 0, this.w / 2, this.headKey && Heads.get(this.headKey), this.age, '#1b1240', this.glowColor);
        } else if (this.kind === 'meteorImpact') {
            ctx.fillStyle = '#fff7ae'; ctx.strokeStyle = '#f97316'; ctx.lineWidth = 4; ctx.fillRect(-this.w / 2, -this.h / 2, this.w, this.h); ctx.strokeRect(-this.w / 2, -this.h / 2, this.w, this.h);
        } else if (this.kind === 'meteor') {
            PXFX.drawMeteor(ctx, 0, 0, this.w / 2, this.headKey && Heads.get(this.headKey), this.age, this.vy);
        } else if (this.kind === 'wave') {     // sóng đất dạng gai tinh thể pixel: phải nhảy qua
            const dir = this.vx > 0 ? 1 : -1, c = this.cols || [PXFX.mix(this.color, '#ffffff', 0.8), this.color, this.glowColor, PXFX.mix(this.glowColor, '#000000', 0.6)];
            PXFX.drawSpikeWave(ctx, 0, 0, this.w, this.h, dir, this.age, c);
        } else {
            ctx.shadowColor = this.glowColor; ctx.shadowBlur = 12; ctx.fillStyle = this.color; ctx.beginPath(); ctx.arc(0, 0, this.w / 2, 0, 6.283); ctx.fill();
        }
        ctx.restore();
    }
    getHitbox() { return { x: this.x, y: this.y, w: this.w, h: this.h }; }
}

// Cột lửa của Meme Lord (phase 3): vòng rune cảnh báo -> cột nổ lên đúng chỗ đó, sát thương xuyên giáp
class TrollPillar extends EnemyProjectile {
    constructor(x, groundY, delay, col, col2) {
        super(x - 46, groundY - 640, 0, 0, 92, 640, 16, delay + 0.55, col, col2, { kind: 'pillar', pierce: true, kb: 320, armT: delay });
        this.gy = groundY; this.cx0 = x; this.fired = false; this.col2 = col2; this.delay = delay;
        const F = pfx(); if (F) { F.circle(x, groundY, 210, delay + 0.1, col, '#ffffff', { grow: 0.5, fade: 0.12, spin: 2.2 }); F.mark(x, groundY, delay, col); }
    }
    update(dt, particles, groundY) {
        this.age += dt; this.life -= dt; if (this.life <= 0) this.dead = true;
        if (this.armT > 0) { this.armT -= dt; if (this.armT <= 0 && !this.fired) { this.fired = true; const F = pfx(); if (F) { F.pillar(this.cx0, this.gy, 140, 760, 0.55, this.color, this.col2); F.groundBlast(this.cx0, this.gy, 160, [this.col2, '#ffffff', this.color]); F.pop(this.cx0, this.gy - 40, 130, '#ffffff', 0.3); } } }
    }
    draw() { /* vẽ bằng PixelFx */ }
}

// ============================================================
// ENEMY BASE — máy trạng thái chung: idle / chase / windup / active / recover / hurt / death
// Mỗi quái meme khai báo bảng `attacks` + hàm chooseAttack() / onHitFilter() riêng.
// ============================================================
const ENEMY_RPOSE = {
    slapWind: { h: 0.96, tilt: -0.15, hf: [-6, -8], hb: [10, 4], ff: [22, 0], fb: [-20, 0] },
    slap: { h: 0.94, tilt: 0.3, hf: [52, -2], hb: [-4, 6], ff: [30, 0], fb: [-26, 0] },
    crouch: { h: 0.68, tilt: 0.15, hf: [16, 26], hb: [6, 28], ff: [24, 0], fb: [-20, 0] },
    stompHit: { h: 0.78, tilt: 0.35, hf: [34, 24], hb: [20, 26], ff: [36, 0], fb: [-8, 0] },
    airTuck: { h: 0.8, tilt: 0.2, hf: [20, -20], hb: [6, -16], ff: [18, -34], fb: [-12, -28] },
    castUp: { h: 0.97, tilt: -0.1, hf: [24, -58], hb: [10, -52], ff: [18, 0], fb: [-16, 0] },
    shoot: { h: 0.96, tilt: 0.14, hf: [56, -18], hb: [40, -6], ff: [22, 0], fb: [-20, 0] },
    flexChad: { h: 0.92, flex: 1, tilt: -0.05, hf: [26, -46], hb: [-8, -48], ff: [26, 0], fb: [-24, 0] },
    chadWind: { h: 0.9, tilt: -0.3, hf: [-14, -8], hb: [10, 0], ff: [28, 0], fb: [-26, 0] },
    chadPunch: { h: 0.9, tilt: 0.45, flex: 0.6, hf: [64, -6], hb: [0, 10], ff: [40, 0], fb: [-34, 0] },
    pound: { h: 0.55, tilt: 0.6, hf: [30, 40], hb: [16, 44], ff: [30, 0], fb: [-20, 0] },
    taunt: { h: 0.97, tilt: -0.18, head: -0.25, hf: [26, -22], hb: [-6, -4], ff: [20, 0], fb: [-18, 0] },
    guardCross: { h: 0.95, tilt: 0.0, hf: [14, -20], hb: [10, -22], ff: [20, 0], fb: [-18, 0] },
    sigWind: { h: 0.92, tilt: -0.25, hf: [-14, -2], hb: [4, -12], ff: [28, 0], fb: [-26, 0] },
    sigSlash: { h: 0.9, tilt: 0.38, hf: [58, 16], hb: [34, 10], ff: [38, 0], fb: [-32, 0] },
    bossWind: { h: 1, tilt: -0.35, flex: 0.8, hf: [-18, -52], hb: [-6, -56], ff: [26, 0], fb: [-26, 0] },
    bossSmash: { h: 0.9, tilt: 0.5, flex: 1, hf: [42, 40], hb: [32, 44], ff: [40, 0], fb: [-30, 0] },
    beam: { h: 0.98, tilt: 0.08, flex: 1, hf: [58, -8], hb: [52, -2], ff: [30, 0], fb: [-26, 0] },
    spinKick: { h: 0.95, tilt: -0.3, hf: [20, 16], hb: [-14, -12], ff: [76, -80], fb: [-10, 0] }
};
function epose(name) { return ENEMY_RPOSE[name] || RPOSE[name] || RPOSE.stand; }

class Enemy {
    constructor(o) {
        this.id = Math.random().toString(36).substring(2, 9);
        this.x = o.x; this.y = o.y; this.w = o.w; this.h = o.h;
        this.vx = 0; this.vy = 0;
        this.hp = o.hp; this.maxHp = o.hp; this.damage = o.damage; this.speed = o.speed; this.type = o.type;
        this.styleId = o.style; this.style = RIG_STYLES[o.style] || null;
        this.displayName = o.name; this.hitColor = o.hitColor || '#ff5577'; this.portraitKey = o.head || null;
        this.grounded = true; this.facingRight = false;
        this.state = 'idle'; this.stateTimer = rand(0.4, 1.0); this.phaseDur = 1;
        this.attackCooldown = rand(0.8, 1.6);
        this.hitFlash = 0; this.invulnTimer = 0; this.dead = false; this.isBoss = false;
        this.hitTargets = new Set();
        this.attacks = {}; this.atk = null; this.atkName = '';
        this.t = Math.random() * 5; this.alpha = 1; this.deathDur = 0.9; this.stepRate = 11;
        this.stunFx = 0; this.poseOverride = null;
        this.floorLevel = 1; this.difficulty = 'normal'; this.floorSkillCooldown = 5; this.floorSkill = null; this.floorSkillIndex = 0; this.floorSkillTargetX = 0; this.floorSkillGroundY = 0;
    }
    // ---- tiện ích ----
    cx() { return this.x + this.w / 2; }
    dx(p) { return (p.x + p.w / 2) - this.cx(); }
    faceP(p) { this.facingRight = this.dx(p) > 0; }
    dirTo(p) { return this.dx(p) > 0 ? 1 : -1; }
    setState(s, dur) { this.state = s; this.stateTimer = dur; this.phaseDur = Math.max(0.001, dur); }
    startAtk(name, player) {
        const a = this.attacks[name]; if (!a) return false;
        this.atk = a; this.atkName = name; this.faceP(player); this.vx = 0;
        this.setState('windup', a.windup * (a.jit ? rand(1 - a.jit, 1 + a.jit) : 1));
        this.hitTargets.clear(); return true;
    }
    // ---- vòng cập nhật chung ----
    update(dt, player, groundY, mapWidth, particles, floatText, audio, projectiles, manager, world) {
        this.t += dt; this.hitFlash = Math.max(0, this.hitFlash - dt); this.invulnTimer = Math.max(0, this.invulnTimer - dt);
        this.attackCooldown = Math.max(0, this.attackCooldown - dt);
        this.floorSkillCooldown = Math.max(0, this.floorSkillCooldown - dt);
        this.stateTimer -= dt;
        const ctx = { player, groundY, mapWidth, particles, floatText, audio, projectiles, manager, world, dt };
        if (this.dead) { this.vx *= 0.9; this.updatePhysics(dt, groundY, mapWidth); return; }
        if (this.preUpdate) this.preUpdate(dt, ctx);
        if (['floorTell', 'floorActive', 'floorRecover'].includes(this.state)) { this._updateFloorSkill(dt, ctx); this.updatePhysics(dt, groundY, mapWidth); return; }
        if (this.updateSpecial && this.updateSpecial(dt, ctx)) { this.updatePhysics(dt, groundY, mapWidth); return; }
        switch (this.state) {
            case 'hurt': this.vx *= Math.pow(0.02, dt); if (this.stateTimer <= 0) this.setState('idle', 0.15); break;
            case 'windup':
                if (this.stateTimer <= 0) {
                    const a = this.atk;
                    if (a.feint && !a._fired) { this.setState('recover', 0.3); break; }
                    this.setState('active', a.active); this.hitTargets.clear();
                    if (a.vx) this.vx = (this.facingRight ? 1 : -1) * a.vx;
                    if (a.hop) { this.vy = -a.hop; this.grounded = false; }
                    if (a.onActive) a.onActive(this, ctx);
                    audio.playSwingEnemy();
                }
                break;
            case 'active':
                if (this.atk.hop && this.grounded && this.stateTimer < this.phaseDur - 0.1 && this.atk.onLand && !this.landed) { this.landed = true; this.atk.onLand(this, ctx); }
                if (this.stateTimer <= 0) { this.landed = false; this.setState('recover', this.atk.recover); this.vx *= 0.3; if (this.atk.onEnd) this.atk.onEnd(this, ctx); }
                break;
            case 'recover':
                this.vx *= Math.pow(0.02, dt);
                if (this.stateTimer <= 0) { this.setState('idle', 0.1); this.attackCooldown = (this.afterAttackCd ? this.afterAttackCd() : rand(0.8, 1.6)) * ((DIFFICULTIES[this.difficulty] || DIFFICULTIES.normal).cooldown); this.atk = null; }
                break;
            default: {
                const cfg = DIFFICULTIES[this.difficulty] || DIFFICULTIES.normal;
                if (this.floorLevel >= 2 && this.floorSkillCooldown <= 0 && Math.random() < 0.42 * cfg.ai) this._startFloorSkill(player, ctx);
                else this.think(dt, ctx);
                break;
            }
        }
        this.updatePhysics(dt, groundY, mapWidth);
    }
    // mặc định: áp sát rồi đánh
    think(dt, c) {
        const p = c.player, d = Math.abs(this.dx(p));
        this.faceP(p);
        if (d > (this.attackRange || 80) - 10) { this.state = 'chase'; this.vx = this.dirTo(p) * this.speed; }
        else { this.state = 'idle'; this.vx *= 0.7; }
        if (this.attackCooldown <= 0) { const n = this.chooseAttack(p, d, c); if (n) this.startAtk(n, p); }
    }
    _startFloorSkill(player, c) {
        const max = Math.min(this.floorLevel, FLOOR_SKILLS.length - 1);
        // Hard có thể trộn kỹ năng cũ và mới thành chuỗi; Easy/Normal ưu tiên kỹ năng vừa mở khóa.
        const pool = this.difficulty === 'easy' ? [max] : Array.from({ length: max - 1 }, (_, i) => i + 2);
        this.floorSkillIndex = pool[Math.floor(Math.random() * pool.length)];
        this.floorSkill = FLOOR_SKILLS[this.floorSkillIndex];
        this.faceP(player); this.floorSkillTargetX = clamp(player.x + player.w / 2, 80, c.mapWidth - 80); this.floorSkillGroundY = c.groundY;
        const cfg = DIFFICULTIES[this.difficulty] || DIFFICULTIES.normal;
        const telegraph = ({ easy: 1.45, normal: 1.05, hard: 0.72 }[this.difficulty] || 1.05) * cfg.tell;
        this.vx = 0; this.setState('floorTell', telegraph);
        this.hitTargets.clear();
    }
    _updateFloorSkill(dt, c) {
        const cfg = DIFFICULTIES[this.difficulty] || DIFFICULTIES.normal;
        if (this.state === 'floorTell' && this.stateTimer <= 0) {
            const id = this.floorSkillIndex, dir = this.facingRight ? 1 : -1;
            const dmg = Math.round(this.damage * 1.25 + id * 1.7);
            const F = pfx();
            if (id === 2 || id === 7) {
                this.atk = { reach: 104, y: 18, h: 92, dmg, kb: 310, pierce: false };
                this.hitTargets.clear(); this.setState('floorActive', id === 7 ? 0.34 : 0.42); this.vx = dir * (id === 7 ? 1050 : 820);
                if (F) F.sparks(this.cx(), this.y + this.h * 0.55, 18, { col: ['#fff7ae', '#fb923c', '#ffffff'], angle: this.facingRight ? 0 : Math.PI, cone: 0.5, min: 90, max: 360, g: 0, life: 0.38, size: 4 });
            } else if (id === 3) {
                c.projectiles.push(new EnemyProjectile(this.cx() + dir * 22, c.groundY - 38, dir * 570, 0, 112, 38, dmg, 2.2, '#38bdf8', '#a5f3fc', { kind: 'wave', kb: 230 }));
                this._floorRecover(cfg, 0.58);
            } else if (id === 4) {
                const dx = c.player.x + c.player.w / 2 - this.cx(), dy = c.player.y + c.player.h * 0.45 - (this.y + 38), a = Math.atan2(dy, dx), sp = 430;
                c.projectiles.push(new EnemyProjectile(this.cx() - 22, this.y + 25, Math.cos(a) * sp, Math.sin(a) * sp, 46, 46, dmg, 3, '#a78bfa', '#e9d5ff', { kind: 'orb', kb: 190 }));
                this._floorRecover(cfg, 0.65);
            } else if (id === 5 || id === 10) {
                const count = id === 10 ? 3 : 1;
                for (let i = 0; i < count; i++) {
                    const tx = clamp(this.floorSkillTargetX + (i - (count - 1) / 2) * 150, 70, c.mapWidth - 70);
                    c.projectiles.push(new TrollPillar(tx, c.groundY, (0.35 + i * 0.16) * cfg.tell, '#f97316', '#fde68a'));
                }
                this._floorRecover(cfg, 0.72);
            } else if (id === 6) {
                for (let i = -1; i <= 1; i++) { const a = i * 0.28, sp = 390; c.projectiles.push(new EnemyProjectile(this.cx() - 18, this.y + 32, dir * Math.cos(a) * sp, Math.sin(a) * sp, 38, 38, dmg * 0.72, 2.8, '#f472b6', '#fbcfe8', { kind: 'orb', kb: 160 })); }
                this._floorRecover(cfg, 0.72);
            } else if (id === 8) {
                const tx = clamp(this.floorSkillTargetX, 80, c.mapWidth - 80);
                c.projectiles.push(new EnemyProjectile(tx - 28, c.groundY - 46, 0, 0, 56, 46, dmg, 4.2, '#84cc16', '#d9f99d', { kind: 'banana', gravity: 0, ground: true, kb: 240, armT: 0.45 }));
                this._floorRecover(cfg, 0.65);
            } else if (id === 9) {
                const tx = clamp(this.floorSkillTargetX, 80, c.mapWidth - 80);
                c.projectiles.push(new EnemyProjectile(tx - 30, -150, 0, 920, 60, 60, dmg * 1.35, 2, '#fb923c', '#fef3c7', { kind: 'meteor', kb: 280 }));
                this._floorRecover(cfg, 0.8);
            } else {
                this._floorRecover(cfg, 0.6);
            }
            c.audio.playSwingEnemy();
        } else if (this.state === 'floorActive' && this.stateTimer <= 0) {
            if (this.floorSkillIndex === 7) {
                const dir = this.facingRight ? 1 : -1;
                c.projectiles.push(new EnemyProjectile(this.cx() + dir * 18, c.groundY - 34, dir * 520, 0, 94, 34, Math.round(this.damage * 1.05), 1.8, '#c084fc', '#f5d0fe', { kind: 'wave', kb: 210 }));
                const F = pfx(); if (F) F.pop(this.cx(), c.groundY - 24, 78, '#e9d5ff', 0.22);
            }
            this.atk = null; this.vx *= 0.25; this._floorRecover(cfg, 0.52);
        } else if (this.state === 'floorRecover' && this.stateTimer <= 0) {
            this.atk = null; this.floorSkillCooldown = rand(7.5, 10.5) * cfg.cooldown;
            this.attackCooldown = Math.max(this.attackCooldown, 0.55); this.setState('idle', 0.12);
        }
    }
    _floorRecover(cfg, duration) { this.atk = null; this.vx *= 0.2; this.setState('floorRecover', duration * cfg.cooldown); }
    chooseAttack() { return null; }
    updatePhysics(dt, groundY, mapWidth) {
        this.vy += GRAVITY * dt; this.x += this.vx * dt; this.y += this.vy * dt;
        if (this.y + this.h >= groundY) { this.y = groundY - this.h; this.vy = 0; this.grounded = true; } else this.grounded = false;
        this.x = clamp(this.x, 20, mapWidth - this.w - 20);
    }
    // ---- nhận sát thương ----
    // trả về 'hit' | 'parried' | 'dodged' | 'taunted' | 'none'
    onHitFilter(amount, kbDir, info) { return { amount, flinch: true }; }
    takeDamage(amount, kbDir = 0, kbForce = 180, particles, floatText, audio, info = {}) {
        if (this.dead || this.invulnTimer > 0) return 'none';
        const f = this.onHitFilter(amount, kbDir, info, { particles, floatText, audio });
        if (f.result) return f.result;
        amount = Math.max(1, Math.round(f.amount));
        this.hp -= amount; this.hitFlash = 0.15; this.invulnTimer = 0.1;
        this.vx = kbDir * kbForce * (f.kbMul === undefined ? 1 : f.kbMul);
        if (info.launch && !this.isBoss) { this.vy = -info.launch; this.grounded = false; }
        if (f.flinch && this.state !== 'death') {
            const base = info.stun || (info.kind === 'heavy' ? 0.45 : 0.28);
            this.setState('hurt', base * (this.isBoss ? 0.5 : 1)); this.hitTargets.clear(); this.atk = null; this.landed = false;
        }
        audio.playHit(amount / 20);
        const cxp = this.cx(), cyp = this.y + this.h * 0.4;
        particles.hitSpark(cxp, cyp, this.hitColor);
        const big = info.kind === 'heavy' || info.kind === 'skill' || info.kind === 'ult';
        floatText.show(cxp, this.y - 14, `-${amount}`, info.kind === 'skill' || info.kind === 'ult' ? '#e879f9' : (big ? '#fb923c' : '#ffd45a'), big ? 26 : 20);
        if (this.hp <= 0) this.die(audio, particles, floatText);
        return 'hit';
    }
    die(audio, particles, floatText) {
        this.hp = 0; this.dead = true; this.state = 'death'; this.stateTimer = this.deathDur; this.phaseDur = this.deathDur;
        audio.playEnemyDeath(this.isBoss);
        particles.emit(this.cx(), this.y + this.h * 0.5, 24, { vxRand: 500, vy: -150, vyRand: 300, life: 0.9, color: [this.hitColor, '#fff', '#222'], size: 5, gravity: 600 });
        if (this.deathLine) floatText.show(this.cx(), this.y - 36, this.deathLine, '#fff', 20, 1.2);
    }
    stagger(dur, floatText) {
        if (this.dead || (this.isBoss && ['phase', 'windup', 'active', 'beam'].includes(this.state))) return;
        this.setState('hurt', dur); this.atk = null; this.hitTargets.clear(); this.vx = 0;
        if (floatText) floatText.show(this.cx(), this.y - 30, 'STAGGER!', '#fde047', 18, 0.8);
    }
    getHurtbox() { return { x: this.x + 5, y: this.y + 5, w: this.w - 10, h: this.h - 10 }; }
    getHitbox() {
        if (!['active', 'floorActive'].includes(this.state) || !this.atk || !this.atk.reach) return null;
        const a = this.atk, dir = this.facingRight ? 1 : -1;
        if (a.spin) return { x: this.cx() - a.reach, y: this.y + (a.y || 30), w: a.reach * 2, h: a.h || 60 };
        return { x: dir > 0 ? this.x + this.w * 0.3 : this.cx() - a.reach - this.w * 0.2, y: this.y + (a.y || 30), w: a.reach + this.w * 0.2, h: a.h || 60 };
    }
    getAttackInfo() { const a = this.atk || {}; return { damage: a.dmg || this.damage, kb: a.kb || 220, pierce: !!a.pierce, stun: a.stun || 0, shake: a.shake || 7 }; }

    // ---- tư thế khung xương ----
    standPose() { return idlePose(this.t); }
    getPose() {
        const st = this.state, p = clamp(1 - this.stateTimer / this.phaseDur, 0, 1);
        if (this.poseOverride) return this.poseOverride;
        if (this.dead) return lerpPose(RPOSE.hit, RPOSE.down, smooth01(p * 2.5));
        switch (st) {
            case 'hurt': {
                if (this.stateTimer > 0.3 && this.phaseDur > 0.3) { const w = Math.sin(this.t * 14); return Object.assign({}, RPOSE.hit, { tilt: w * 0.22 - 0.12, head: -w * 0.3, hf: [8, 30 + w * 6], hb: [-8, 30 - w * 6] }); }
                return RPOSE.hit;
            }
            case 'windup': return lerpPose(this.standPose(), epose(this.atk.wind), smooth01(p));
            case 'active': return lerpPose(epose(this.atk.wind), epose(this.atk.hit), smooth01(p * 2.5));
            case 'floorTell': return lerpPose(this.standPose(), epose(this.floorSkillIndex === 2 || this.floorSkillIndex === 7 ? 'crouch' : 'castUp'), smooth01(p));
            case 'floorActive': return epose(this.floorSkillIndex === 2 || this.floorSkillIndex === 7 ? 'dashRun' : 'shoot');
            case 'recover': return lerpPose(epose(this.atk.hit), this.standPose(), smooth01(p));
            case 'chase': { const pp = runPose(this.t * this.stepRate); return pp; }
            default: return this.standPose();
        }
    }
    // ---- vẽ ----
    drawShadow(ctx, cam, groundY) {
        const sx = cam.screenX(this.cx()), sy = cam.screenY(groundY);
        const gh = clamp(1 - (groundY - (this.y + this.h)) / 300, 0.3, 1);
        ctx.fillStyle = '#00000055'; ctx.beginPath(); ctx.ellipse(sx, sy + 2, this.w * 0.55 * gh, 7 * gh, 0, 0, 6.283); ctx.fill();
    }
    drawBody(ctx, cam, x, y, dir, flash, alpha) {
        Rig.draw(ctx, this.style, this.getPose(), { x, y, facing: dir, t: this.t, flash, alpha, aura: this.auraColor && this.auraColor() });
    }
    draw(ctx, cam, groundY) {
        if (!cam.visible(this.x - 100, this.y - 100, this.w + 200, this.h + 200)) return;
        this.drawShadow(ctx, cam, groundY);
        const x = cam.screenX(this.cx()), y = cam.screenY(this.y + this.h), dir = this.facingRight ? 1 : -1;
        let alpha = 1;
        if (this.dead) alpha = clamp(this.stateTimer / (this.deathDur * 0.6), 0, 1);
        if (this.alpha !== 1) alpha *= this.alpha;
        const jit = (this.hitFlash > 0 ? (Math.random() - 0.5) * 6 : 0);
        this.drawBody(ctx, cam, x + jit, y, dir, this.hitFlash > 0 ? this.hitFlash / 0.15 : 0, alpha);
        if (!this.dead) {
            this.drawStatus(ctx, cam, x, y);
            this.drawBars(ctx, cam, x, y);
        }
    }
    drawStatus(ctx, cam, x, y) {
        const top = y - this.h - 24;
        if ((this.state === 'windup' && this.atk && this.atk.tell) || this.state === 'floorTell') {       // cảnh báo pixel trước đòn
            ctx.save(); ctx.fillStyle = this.state === 'floorTell' ? '#fb923c' : '#ffe27a'; ctx.strokeStyle = '#000'; ctx.lineWidth = 4; ctx.font = '900 26px Impact, Arial'; ctx.textAlign = 'center';
            const sc = 1 + 0.15 * Math.sin(this.t * 30); ctx.translate(x, top - 22); ctx.scale(sc, sc); ctx.strokeText('!', 0, 0); ctx.fillText('!', 0, 0); ctx.restore();
            if (this.state === 'floorTell') {
                ctx.save(); ctx.globalAlpha = 0.35 + 0.25 * Math.sin(this.t * 18); ctx.fillStyle = '#fb923c'; for (let i = -2; i <= 2; i++) ctx.fillRect(x + i * 9 - 3, y - 5, 6, 6); ctx.restore();
                if ([5, 8, 9, 10].includes(this.floorSkillIndex)) {
                    const tx = cam.screenX(this.floorSkillTargetX), ty = cam.screenY(this.floorSkillGroundY);
                    ctx.save(); ctx.translate(tx, ty); ctx.globalAlpha = 0.45 + 0.4 * Math.sin(this.t * 16); ctx.strokeStyle = '#fb923c'; ctx.lineWidth = 4; ctx.setLineDash([8, 6]); ctx.beginPath(); ctx.ellipse(0, 0, this.floorSkillIndex === 10 ? 58 : 42, 12, 0, 0, 6.283); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = '#fef3c7'; for (let i = -2; i <= 2; i++) ctx.fillRect(i * 10 - 2, -3, 4, 6); ctx.restore();
                }
            }
        }
        if (this.state === 'hurt' && this.stateTimer > 0.12 && !this.isBoss) {     // sao choáng quay quanh đầu
            ctx.save(); ctx.fillStyle = '#ffd45a'; ctx.strokeStyle = '#7a4c0c'; ctx.lineWidth = 1.5;
            for (let k = 0; k < 3; k++) {
                const a = this.t * 9 + k * 2.094, px = x + Math.cos(a) * 24, py = top + 10 + Math.sin(a) * 6;
                ctx.beginPath(); for (let q = 0; q < 8; q++) { const r = q % 2 ? 2.5 : 6; const an = q * Math.PI / 4; ctx.lineTo(px + Math.cos(an) * r, py + Math.sin(an) * r); } ctx.closePath(); ctx.fill(); ctx.stroke();
            }
            ctx.restore();
        }
    }
    drawBars(ctx, cam, x, y) {
        if (this.isBoss) return;
        const w = 64, bx = x - w / 2, by = y - this.h - 34;
        ctx.save();
        ctx.font = '700 12px "Trebuchet MS", Arial'; ctx.textAlign = 'center'; ctx.lineJoin = 'round';
        ctx.strokeStyle = '#000'; ctx.lineWidth = 4; ctx.strokeText(this.displayName, x, by - 6); ctx.fillStyle = '#fff3c4'; ctx.fillText(this.displayName, x, by - 6);
        ctx.fillStyle = '#000'; ctx.fillRect(bx - 2, by - 2, w + 4, 9);
        ctx.fillStyle = '#3b1020'; ctx.fillRect(bx, by, w, 5);
        const pct = clamp(this.hp / this.maxHp, 0, 1);
        const g = ctx.createLinearGradient(0, by, 0, by + 5); g.addColorStop(0, '#fca5a5'); g.addColorStop(1, '#dc2626');
        ctx.fillStyle = g; ctx.fillRect(bx, by, w * pct, 5);
        ctx.restore();
    }
}

// ---------- tiện ích vẽ có nháy trắng cho Doge (ảnh cắt) ----------
function drawFlash(ctx, x, y, flash, alpha, fn) {
    if (!flash || flash <= 0) { ctx.save(); if (alpha !== undefined) ctx.globalAlpha *= alpha; fn(ctx, x, y); ctx.restore(); return; }
    const BW = 420, BH = 420, OX = 210, OY = 330;
    if (!Rig._buf) { Rig._buf = document.createElement('canvas'); Rig._buf.width = BW; Rig._buf.height = BH; }
    const b = Rig._buf, bc = b.getContext('2d');
    bc.setTransform(1, 0, 0, 1, 0, 0); bc.clearRect(0, 0, BW, BH); bc.globalCompositeOperation = 'source-over';
    fn(bc, OX, OY);
    bc.globalCompositeOperation = 'source-atop'; bc.fillStyle = `rgba(255,255,255,${clamp(flash, 0, 1) * 0.85})`; bc.fillRect(0, 0, BW, BH);
    ctx.save(); if (alpha !== undefined) ctx.globalAlpha *= alpha; ctx.drawImage(b, x - OX, y - OY); ctx.restore();
}
const COPE_WORDS = ['COPE', 'SEETHE', 'DILATE', 'MALD', 'SKILL ISSUE', 'L + RATIO'];

// ============================================================
// 1) NPC WOJAK — đánh khó đoán: tát, dậm, ném bong bóng COPE, lao SEETHE, giả vờ ra đòn rồi đứng đờ
// ============================================================
class WojakNPC extends Enemy {
    constructor(x, y) {
        super({ style: 'wojak', x, y, w: 54, h: 118, hp: 70, damage: 8, speed: 150, type: 'wojak', name: 'NPC WOJAK', hitColor: '#9ca3af', head: 'npc' });
        this.attackRange = 70; this.stepRate = 9; this.glitch = 0; this.deathLine = '…ok.';
        this.style = Object.assign({}, RIG_STYLES.wojak, { scale: 0.665 });
        this.attacks = {
            slap: { windup: 0.26, active: 0.12, recover: 0.42, dmg: 8, kb: 200, reach: 64, h: 46, y: 28, wind: 'slapWind', hit: 'slap', vx: 140, jit: 0.4, tell: true },
            stomp: { windup: 0.42, active: 0.5, recover: 0.5, dmg: 12, kb: 260, reach: 70, h: 70, y: 50, wind: 'crouch', hit: 'stompHit', hop: 520, vx: 250, jit: 0.3, tell: true,
                onLand: (e, c) => { c.world.fx.ring(e.cx(), e.y + e.h, { r1: 90, life: 0.35, color: '#cbd5e1', sq: 0.3 }); c.particles.dust(e.cx(), e.y + e.h); } },
            seethe: { windup: 0.34, active: 0.38, recover: 0.6, dmg: 10, kb: 240, reach: 62, h: 56, y: 30, wind: 'dashRun', hit: 'dashRun', vx: 520, jit: 0.35, tell: true },
            cope: { windup: 0.46, active: 0.12, recover: 0.55, dmg: 7, wind: 'castUp', hit: 'shoot', jit: 0.4,
                onActive: (e, c) => { const dir = e.facingRight ? 1 : -1;
                    c.projectiles.push(new EnemyProjectile(e.cx() + dir * 30, e.y + 30, dir * 340, -20, 76, 36, 7, 3, '#fff', '#9ca3af', { kind: 'cope', label: COPE_WORDS[Math.floor(Math.random() * COPE_WORDS.length)], spin: 5, kb: 160 })); } }
        };
    }
    standPose() { const p = idlePose(this.t); if (this.glitch > 0) p.head = Math.sin(this.t * 45) * 0.12; return p; }
    think(dt, c) {
        if (this.glitch > 0) { this.glitch -= dt; this.vx = 0; this.state = 'idle'; this.faceP(c.player); return; }   // "NPC lag": đứng đờ
        if (Math.random() < dt * 0.22 && Math.abs(this.dx(c.player)) < 420) { this.glitch = rand(0.5, 0.9); c.floatText.show(this.cx(), this.y - 40, '...', '#cbd5e1', 18, 0.8); return; }
        super.think(dt, c);
    }
    chooseAttack(p, d) {
        const r = Math.random();
        if (d < 95) {
            if (r < 0.38) return 'slap'; if (r < 0.56) return 'seethe'; if (r < 0.74) return 'stomp';
            if (r < 0.86) { this.startAtk('slap', p); this.atk = Object.assign({}, this.atk, { feint: true }); return null; }   // giả vờ
            return 'slap';
        }
        if (d < 470) { if (r < 0.45) return 'cope'; if (r < 0.8) return 'seethe'; }
        return null;
    }
    afterAttackCd() { return rand(0.5, 1.7); }
}

// ============================================================
// 2) DOGE — nhanh, NÉ ĐÒN (lùi nhanh + phản công), cào liên hoàn, "zoomies"
// ============================================================
class DogeEnemy extends Enemy {
    constructor(x, y) {
        super({ style: null, x, y, w: 72, h: 112, hp: 60, damage: 8, speed: 330, type: 'doge', name: 'DOGE', hitColor: '#fbbf24', head: 'doge_full' });
        this.attackRange = 88; this.dodgeCd = 1.2; this.dodging = false; this.deathLine = 'such wow...';
        this.attacks = {
            claw: { windup: 0.14, active: 0.1, recover: 0.2, dmg: 8, kb: 200, reach: 72, h: 62, y: 36, vx: 300, wind: 'arm', hit: 'arm',
                onEnd: (e, c) => { if (Math.random() < 0.7) { e.startAtk('claw2', c.player); } } },
            claw2: { windup: 0.07, active: 0.1, recover: 0.36, dmg: 8, kb: 230, reach: 76, h: 62, y: 36, vx: 340, wind: 'arm', hit: 'arm' },
            zoom: { windup: 0.3, active: 0.45, recover: 0.55, dmg: 11, kb: 280, reach: 62, h: 62, y: 38, vx: 780, wind: 'arm', hit: 'arm', tell: true }
        };
    }
    preUpdate(dt, c) {
        this.dodgeCd = Math.max(0, this.dodgeCd - dt);
        const p = c.player;
        if (this.dodgeCd <= 0 && !this.dodging && !['hurt', 'windup', 'active', 'dodge'].includes(this.state)) {
            const near = Math.abs(this.dx(p)) < 160, facing = (p.facingRight ? 1 : -1) === (this.dx(p) > 0 ? -1 : 1);
            if (near && facing && (p.state === 'attack' || p.skill2Active) && Math.random() < 0.65) {
                this.dodging = true; this.dodgeCd = 2.6; this.faceP(p); this.setState('dodge', 0.3);
                this.vx = -this.dirTo(p) * 680; this.vy = -120; this.grounded = false;
                c.floatText.show(this.cx(), this.y - 30, 'WOW!', '#fde047', 22, 0.7);
                c.world.fx.ring(this.cx(), this.y + this.h, { r1: 50, life: 0.25, color: '#fde047', sq: 0.3 });
            }
        }
    }
    updateSpecial(dt, c) {
        if (this.state === 'dodge') {
            this.vx *= Math.pow(0.05, dt);
            if (this.stateTimer <= 0) { this.dodging = false; this.setState('idle', 0.05); this.faceP(c.player); if (Math.random() < 0.7) this.startAtk('claw', c.player); }
            return true;
        }
        return false;
    }
    onHitFilter(amount, kbDir, info, fx) {
        if (this.dodging) { fx.floatText.show(this.cx(), this.y - 20, 'MISS', '#fde047', 16, 0.5); return { result: 'dodged' }; }
        return { amount, flinch: true };
    }
    chooseAttack(p, d) {
        if (d < 100) return 'claw';
        if (d > 170 && d < 430 && Math.random() < 0.03 * 4) return 'zoom';
        return null;
    }
    afterAttackCd() { return rand(0.4, 1.0); }
    getPose() {
        const t = this.t, st = this.state, p = clamp(1 - this.stateTimer / this.phaseDur, 0, 1);
        if (this.dead) return { lean: -1.4 * smooth01(p * 2), by: 0, armF: 0.8, armB: 0.8 };
        if (st === 'hurt') return { tilt: -0.28, head: -0.3, armF: 0.8, armB: 0.8, sx: 0.96 };
        if (st === 'dodge') return { lean: -0.35, sy: 0.93, sx: 1.05, legF: 0.5, legB: -0.5 };
        if (st === 'windup') return { armF: 0.9 * p, tilt: -0.12 * p, bx: -8 * p, by: 4 * p };
        if (st === 'active') return { armF: -1.45, armB: 0.2, tilt: 0.18, bx: 12, legF: 0.3, legB: -0.3 };
        if (st === 'recover') return { armF: -1.45 * (1 - p), tilt: 0.18 * (1 - p), bx: 12 * (1 - p) };
        if (st === 'chase') { const s = Math.sin(t * 18); return { legF: s * 0.5, legB: -s * 0.5, armF: -s * 0.35, armB: s * 0.35, by: -Math.abs(s) * 6, tilt: 0.1 }; }
        return { by: -Math.abs(Math.sin(t * 4)) * 2, armF: Math.sin(t * 3) * 0.06, armB: -Math.sin(t * 3) * 0.06 };
    }
    drawBody(ctx, cam, x, y, dir, flash, alpha) {
        const pose = this.getPose();
        const ok = DogePuppet.build();
        if (!ok) {     // chưa tải ảnh: khối dự phòng
            ctx.fillStyle = '#e8c07a'; ctx.fillRect(x - 30, y - 100, 60, 100); return;
        }
        if (this.state === 'dodge' || this.state === 'active' && this.atk === this.attacks.zoom) {
            ctx.save(); ctx.globalAlpha = 0.35; DogePuppet.draw(ctx, pose, { x: x - dir * 36, y, facing: dir, h: 130 }); ctx.restore();
        }
        drawFlash(ctx, x, y, flash, alpha, (cc, xx, yy) => DogePuppet.draw(cc, pose, { x: xx, y: yy, facing: dir, h: 130 }));
    }
}

// ============================================================
// 3) TROLLFACE — lừa & phản đòn: chế giễu (hứng đòn rồi phản), dịch chuyển ra sau lưng, ném vỏ chuối
// ============================================================
class TrollEnemy extends Enemy {
    constructor(x, y) {
        super({ style: 'troll', x, y, w: 50, h: 112, hp: 70, damage: 10, speed: 190, type: 'troll', name: 'TROLLFACE', hitColor: '#c4b5fd', head: 'troll' });
        this.style = Object.assign({}, RIG_STYLES.troll, { scale: 0.62 });
        this.attackRange = 76; this.stepRate = 10; this.deathLine = 'U MAD?'; this.bananaCd = 3; this.blinkCd = 4; this.counterNext = false; this.blinkT = 0; this.blinkTo = null;
        this.attacks = {
            slap: { windup: 0.24, active: 0.12, recover: 0.4, dmg: 9, kb: 200, reach: 66, h: 46, y: 30, wind: 'slapWind', hit: 'slap', vx: 200, tell: true },
            kick: { windup: 0.3, active: 0.16, recover: 0.45, dmg: 11, kb: 260, reach: 80, h: 50, y: 56, wind: 'k1', hit: 'k3', vx: 160, tell: true },
            counter: { windup: 0.1, active: 0.16, recover: 0.5, dmg: 14, kb: 340, reach: 86, h: 56, y: 30, wind: 'slapWind', hit: 'slap', vx: 420, shake: 10,
                onActive: (e, c) => { const dir = e.facingRight ? 1 : -1, F = pfx(); if (F) { F.slash(e.cx() + dir * 14, e.y + 52, dir, 84, '#f0abfc', 0.3, { th: 30, col2: '#fff' }); F.pop(e.cx() + dir * 70, e.y + 50, 120, '#e9d5ff', 0.3); F.text(e.cx(), e.y - 24, 'TROLLED!', '#f0abfc', 0.8, 12); } } },
            banana: { windup: 0.35, active: 0.1, recover: 0.5, dmg: 6, wind: 'castUp', hit: 'shoot',
                onActive: (e, c) => { const dir = e.facingRight ? 1 : -1; const F = pfx(); if (F) { F.pop(e.cx() + dir * 34, e.y + 44, 70, '#fde047', 0.25); F.sparks(e.cx() + dir * 34, e.y + 44, 10, { col: ['#fde047', '#fff', '#facc15'], angle: dir > 0 ? -0.5 : Math.PI + 0.5, cone: 1.2, min: 80, max: 260, g: 500, life: 0.4 }); }
                    const b = new EnemyProjectile(e.cx() + dir * 30, e.y + 40, dir * 300, -260, 40, 28, 6, 7, '#fde047', '#facc15', { kind: 'banana', gravity: 1100, slip: true, stun: 0.7, spin: 7, kb: 80 }); c.projectiles.push(b); } }
        };
    }
    preUpdate(dt) { this.bananaCd = Math.max(0, this.bananaCd - dt); this.blinkCd = Math.max(0, this.blinkCd - dt); }
    updateSpecial(dt, c) {
        const p = c.player, F = pfx();
        if (!this._fxInit) {      // gắn vệt chém pixel cho slap / kick (một lần)
            this._fxInit = true;
            this.attacks.slap.onActive = (e) => { const d = e.facingRight ? 1 : -1, G = pfx(); if (G) G.slash(e.cx() + d * 12, e.y + 48, d, 62, '#c4b5fd', 0.22, { th: 18 }); };
            this.attacks.kick.onActive = (e) => { const d = e.facingRight ? 1 : -1, G = pfx(); if (G) G.slash(e.cx() + d * 10, e.y + 78, d, 72, '#a78bfa', 0.24, { a0: -0.5, a1: 0.95, th: 20 }); };
        }
        if (this.state === 'taunt') {
            if (F && Math.random() < 0.25) F.sparks(this.cx() + rand(-30, 30), this.y + rand(0, 20), 1, { col: ['#e9d5ff', '#c4b5fd'], angle: -Math.PI / 2, cone: 0.8, min: 30, max: 90, g: -20, life: 0.6, size: 3 });
            this.vx = 0; this.faceP(p);
            if (this.counterNext) { this.counterNext = false; this.startAtk('counter', p); this.invulnTimer = 0; return true; }
            if (this.stateTimer <= 0) { this.setState('idle', 0.1); this.attackCooldown = 0.5; }
            return true;
        }
        if (this.state === 'blink') {
            this.vx = 0; const prog = 1 - this.stateTimer / this.phaseDur;
            if (prog < 0.5) this.alpha = 1 - prog * 2;
            else { if (this.blinkTo !== null) { this.x = this.blinkTo; this.blinkTo = null; this.faceP(p);
                if (F) { F.implode(this.cx(), this.y + this.h * 0.5, 150, ['#c4b5fd', '#fff', '#7c3aed'], 26, 0.3); F.ring(this.cx(), c.groundY, 8, 120, 0.4, '#c4b5fd', { sq: 0.28, n: 24 }); F.pop(this.cx(), this.y + this.h * 0.5, 100, '#e9d5ff', 0.3); F.text(this.cx(), this.y - 30, 'BOO!', '#e9d5ff', 0.7, 12); } } this.alpha = (prog - 0.5) * 2; }
            if (this.stateTimer <= 0) { this.alpha = 1; this.setState('idle', 0.05); this.faceP(p); this.startAtk('kick', p); }
            return true;
        }
        return false;
    }
    onHitFilter(amount, kbDir, info, fx) {
        if (this.state === 'taunt') {      // PHẢN ĐÒN: né hết sát thương và đáp trả
            const F = pfx(); if (F) { F.text(this.cx(), this.y - 34, 'PROBLEM?', '#e9d5ff', 0.9, 13); F.pop(this.cx(), this.y + 50, 110, '#c4b5fd', 0.3); F.ring(this.cx(), this.y + 56, 10, 90, 0.4, '#fff', { n: 20, size: 6 }); }
            this.counterNext = true; return { result: 'taunted' };
        }
        return { amount, flinch: true };
    }
    chooseAttack(p, d, c) {
        const r = Math.random();
        if (d < 90) {
            if (r < 0.34) return 'slap'; if (r < 0.52) return 'kick';
            if (r < 0.74) { this.setState('taunt', 0.9); const F = pfx(); if (F) { F.icon(this.cx(), this.y - 44, 'troll', 0.9, 3); F.ring(this.cx(), this.y + this.h * 0.55, 20, 80, 0.6, '#c4b5fd', { n: 18, size: 6 }); } return null; }
            if (this.blinkCd <= 0) { this.startBlink(p, c); return null; }
            return 'slap';
        }
        if (d < 440) {
            if (this.bananaCd <= 0 && r < 0.4) { this.bananaCd = 6; return 'banana'; }
            if (this.blinkCd <= 0 && r < 0.7) { this.startBlink(p, c); return null; }
        }
        return null;
    }
    startBlink(p, c) {
        this.blinkCd = 5.5; const pd = p.facingRight ? 1 : -1;
        this.blinkTo = clamp(p.x + p.w / 2 - pd * 100 - this.w / 2, 30, c.mapWidth - this.w - 30);
        this.setState('blink', 0.55); const F = pfx(); if (F) { F.dissolve(this.cx(), this.y, 50, this.h, ['#c4b5fd', '#fff', '#7c3aed'], 34); F.circle(this.cx(), c.groundY, 150, 0.55, '#a78bfa', '#fff'); }
    }
    standPose() {
        if (this.state === 'taunt') return Object.assign({}, epose('taunt'), { by: Math.sin(this.t * 30) * 2, head: -0.25 + Math.sin(this.t * 25) * 0.12 });
        return idlePose(this.t);
    }
    afterAttackCd() { return rand(0.5, 1.2); }
}

// ============================================================
// 4) GIGACHAD — cận chiến nặng, giáp dày, GỒNG CƠ (giảm 80% sát thương, không bị choáng), đấm giáng & dậm đất
// ============================================================
class ChadEnemy extends Enemy {
    constructor(x, y) {
        super({ style: 'chad', x, y, w: 84, h: 170, hp: 170, damage: 18, speed: 100, type: 'chad', name: 'GIGACHAD', hitColor: '#e5e7eb', head: 'chad' });
        this.style = Object.assign({}, RIG_STYLES.chad, { scale: 0.82 });
        this.attackRange = 100; this.stepRate = 6; this.deathLine = 'Yes.'; this.flexCd = 5;
        this.attacks = {
            gigaPunch: { windup: 0.7, active: 0.2, recover: 0.75, dmg: 22, kb: 440, reach: 108, h: 84, y: 34, wind: 'chadWind', hit: 'chadPunch', vx: 200, tell: true, armor: true, shake: 12 },
            pound: { windup: 0.7, active: 0.6, recover: 0.85, dmg: 15, kb: 300, reach: 84, h: 80, y: 90, hop: 560, wind: 'crouch', hit: 'pound', tell: true, armor: true, pierce: false,
                onLand: (e, c) => { c.world.fx.shock(e.cx(), e.y + e.h, { r1: 200, life: 0.4, color: '#e5e7eb' }); c.world.camera.shake(10, 0.3); c.audio.playBigImpact();
                    e.landFx = 0.45;
                    for (const dir of [-1, 1]) c.projectiles.push(new EnemyProjectile(e.cx() + dir * 40, c.groundY - 34, dir * 380, 0, 90, 34, 14, 1.3, '#d1d5db', '#9ca3af', { kind: 'wave', kb: 260 })); } }
        };
        this.landFx = 0;
    }
    preUpdate(dt) { this.flexCd = Math.max(0, this.flexCd - dt); this.landFx = Math.max(0, this.landFx - dt); }
    // Chọn khung hình sprite theo trạng thái (giống Player._sprite của Ricardo)
    _sprite() {
        const st = this.state, t = this.t, age = this.phaseDur - this.stateTimer, pound = this.atkName === 'pound';
        if (this.dead) { const p = clamp(1 - this.stateTimer / this.deathDur, 0, 1); return { k: 'hurt_0', rot: -clamp(p * 3, 0, 1) * 1.45, feet: true, lift: 18 }; }
        switch (st) {
            case 'hurt': return { k: age < 0.12 ? 'hurt_0' : (this.stateTimer < 0.1 ? 'hurt_2' : 'hurt_1'), rot: Math.sin(t * 30) * 0.03 };
            case 'flex': return { k: age < 0.2 ? 'skill_0' : 'skill_1', by: Math.sin(t * 40) * 1.5, sx: 1 + Math.sin(t * 6) * 0.015 };
            case 'windup': {
                if (pound) return { k: 'jump_0' };                                              // ngồi nén chuẩn bị nhảy
                const p = clamp(age / this.phaseDur, 0, 1);
                return { k: 'attack_0', rot: -p * 0.07, sx: 1 + p * 0.04 };                      // gồng tay, ngả người ra sau
            }
            case 'active':
                if (pound) return { k: this.grounded ? 'jump_3' : (this.vy < -220 ? 'jump_1' : 'jump_2') };
                return { k: 'attack_1' };                                                        // đấm giáng (có vệt gió trong khung)
            case 'recover': {
                const p = clamp(1 - this.stateTimer / this.phaseDur, 0, 1);
                if (pound) return p < 0.55 ? { k: 'jump_3' } : ChadSprite.idle(t);
                return p < 0.6 ? { k: 'attack_2' } : ChadSprite.idle(t);
            }
            case 'chase': return Math.abs(this.vx) > 170 ? ChadSprite.run(t) : ChadSprite.walk(t, this.stepRate * 1.1);
            default: return this.grounded ? ChadSprite.idle(t) : { k: 'jump_2' };
        }
    }
    drawBody(ctx, cam, x, y, dir, flash, alpha) {
        Rig.draw(ctx, this.style, this.getPose(), { x, y, facing: dir, t: this.t, flash, alpha, aura: this.auraColor(), spr: this._sprite() });
        if (this.landFx > 0) {                                                                    // bụi nổ khi đập đất
            const p = 1 - this.landFx / 0.45;
            ChadSprite.fx(ctx, 'fx_boom', x, y + 4, this.style.scale * ChadSprite.U * (0.9 + p * 0.5), (1 - p) * (alpha === undefined ? 1 : alpha), false);
        }
    }
    updateSpecial(dt, c) {
        if (this.state === 'flex') {
            this.vx = 0; this.faceP(c.player);
            if (Math.random() < dt * 14) c.particles.emit(this.cx(), this.y + this.h * 0.4, 1, { spreadX: 60, vy: -80, vyRand: 40, life: 0.6, color: ['#ffd45a', '#fff'], size: 4, gravity: -30 });
            if (this.stateTimer <= 0) {
                this.setState('idle', 0.05);
                if (Math.abs(this.dx(c.player)) < 190) this.startAtk('gigaPunch', c.player); else this.attackCooldown = 0.2;
            }
            return true;
        }
        return false;
    }
    onHitFilter(amount, kbDir, info, fx) {
        const facingDir = this.facingRight ? 1 : -1, behind = (-kbDir) !== facingDir;
        let mul = 1;
        if (this.state === 'flex') mul = info.kind === 'ult' ? 0.5 : 0.2;
        else if (!behind) mul = info.kind === 'light' ? 0.5 : (info.kind === 'heavy' ? 0.8 : 1);
        if (mul < 1) fx.floatText.show(this.cx(), this.y - 8, 'ARMOR', '#e5e7eb', 14, 0.5);
        const armoredAtk = (this.state === 'windup' || this.state === 'active') && this.atk && this.atk.armor;
        const flinch = this.state !== 'flex' && !armoredAtk && (info.kind !== 'light' || Math.random() < 0.35);
        return { amount: amount * mul, flinch, kbMul: 0.5 };
    }
    chooseAttack(p, d, c) {
        const r = Math.random();
        if (this.flexCd <= 0 && d < 260 && r < 0.4) { this.flexCd = rand(7, 10); this.setState('flex', 1.5); c.floatText.show(this.cx(), this.y - 30, 'YES.', '#ffd45a', 24, 1); c.world.fx.ring(this.cx(), this.y + this.h * 0.5, { r1: 90, life: 0.5, color: '#ffd45a', sq: 1 }); return null; }
        if (d < 130) return r < 0.7 ? 'gigaPunch' : 'pound';
        if (d < 300 && r < 0.25) return 'pound';
        return null;
    }
    standPose() { const b = (Math.sin(this.t * 2.5) + 1) / 2; return this.state === 'flex' ? epose('flexChad') : lerpPose(idlePose(this.t), epose('flexChad'), b * 0.3); }
    afterAttackCd() { return rand(0.9, 1.8); }
    auraColor() { return this.state === 'flex' ? '#ffd45a' : null; }
}

// ---- Đạn riêng của Dancing Meme: nốt nhạc lượn sóng + cột đèn sân khấu (Spotlight) có báo hiệu ----
class WobbleNote extends EnemyProjectile {
    constructor(x, y, vx, vy, dmg, amp, phase, color, glow) {
        super(x, y, vx, vy, 34, 34, dmg, 2.4, color, glow, { kind: 'note', spin: 8, kb: 140 });
        this.amp = amp; this.ph = phase; this.age = 0;
    }
    update(dt, particles, groundY) {
        super.update(dt, particles, groundY); this.age += dt;
        this.y += Math.cos(this.age * 7 + this.ph) * this.amp * 7 * dt;       // lượn sóng: phải canh nhịp để né
    }
}
class SpotlightProjectile extends EnemyProjectile {
    // Giai đoạn 1: vòng sáng dưới sàn (vô hại, nhấp nháy nhanh dần) -> Giai đoạn 2: cột sáng giáng xuống (gây sát thương + choáng nhẹ)
    constructor(cx, groundY, delay, dmg, color) {
        super(cx - 36, groundY - 250, 0, 0, 72, 250, dmg, delay + 0.34, color, color, { kind: 'spot', slip: true, stun: 0.35, kb: 150 });
        this.cx0 = cx; this.gy = groundY; this.delay = delay; this.age = 0; this.armed = false;
    }
    update(dt, particles) {
        this.age += dt; this.life -= dt; if (this.life <= 0) this.dead = true;
        if (!this.armed && this.age >= this.delay) {
            this.armed = true;
            particles.emit(this.cx0, this.gy - 10, 22, { spreadX: 36, vy: -420, vyRand: 260, life: 0.6, color: ['#fff', '#f0abfc', '#fde68a', '#67e8f9'], size: 4, gravity: 500 });
        }
    }
    getHitbox() { return this.armed ? { x: this.x, y: this.y, w: this.w, h: this.h } : { x: -9999, y: -9999, w: 0, h: 0 }; }
    draw(ctx, cam) {
        const sx = cam.screenX(this.cx0), sy = cam.screenY(this.gy);
        ctx.save();
        if (!this.armed) {
            const p = clamp(this.age / this.delay, 0, 1), blink = (Math.sin(this.age * (10 + 30 * p)) + 1) / 2;
            ctx.globalAlpha = 0.35 + 0.45 * blink; ctx.strokeStyle = '#f0abfc'; ctx.fillStyle = 'rgba(240,171,252,0.18)'; ctx.lineWidth = 3;
            ctx.shadowColor = '#f0abfc'; ctx.shadowBlur = 14;
            ctx.beginPath(); ctx.ellipse(sx, sy, 44, 11, 0, 0, 6.283); ctx.fill(); ctx.stroke();
            ctx.beginPath(); ctx.ellipse(sx, sy, 44 * (1 - p), 11 * (1 - p), 0, 0, 6.283); ctx.stroke();     // vòng thu nhỏ = đếm ngược
            ctx.globalAlpha = 0.5 + 0.4 * blink; ctx.fillStyle = '#fff'; ctx.font = '900 18px Impact, Arial'; ctx.textAlign = 'center';
            ctx.strokeStyle = '#000'; ctx.lineWidth = 4; ctx.strokeText('!', sx, sy - 18); ctx.fillText('!', sx, sy - 18);
        } else {
            const k = clamp(1 - (this.age - this.delay) / 0.34, 0, 1), w = this.w * (0.45 + 0.55 * k);
            ctx.globalCompositeOperation = 'lighter';
            const g = ctx.createLinearGradient(0, sy - this.h, 0, sy);
            g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.5, 'rgba(244,114,182,' + (0.55 * k + 0.1) + ')'); g.addColorStop(1, 'rgba(253,230,138,' + (0.95 * k) + ')');
            ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(sx - w * 0.28, sy - this.h); ctx.lineTo(sx + w * 0.28, sy - this.h); ctx.lineTo(sx + w / 2, sy); ctx.lineTo(sx - w / 2, sy); ctx.closePath(); ctx.fill();
            ctx.fillStyle = 'rgba(255,255,255,' + (0.8 * k) + ')'; ctx.fillRect(sx - w * 0.1, sy - this.h, w * 0.2, this.h);
            ctx.beginPath(); ctx.ellipse(sx, sy, w * 0.75, 12, 0, 0, 6.283); ctx.fill();
        }
        ctx.restore();
    }
}

// ============================================================
// 5) DANCING MEME — đánh theo NHỊP: bước → báo hiệu → xoay đá đúng phách → lùi → bắn nốt nhạc
// ============================================================
const DANCE_BEAT = 60 / 128;
const DISCO_COLORS = ['#f0abfc', '#67e8f9', '#fde68a', '#f9a8d4'];
class DancerEnemy extends Enemy {
    constructor(x, y) {
        super({ style: 'dancer', x, y, w: 52, h: 124, hp: 80, damage: 9, speed: 140, type: 'dancer', name: 'DANCING MEME', hitColor: '#f0abfc', head: 'disco' });
        this.style = Object.assign({}, RIG_STYLES.dancer, { scale: 0.655 });
        this.attackRange = 100; this.deathLine = '\u266A stayin alive \u266A'; this.beatT = rand(0, DANCE_BEAT); this.beatIdx = 0; this.beatFlash = 0; this.stepT = 0;
        this.bar = 0; this.fever = false;
        this.attacks = {
            // FEVER SPIN — báo hiệu 1 nhịp, nhảy lên xoay 360° (trúng cả hai phía), tiếp đất tạo vòng sóng + 2 làn sóng ánh sáng chạy sát đất (nhảy qua được)
            spin: { windup: DANCE_BEAT - 0.06, active: 0.7, recover: 0.42, dmg: 10, kb: 280, spin: true, reach: 86, h: 80, y: 24, hop: 430, vx: 190, wind: 'castUp', hit: 'spinKick', tell: true,
                onActive: (e, c) => { c.floatText.show(e.cx(), e.y - 46, 'FEVER SPIN!', '#f0abfc', 16, 0.7); },
                onLand: (e, c) => {
                    c.world.fx.ring(e.cx(), e.y + e.h, { r1: 130, life: 0.45, color: '#f0abfc', w: 7, sq: 0.3 });
                    c.world.fx.ring(e.cx(), e.y + e.h, { r1: 90, life: 0.35, color: '#67e8f9', w: 4, sq: 0.3 });
                    c.world.camera.shake(7, 0.2); c.particles.dust(e.cx(), e.y + e.h);
                    for (const dir of [-1, 1]) c.projectiles.push(new EnemyProjectile(e.cx() + dir * 44, c.groundY - 38, dir * (e.fever ? 470 : 400), 0, 96, 38, 7, 1.5, '#f9a8d4', '#f0abfc', { kind: 'wave', kb: 230 }));
                } },
            // NOTE BARRAGE — 3 nốt nhạc lượn sóng (5 nốt khi FEVER); đứng yên sẽ bị trúng, hãy canh nhịp lượn mà lách
            notes: { windup: 0.25, active: 0.1, recover: 0.3, dmg: 7, wind: 'castUp', hit: 'shoot',
                onActive: (e, c) => {
                    const dir = e.facingRight ? 1 : -1, n = e.fever ? 5 : 3;
                    c.floatText.show(e.cx(), e.y - 46, '\u266B', '#f9a8d4', 22, 0.6);
                    for (let i = 0; i < n; i++) {
                        const k = i - (n - 1) / 2;
                        c.projectiles.push(new WobbleNote(e.cx() + dir * 26, e.y + 30, dir * (300 + Math.abs(k) * 20), k * 38, 6, 16 + Math.abs(k) * 6, k * 1.4, DISCO_COLORS[i % 4], '#f0abfc'));
                    }
                } },
            // SPOTLIGHT DROP — chỉ tay lên trời: đèn sân khấu khoá vị trí bạn, vòng sáng đếm ngược 1,5 nhịp rồi cột sáng giáng xuống + choáng nhẹ
            spotlight: { windup: 0.32, active: 0.1, recover: 0.55, dmg: 0, wind: 'castUp', hit: 'castUp', tell: true,
                onActive: (e, c) => {
                    const p = c.player, px = p.x + p.w / 2, d0 = DANCE_BEAT * 1.5;
                    c.floatText.show(e.cx(), e.y - 46, 'SPOTLIGHT!', '#fde68a', 16, 0.8);
                    c.projectiles.push(new SpotlightProjectile(px, c.groundY, d0, 11, '#f9a8d4'));
                    if (e.fever) for (const off of [-150, 150]) c.projectiles.push(new SpotlightProjectile(clamp(px + off, 60, c.mapWidth - 60), c.groundY, d0 + DANCE_BEAT * 0.5, 11, '#67e8f9'));
                } }
        };
    }
    discoColor() { return DISCO_COLORS[this.beatIdx % 4]; }
    preUpdate(dt, c) {
        if (!this.fever && this.hp < this.maxHp * 0.4) {      // DISCO FEVER — dưới 40% máu: nhanh hơn, nhiều nốt hơn, 3 đèn cùng lúc
            this.fever = true; this.speed *= 1.15;
            c.floatText.show(this.cx(), this.y - 50, 'DISCO FEVER!', '#f0abfc', 18, 1.2);
            c.world.fx.ring(this.cx(), this.y + this.h * 0.5, { r1: 200, life: 0.6, color: '#f0abfc', w: 8, sq: 1 });
        }
        this.beatFlash = Math.max(0, this.beatFlash - dt * 3); this.stepT = Math.max(0, this.stepT - dt);
        if (this.stepT <= 0 && ['idle', 'chase'].includes(this.state)) this.vx *= Math.pow(0.001, dt);
        this.beatT += dt;
        if (this.beatT >= DANCE_BEAT) { this.beatT -= DANCE_BEAT; this.beatIdx = (this.beatIdx + 1) % 8; if (this.beatIdx === 0) this.bar++; this.beatFlash = 1; this.onBeat(c); }
    }
    onBeat(c) {
        if (!['idle', 'chase', 'recover'].includes(this.state)) return;
        const p = c.player, d = Math.abs(this.dx(p)), dir = this.dirTo(p);
        this.faceP(p);
        c.particles.emit(this.cx(), this.y + this.h, 3, { spreadX: 20, vy: -60, life: 0.4, color: [this.discoColor(), '#fde68a'], size: 3, gravity: 0 });
        switch (this.beatIdx) {
            case 0: case 1: if (d > 120) { this.vx = dir * 280; this.stepT = 0.18; this.state = 'chase'; } break;         // bước tiến theo nhịp
            case 2: if (d < 280) this.startAtk('spin', p); else this.startAtk('spotlight', p); break;                     // phách 3: Fever Spin (gần) / Spotlight (xa)
            case 3: c.world.fx.ring(this.cx(), this.y + this.h * 0.5, { r1: 60, life: 0.3, color: this.discoColor(), w: 3, sq: 1 }); break;   // tạo dáng
            case 4: case 5: this.vx = -dir * 220; this.stepT = 0.2;                                                         // MOONWALK lùi + vệt sáng
                c.particles.emit(this.cx(), this.y + this.h - 4, 6, { spreadX: 24, vy: -30, life: 0.5, color: ['#fff', this.discoColor()], size: 3, gravity: 0 }); break;
            case 6: if (d > 130 && d < 520) { if (this.bar % 2 === 0) this.startAtk('notes', p); else this.startAtk('spotlight', p); } break;
            case 7: if (this.fever && this.bar % 2 === 1 && d < 520) this.startAtk('notes', p); break;
        }
    }
    think(dt, c) { this.faceP(c.player); if (Math.abs(this.dx(c.player)) > 420) { this.state = 'chase'; this.vx = this.dirTo(c.player) * this.speed; } else this.state = 'idle'; }
    standPose() { const d = dancePose(this.t * (this.fever ? 1.25 : 0.9)); d.flex = 0.2; return d; }
    getPose() {
        if (this.state === 'active' && this.atk && this.atk.spin) { const p = clamp(1 - this.stateTimer / this.phaseDur, 0, 1); const o = Object.assign({}, epose('spinKick')); o.lean = p * Math.PI * 2; return o; }
        return super.getPose();
    }
    drawBody(ctx, cam, x, y, dir, flash, alpha) {
        const f = this.beatFlash, col = this.discoColor();      // vòng nhịp dưới chân: đổi màu theo từng phách
        ctx.save(); ctx.shadowColor = col; ctx.shadowBlur = 12; ctx.strokeStyle = col; ctx.lineWidth = 3;
        ctx.globalAlpha = 0.25 + 0.5 * f; ctx.beginPath(); ctx.ellipse(x, y, 36 + (1 - f) * 22, 9 + (1 - f) * 5, 0, 0, 6.283); ctx.stroke();
        ctx.globalAlpha = 0.15 + 0.3 * f; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(x, y, 24 + (1 - f) * 10, 6 + (1 - f) * 3, 0, 0, 6.283); ctx.stroke();
        ctx.globalAlpha = 0.5 + 0.4 * f; ctx.fillStyle = '#fff'; ctx.shadowBlur = 6;       // 4 đốm sáng quay quanh vòng
        for (let i = 0; i < 4; i++) { const a = this.t * 2.4 + i * 1.571; ctx.fillRect(x + Math.cos(a) * 36 - 1.5, y + Math.sin(a) * 9 - 1.5, 3, 3); }
        ctx.restore();
        super.drawBody(ctx, cam, x, y, dir, flash, alpha);
    }
    afterAttackCd() { return 0.1; }
    auraColor() { return this.beatFlash > 0.6 || this.fever ? this.discoColor() : null; }
}

// ============================================================
// 6) SIGMA MEME — tinh nhuệ: tư thế đỡ (GUARD) bắt đòn thường rồi PHẢN CÔNG; đòn mạnh / kỹ năng phá thế đỡ
// ============================================================
class SigmaEnemy extends Enemy {
    constructor(x, y) {
        super({ style: 'sigma', x, y, w: 54, h: 134, hp: 120, damage: 12, speed: 165, type: 'sigma', name: 'SIGMA MEME', hitColor: '#cbd5e1', head: 'sigma' });
        this.style = Object.assign({}, RIG_STYLES.sigma, { scale: 0.7 });
        this.attackRange = 84; this.deathLine = 'Grindset over.'; this.guardCd = 2; this.counterNext = false; this.rage = false;
        this.attacks = {
            slash: { windup: 0.3, active: 0.12, recover: 0.35, dmg: 12, kb: 240, reach: 84, h: 56, y: 34, vx: 260, wind: 'sigWind', hit: 'sigSlash', tell: true, onEnd: (e, c) => { if (Math.random() < 0.6) e.startAtk('slash2', c.player); } },
            slash2: { windup: 0.1, active: 0.12, recover: 0.45, dmg: 12, kb: 260, reach: 88, h: 56, y: 34, vx: 280, wind: 'sigWind', hit: 'sigSlash' },
            dash: { windup: 0.4, active: 0.3, recover: 0.55, dmg: 16, kb: 330, reach: 74, h: 60, y: 34, vx: 900, wind: 'sigWind', hit: 'sigSlash', tell: true },
            counter: { windup: 0.12, active: 0.16, recover: 0.5, dmg: 17, kb: 360, reach: 92, h: 60, y: 34, vx: 430, wind: 'sigWind', hit: 'sigSlash', shake: 10 }
        };
    }
    preUpdate(dt, c) {
        this.guardCd = Math.max(0, this.guardCd - dt);
        if (!this.rage && this.hp < this.maxHp * 0.4) { this.rage = true; this.speed *= 1.25; c.floatText.show(this.cx(), this.y - 40, 'SIGMA GRINDSET', '#e2e8f0', 16, 1.2); }
    }
    updateSpecial(dt, c) {
        if (this.state === 'guard') {
            this.vx = 0; this.faceP(c.player);
            if (this.counterNext) { this.counterNext = false; this.startAtk('counter', c.player); return true; }
            if (this.stateTimer <= 0) { this.setState('idle', 0.1); this.guardCd = rand(3, 4.5); }
            return true;
        }
        return false;
    }
    onHitFilter(amount, kbDir, info, fx) {
        if (this.state === 'guard') {
            const fromFront = (-kbDir) === (this.facingRight ? 1 : -1);
            if (fromFront && (info.kind === 'light' || info.kind === 'proj')) {     // PARRY
                fx.floatText.show(this.cx(), this.y - 30, 'PARRY!', '#e2e8f0', 22, 0.8); fx.particles.hitSpark(this.cx() + (this.facingRight ? 24 : -24), this.y + 50, '#fff');
                this.counterNext = true; return { result: 'parried' };
            }
            fx.floatText.show(this.cx(), this.y - 30, 'GUARD BREAK!', '#fde047', 20, 0.9);   // đòn mạnh / kỹ năng phá giáp
            return { amount: amount * 0.7, flinch: true };
        }
        return { amount, flinch: true };
    }
    chooseAttack(p, d, c) {
        const r = Math.random();
        if (this.guardCd <= 0 && d < 150 && r < 0.5) { this.setState('guard', rand(1.1, 1.6)); return null; }
        if (d < 100) return 'slash';
        if (d > 140 && d < 400 && r < 0.14) return 'dash';
        return null;
    }
    standPose() { return this.state === 'guard' ? epose('guardCross') : idlePose(this.t); }
    afterAttackCd() { return rand(0.5, 1.1) * (this.rage ? 0.65 : 1); }
    auraColor() { return this.rage ? '#e2e8f0' : null; }
}

// ============================================================
// 7) ULTIMATE MEME LORD — boss 3 giai đoạn: quả cầu meme + đập / sóng đất + triệu hồi / dịch chuyển + tia laser
// ============================================================
class MemeLord extends Enemy {
    constructor(x, y) {
        super({ style: 'lord', x, y, w: 118, h: 226, hp: 900, damage: 18, speed: 92, type: 'boss', name: 'ULTIMATE MEME LORD', hitColor: '#a855f7', head: 'lord' });
        this.style = Object.assign({}, RIG_STYLES.lord, { scale: 1.1 });
        this.landFx = 0; this.castFx = 0;
        this.isBoss = true; this.phase = 1; this.attackRange = 150; this.deathDur = 2.6; this.stepRate = 6; this.deathLine = 'MEME FOREVER...';
        this.orbs = [{ a: 0, key: 'doge_full', alive: true, rt: 0 }, { a: 2.09, key: 'chad', alive: true, rt: 0 }, { a: 4.19, key: 'troll', alive: true, rt: 0 }];
        this.orbCd = 3; this.summonCd = 10; this.beamCd = 7; this.blinkCd = 6; this.slamCd = 5; this.sub = 0; this.beamHit = 0; this.blinkTo = null; this.fired = 0; this.summoned = false;
        // kỹ năng MỚI của phase 3
        this.rainCd = 5; this.pillarCd = 4; this.barrageCd = 3; this.rushCd = 5;
        this.rage = false; this.lastSkill = ''; this.beamShots = [[1.0, 2.5, 140]]; this._lastShot = null; this.rainN = 0; this.pilN = 0; this.barN = 0; this.pilPlan = [];
        this.attacks = {
            smash: { windup: 0.85, active: 0.26, recover: 0.7, dmg: 22, kb: 460, reach: 150, h: 130, y: 70, wind: 'bossWind', hit: 'bossSmash', armor: true, tell: true, shake: 14 },
            swipe: { windup: 0.5, active: 0.2, recover: 0.45, dmg: 16, kb: 300, reach: 135, h: 110, y: 80, vx: 160, wind: 'p3', hit: 'p4', tell: true },
            slam: { windup: 0.9, active: 0.7, recover: 0.85, dmg: 20, kb: 320, reach: 130, h: 70, y: 150, hop: 620, wind: 'crouch', hit: 'pound', armor: true, pierce: true, tell: true,
                onLand: (e, c) => {
                    const p3 = e.phase >= 3, F = pfx(), cols = p3 ? ['#fee2e2', '#f87171', '#b91c1c', '#450a0a'] : ['#f3e8ff', '#c084fc', '#7e22ce', '#2e1065'];
                    c.world.camera.shake(p3 ? 22 : 16, 0.45); c.audio.playBigImpact(); e.landFx = 0.6;
                    if (F) F.groundBlast(e.cx(), c.groundY, p3 ? 360 : 280, [cols[0], cols[1], cols[2]]);
                    c.world.fx.shock(e.cx(), e.y + e.h, { r1: 260, life: 0.5, color: p3 ? '#ef4444' : '#a855f7' });
                    for (const dir of [-1, 1]) {
                        c.projectiles.push(new EnemyProjectile(e.cx() + dir * 50, c.groundY - 38, dir * 430, 0, 110, 38, 18, 1.8, cols[1], cols[2], { kind: 'wave', pierce: true, kb: 320, cols }));
                        if (p3) c.projectiles.push(new EnemyProjectile(e.cx() + dir * 90, c.groundY - 38, dir * 290, 0, 110, 38, 16, 2.4, cols[1], cols[2], { kind: 'wave', pierce: true, kb: 300, cols }));
                    }
                } },
            // TROLL RUSH (phase 3): gồng rồi lao xuyên màn hình
            rush: { windup: 0.55, active: 0.5, recover: 0.55, dmg: 20, kb: 520, reach: 150, h: 130, y: 70, vx: 1150, wind: 'bossWind', hit: 'bossSmash', armor: true, pierce: true, tell: true, shake: 16,
                onActive: (e, c) => { const F = pfx(); if (F) { F.pop(e.cx(), e.y + e.h * 0.5, 200, '#fecaca', 0.35); F.sparks(e.cx(), c.groundY - 6, 26, { col: ['#fff', '#fca5a5', '#ef4444'], angle: e.facingRight ? Math.PI : 0, cone: 1.2, min: 150, max: 520, g: 300, life: 0.5 }); } c.world.camera.shake(10, 0.3); } }
        };
    }
    phaseColor() { return this.phase === 1 ? '#a855f7' : (this.phase === 2 ? '#fbbf24' : '#ef4444'); }
    phaseColor2() { return this.phase === 1 ? '#f0abfc' : (this.phase === 2 ? '#fde68a' : '#fecaca'); }
    auraColor() { return this.phaseColor(); }
    _cd(a, b) { return this.phase >= 3 ? rand(0.2, 0.5) * (this.rage ? 0.7 : 1) : rand(a, b); }
    preUpdate(dt, c) {
        const k = this.rage ? 1.4 : 1, F = pfx();
        for (const n of ['orbCd', 'summonCd', 'beamCd', 'blinkCd', 'slamCd', 'rainCd', 'pillarCd', 'barrageCd', 'rushCd']) this[n] = Math.max(0, this[n] - dt * (this.phase >= 3 ? k : 1));
        this.landFx = Math.max(0, this.landFx - dt);
        if (this.state === 'chase') this.walkD = (this.walkD || 0) + Math.abs(this.vx) * dt;
        for (const o of this.orbs) { o.a += dt * (this.phase >= 3 ? 2.4 : 1.6); if (!o.alive) { o.rt -= dt; if (o.rt <= 0) o.alive = true; } }
        if (this.phase === 1 && this.hp <= this.maxHp * 0.66) this.enterPhase(2, c);
        else if (this.phase === 2 && this.hp <= this.maxHp * 0.33) this.enterPhase(3, c);
        // phase 3: dưới 12% máu -> NỔI ĐIÊN (nhanh hơn, hồi chiêu rút ngắn)
        if (this.phase === 3 && !this.rage && !this.dead && this.hp <= this.maxHp * 0.12) {
            this.rage = true; c.floatText.show(this.cx(), this.y - 50, 'OVERDRIVE!!', '#fecaca', 24, 1.4); c.world.camera.shake(14, 0.6); c.world.flash(0.35);
            if (F) { F.ring(this.cx(), this.y + this.h * 0.5, 20, 420, 0.7, '#fecaca', { n: 48 }); F.text(this.cx(), this.y - 90, 'OVERDRIVE', '#ef4444', 1.4, 18); }
        }
        // vệt bụi khi lao
        if (F && this.state === 'active' && this.atkName === 'rush' && Math.random() < 0.8) F.sparks(this.cx() - (this.facingRight ? 1 : -1) * 50, c.groundY - 6, 2, { col: ['#fff', '#fca5a5', '#ef4444'], angle: -Math.PI / 2, cone: 1.6, min: 40, max: 220, g: 500, life: 0.45 });
        // phase 3: tàn lửa pixel quanh người
        if (F && this.phase >= 3 && !this.dead && Math.random() < 0.35) F.sparks(this.cx() + rand(-50, 50), this.y + this.h * rand(0.2, 1), 1, { col: ['#ef4444', '#fecaca', '#fbbf24'], angle: -Math.PI / 2, cone: 0.6, min: 40, max: 130, g: -60, life: 0.9, size: 3 });
    }
    enterPhase(n, c) {
        this.phase = n; this.atk = null; this.setState('phase', 1.8); this.invulnTimer = 1.8; this.hitTargets.clear();
        const col = this.phaseColor(), F = pfx();
        c.audio.playRoar(); c.world.camera.shake(n === 3 ? 26 : 18, n === 3 ? 1.2 : 0.8); c.world.flash(n === 3 ? 0.8 : 0.5);
        c.world.banner(`PHASE ${n}`, n === 2 ? 'MEME ARMY' : 'TROLL OVERDRIVE', 1.8, col);
        c.world.fx.ring(this.cx(), this.y + this.h * 0.5, { r1: 320, life: 0.8, color: col, w: 9, sq: 1 });
        c.particles.emit(this.cx(), this.y + this.h * 0.5, 40, { vxRand: 600, vyRand: 600, life: 0.9, color: [col, '#fff'], size: 5, gravity: 0 });
        if (F) {
            F.ring(this.cx(), this.y + this.h * 0.5, 20, 520, 0.9, this.phaseColor2(), { n: 60 }); F.ring(this.cx(), c.groundY, 20, 640, 0.9, col, { sq: 0.28, n: 70 });
            F.sparks(this.cx(), this.y + this.h * 0.5, 70, { col: [col, '#fff', this.phaseColor2()], min: 150, max: 700, g: 0, life: 0.9, drag: 0.03 });
            F.text(this.cx(), this.y - 70, n === 2 ? 'MEME ARMY' : 'OVERDRIVE', col, 1.6, 18);
        }
        this.orbCd = 1.5;
        if (n === 3) { this.rainCd = 3; this.pillarCd = 1.5; this.barrageCd = 0.8; this.rushCd = 2.5; this.beamCd = 4; this.blinkCd = 2; this.slamCd = 3; }
    }
    // ----- tiện ích phase 3 -----
    _shot(e) { for (const s of this.beamShots) if (e >= s[0] && e < s[1]) return s; return null; }
    _heads() { return ['doge_full', 'chad', 'troll']; }
    _meteor(c, i) {
        const p = c.player, F = pfx(), px = p.x + p.w / 2;
        const tx = i % 3 === 0 ? clamp(px + rand(-30, 30) + p.vx * 0.35, 60, c.mapWidth - 60) : clamp(px + rand(-560, 560), 60, c.mapWidth - 60);
        if (F) F.mark(tx, c.groundY, 0.7, '#ff4d4d');
        c.projectiles.push(new EnemyProjectile(tx - 26, -150, 0, 920, 52, 52, 12, 1.4, '#2a0e0e', '#ff7a1f', { kind: 'meteor', headKey: this._heads()[i % 3], kb: 260 }));
    }
    _fan(c, k) {
        const p = c.player, n = k % 2 ? 6 : 7, dir = this.facingRight ? 1 : -1, ox = this.cx() + dir * 50, oy = this.y + this.h * 0.38;
        const a0 = Math.atan2((p.y + p.h * 0.5) - oy, (p.x + p.w / 2) - ox), sp = 400 + k * 35;
        for (let i = 0; i < n; i++) {
            const ang = a0 + (i - (n - 1) / 2) * 0.2;
            c.projectiles.push(new EnemyProjectile(ox - 20, oy - 20, Math.cos(ang) * sp, Math.sin(ang) * sp, 40, 40, 9, 3, '#1b1240', '#ef4444', { kind: 'orb', headKey: this._heads()[(i + k) % 3], kb: 160 }));
        }
        c.audio.playSwingEnemy(); const F = pfx(); if (F) F.pop(ox, oy, 120, '#fecaca', 0.3);
    }
    _pillars(c, k) {
        const p = c.player, F = pfx(), px = p.x + p.w / 2 + p.vx * 0.3, plan = [[0], [-170, 170], [-340, 0, 340], this.rage ? [-170, 0, 170] : [0]][k] || [0];
        for (const off of plan) c.projectiles.push(new TrollPillar(clamp(px + off, 60, c.mapWidth - 60), c.groundY, 0.75, '#ef4444', '#fbbf24'));
        c.audio.playSwingEnemy();
    }
    updateSpecial(dt, c) {
        const p = c.player, st = this.state, F = pfx();
        if (st === 'phase') { this.vx = 0; if (this.stateTimer <= 0) { this.setState('idle', 0.2); } return true; }
        if (st === 'orbs') {      // niệm chú rồi bắn lần lượt các quả cầu meme
            this.vx = 0; this.faceP(p); const e = this.phaseDur - this.stateTimer;
            while (this.fired < 3 && e >= 0.5 + 0.28 * this.fired) {
                const o = this.orbs[this.fired]; this.fired++;
                if (!o.alive) continue;
                o.alive = false; o.rt = this.phase >= 3 ? 2.5 : 6;
                const ox = this.cx() + Math.cos(o.a) * 120, oy = this.y + this.h * 0.4 + Math.sin(o.a) * 40;
                const ang = Math.atan2((p.y + p.h * 0.5) - oy, (p.x + p.w / 2) - ox), sp = this.phase === 3 ? 470 : 380;
                c.projectiles.push(new EnemyProjectile(ox - 24, oy - 24, Math.cos(ang) * sp, Math.sin(ang) * sp, 48, 48, 10, 3, '#312e81', '#a855f7', { kind: 'orb', headKey: o.key, kb: 200 }));
                c.audio.playSwingEnemy();
            }
            if (this.stateTimer <= 0) { this.setState('idle', 0.1); this.attackCooldown = this._cd(0.8, 1.4); }
            return true;
        }
        if (st === 'summon') {
            this.vx = 0; const e = this.phaseDur - this.stateTimer;
            if (!this.summoned && e >= 0.6) {
                this.summoned = true;
                const types = ['doge', 'troll'], n = Math.min(2, 3 - c.manager.getMinionCount());
                for (let i = 0; i < n; i++) { const sx = clamp(this.cx() + (i ? 190 : -190), 60, c.mapWidth - 100); c.manager.spawnEnemy(types[i % 2], sx, c.groundY - 200); c.world.fx.ring(sx + 30, c.groundY, { r1: 70, life: 0.5, color: '#fbbf24', sq: 0.3 }); if (F) { F.circle(sx + 30, c.groundY, 200, 0.8, '#fbbf24', '#fff'); F.sparks(sx + 30, c.groundY - 20, 24, { col: ['#fbbf24', '#fff'], angle: -Math.PI / 2, cone: 1.2, min: 100, max: 360, g: 700, life: 0.6 }); } }
                c.floatText.show(this.cx(), this.y - 30, 'MEME ALERT!', '#fbbf24', 26, 1.1); c.world.camera.shake(8, 0.3);
            }
            if (this.stateTimer <= 0) { this.setState('idle', 0.1); this.attackCooldown = this._cd(0.8, 1.2); }
            return true;
        }
        if (st === 'beam') {      // laser quét ngang: báo hiệu -> bắn -> hồi (phase 3: 3 loạt, có loạt thấp phải nhảy qua)
            this.vx = 0; this.faceP(p); const e = this.phaseDur - this.stateTimer, sh = this._shot(e);
            if (sh) {
                if (sh !== this._lastShot) { this._lastShot = sh; this.beamHit = 0; c.audio.playBigImpact(); }
                this.beamHit -= dt; if (this.beamHit <= 0) { this.beamHit = 0.42; this.hitTargets.clear(); } if (Math.random() < 0.5) c.world.camera.shake(3, 0.1);
            } else this._lastShot = null;
            if (this.stateTimer <= 0) { this._lastShot = null; this.setState('idle', 0.1); this.attackCooldown = this._cd(0.9, 1.4); }
            return true;
        }
        if (st === 'rain') {      // TROLL METEOR RAIN: gồng -> mưa thiên thạch có dấu X báo trước
            this.vx = 0; this.faceP(p); const e = this.phaseDur - this.stateTimer, t0 = 0.9, gap = this.rage ? 0.13 : 0.17, N = this.rage ? 18 : 14;
            if (F && e < t0 && Math.random() < 0.5) F.implode(this.cx(), this.y + this.h * 0.45, 260, ['#ef4444', '#fbbf24', '#ffffff'], 2, 0.4);
            while (this.rainN < N && e >= t0 + gap * this.rainN) { this._meteor(c, this.rainN); this.rainN++; }
            if (this.stateTimer <= 0) { this.setState('idle', 0.1); this.attackCooldown = this._cd(0.8, 1.2); }
            return true;
        }
        if (st === 'pillars') {   // TROLL PILLARS: 4 đợt cột lửa nổ dưới chân, mỗi đợt rộng hơn
            this.vx = 0; this.faceP(p); const e = this.phaseDur - this.stateTimer, T = [0.7, 1.15, 1.6, 2.05];
            if (F && e < 0.7 && Math.random() < 0.5) F.implode(this.cx(), this.y + this.h * 0.45, 240, ['#ef4444', '#fbbf24', '#ffffff'], 2, 0.4);
            while (this.pilN < T.length && e >= T[this.pilN]) { this._pillars(c, this.pilN); this.pilN++; }
            if (this.stateTimer <= 0) { this.setState('idle', 0.1); this.attackCooldown = this._cd(0.8, 1.2); }
            return true;
        }
        if (st === 'barrage') {   // FAN BARRAGE: 4 đợt đạn toả quạt
            this.vx = 0; this.faceP(p); const e = this.phaseDur - this.stateTimer, T = this.rage ? [0.45, 0.8, 1.15, 1.5, 1.85] : [0.5, 0.95, 1.4, 1.85];
            while (this.barN < T.length && e >= T[this.barN]) { this._fan(c, this.barN); this.barN++; }
            if (this.stateTimer <= 0) { this.setState('idle', 0.1); this.attackCooldown = this._cd(0.8, 1.2); }
            return true;
        }
        if (st === 'blink') {
            this.vx = 0; const prog = 1 - this.stateTimer / this.phaseDur;
            if (prog < 0.5) this.alpha = 1 - prog * 2;
            else {
                if (this.blinkTo !== null) {
                    this.x = this.blinkTo; this.blinkTo = null; this.faceP(p); c.world.fx.ring(this.cx(), this.y + this.h * 0.5, { r1: 140, life: 0.4, color: '#ef4444', sq: 1 });
                    if (F) { F.implode(this.cx(), this.y + this.h * 0.5, 260, ['#ef4444', '#fecaca', '#fff'], 36, 0.35); F.ring(this.cx(), c.groundY, 10, 260, 0.5, '#ef4444', { sq: 0.28, n: 40 }); F.pop(this.cx(), this.y + this.h * 0.5, 180, '#fecaca', 0.4); }
                }
                this.alpha = (prog - 0.5) * 2;
            }
            if (this.stateTimer <= 0) { this.alpha = 1; this.setState('idle', 0.05); this.faceP(p); this.startAtk(Math.random() < 0.6 ? 'smash' : 'swipe', p); }
            return true;
        }
        return false;
    }
    onHitFilter(amount, kbDir, info) {
        if (this.state === 'phase') return { result: 'none' };
        const free = ['idle', 'chase', 'recover', 'hurt'].includes(this.state);
        const flinch = free && (info.kind !== 'light' || Math.random() < 0.25);
        return { amount: info.kind === 'ult' ? amount * 0.6 : amount, flinch, kbMul: 0.15 };
    }
    think(dt, c) {
        const p = c.player, d = Math.abs(this.dx(p)), p3 = this.phase >= 3, F = pfx(), cdm = (this.rage ? 0.7 : 1) * ((DIFFICULTIES[this.difficulty] || DIFFICULTIES.normal).cooldown);
        this.faceP(p);
        if (d > this.attackRange - 10) { this.state = 'chase'; this.vx = this.dirTo(p) * this.speed * (p3 ? (this.rage ? 1.5 : 1.3) : 1); } else { this.state = 'idle'; this.vx *= 0.7; }
        if (this.attackCooldown > 0) return;
        const pool = [], add = (name, w, fn) => { if (name !== this.lastSkill) pool.push([w, name, fn]); };
        if (p3 && this.beamCd <= 0 && d > 150) add('beam', 3, () => { this.beamCd = 8 * cdm; this.beamShots = [[0.8, 1.5, 140], [1.8, 2.4, 56], [2.7, 3.5, 140]]; this._lastShot = null; this.faceP(p); this.setState('beam', 3.9); });
        if (p3 && this.rainCd <= 0) add('rain', 3, () => { this.rainCd = 11 * cdm; this.rainN = 0; this.setState('rain', this.rage ? 4.0 : 3.6); c.audio.playRoar(); });
        if (p3 && this.pillarCd <= 0) add('pillars', 3, () => { this.pillarCd = 8 * cdm; this.pilN = 0; this.setState('pillars', 2.8); c.audio.playRoar(); });
        if (p3 && this.barrageCd <= 0 && d > 110) add('barrage', 3, () => { this.barrageCd = 6 * cdm; this.barN = 0; this.setState('barrage', this.rage ? 2.5 : 2.3); });
        if (p3 && this.rushCd <= 0 && d > 220 && d < 700) add('rush', 3, () => { this.rushCd = 6 * cdm; this.startAtk('rush', p); });
        if (p3 && this.blinkCd <= 0) add('blink', 2, () => { this.blinkCd = 5 * cdm; const pd = p.facingRight ? 1 : -1; this.blinkTo = clamp(p.x + p.w / 2 - pd * 170 - this.w / 2, 40, c.mapWidth - this.w - 40); this.setState('blink', 0.6); if (F) { F.dissolve(this.cx(), this.y, 90, this.h, ['#ef4444', '#fecaca', '#fff', '#7f1d1d'], 60); F.circle(this.cx(), c.groundY, 260, 0.6, '#ef4444', '#fff'); } });
        if (this.phase >= 2 && this.summonCd <= 0 && c.manager.getMinionCount() < 2) add('summon', p3 ? 1 : 2, () => { this.summonCd = p3 ? 20 : 16; this.summoned = false; this.setState('summon', 1.4); c.audio.playRoar(); });
        if (this.phase >= 2 && this.slamCd <= 0 && d < 450) add('slam', 2, () => { this.slamCd = p3 ? 6 * cdm : 8; this.startAtk('slam', p); });
        if (this.orbCd <= 0 && d > 160 && this.orbs.some(o => o.alive)) add('orbs', 2, () => { this.orbCd = p3 ? 3.5 : 5; this.fired = 0; this.setState('orbs', 1.5); });
        if (pool.length && (Math.random() < (p3 ? 0.9 : 0.55))) {
            let tot = pool.reduce((s, a) => s + a[0], 0), r = Math.random() * tot;
            for (const [w, name, fn] of pool) { r -= w; if (r <= 0) { this.lastSkill = name; fn(); return; } }
        }
        if (d < 170) { this.lastSkill = 'melee'; this.startAtk(Math.random() < 0.55 ? 'smash' : 'swipe', p); }
    }
    afterAttackCd() { return rand(0.9, 1.6) * (this.phase === 3 ? 0.3 * (this.rage ? 0.7 : 1) : this.phase === 2 ? 0.8 : 1); }
    getHitbox() {
        if (this.state === 'beam') {
            const e = this.phaseDur - this.stateTimer, sh = this._shot(e); if (!sh) return null;
            const dir = this.facingRight ? 1 : -1; return { x: dir > 0 ? this.cx() : this.cx() - 900, y: this.y + this.h - sh[2], w: 900, h: 48 };
        }
        return super.getHitbox();
    }
    getAttackInfo() { if (this.state === 'beam') return { damage: this.phase >= 3 ? 16 : 14, kb: 260, pierce: true, shake: 5 }; return super.getAttackInfo(); }
    // Chọn khung sprite theo trạng thái (như ChadEnemy._sprite): niệm phép = skill_0/1, laser = skill_1 -> skill_2, đập đất = jump_*, đấm = attack_*
    _sprite() {
        const st = this.state, t = this.t, age = this.phaseDur - this.stateTimer, an = this.atkName, slam = an === 'slam', rush = an === 'rush', L = LordSprite, p01 = clamp(age / this.phaseDur, 0, 1);
        if (this.dead) { const p = clamp(1 - this.stateTimer / this.deathDur, 0, 1); return { k: 'hurt_0', rot: -clamp(p * 3, 0, 1) * 1.45, feet: true, lift: 18 }; }
        switch (st) {
            case 'hurt': return age < 0.12 ? L.bl('hurt_0', 'hurt_1', age / 0.12, { rot: Math.sin(t * 30) * 0.03 }) : (this.stateTimer < 0.14 ? L.bl('hurt_1', 'idle_0', 1 - this.stateTimer / 0.14) : { k: 'hurt_1', rot: Math.sin(t * 30) * 0.03 });
            case 'phase': return age < 0.5 ? L.bl('skill_0', 'skill_1', (age - 0.3) / 0.2, { by: Math.sin(t * 40) * 2 }) : { k: 'skill_1', by: Math.sin(t * 40) * 2, sx: 1 + Math.sin(t * 18) * 0.03 };
            case 'orbs': return L.bl('skill_0', 'skill_1', (age - 0.25) / 0.2, { by: Math.sin(t * 24) * 1.2 });
            case 'summon': return L.bl('skill_0', 'skill_1', (age - 0.4) / 0.25, { by: Math.sin(t * 20) * 1.5 });
            case 'rain': return L.bl('skill_0', 'skill_1', (age - 0.3) / 0.3, { by: Math.sin(t * 36) * 1.8, sx: 1 + Math.sin(t * 14) * 0.02 });
            case 'pillars': return L.bl('skill_0', 'skill_1', (age - 0.25) / 0.25, { by: Math.sin(t * 30) * 1.6 });
            case 'barrage': return age % 0.45 < 0.12 ? { k: 'attack_1', sx: 1.03 } : L.bl('skill_0', 'skill_1', 0.8, { by: Math.sin(t * 30) * 1.2 });
            case 'beam': { const sh = this._shot(age); return !sh && age < 0.8 ? { k: 'skill_1', by: Math.sin(t * 50) * 1.5, sx: 1 + age * 0.02 } : (sh ? L.bl('skill_1', 'skill_2', (age - sh[0]) / 0.12, { by: Math.sin(t * 60) }) : { k: 'skill_1', by: Math.sin(t * 40) }); }
            case 'blink': return { k: 'skill_0' };
            case 'windup': {
                if (slam) return L.bl('idle_0', 'jump_0', age / 0.25);
                return L.bl('idle_0', 'attack_0', age / Math.min(0.3, this.phaseDur * 0.6), { rot: -p01 * 0.05, sx: 1 + p01 * 0.03 });
            }
            case 'active':
                if (slam) return { k: this.grounded ? 'jump_3' : (this.vy < -220 ? 'jump_1' : 'jump_2') };
                if (rush) return { k: 'skill_2', rot: 0.08 };
                return L.bl('attack_0', an === 'swipe' ? 'attack_2' : 'attack_1', p01 / 0.3);
            case 'recover': {
                const p = clamp(1 - this.stateTimer / this.phaseDur, 0, 1);
                if (slam) return L.bl('jump_3', 'idle_0', (p - 0.35) / 0.5);
                return L.bl(an === 'swipe' ? 'attack_0' : 'attack_2', 'idle_0', (p - 0.3) / 0.6);
            }
            case 'chase': return Math.abs(this.vx) > 115 ? L.run(this.walkD || 0) : L.walk(this.walkD || 0);
            default: return this.grounded ? L.idle(t) : { k: 'jump_2' };
        }
    }
    getPose() { return POSE0; }
    drawBody(ctx, cam, x, y, dir, flash, alpha) {
        const t = this.t, cxp = x, cyp = y - this.h * 0.55, st = this.state, S = this.style.scale * LordSprite.U, age = this.phaseDur - this.stateTimer, A = alpha === undefined ? 1 : alpha, col = this.phaseColor(), col2 = this.phaseColor2();
        // trận pháp / cột sáng PIXEL dưới chân khi niệm phép
        if (!this.dead) {
            const circ = (w, a) => PXFX.drawCircle(ctx, x, y + 6, w, t, col, col2, clamp(a, 0, 1), t * 1.4, 0.36);
            if (st === 'phase') { const p = clamp(age / 1.8, 0, 1); circ(560 * (0.45 + 0.55 * p), A * Math.sin(Math.PI * p)); PXFX.drawPillar(ctx, x, y + 6, 190, 760, t, col, col2, A * Math.sin(Math.PI * clamp(p * 1.2, 0, 1))); }
            else if (st === 'summon' || st === 'orbs' || st === 'rain' || st === 'pillars' || st === 'barrage') { const p = clamp(age / this.phaseDur, 0, 1); circ(st === 'summon' ? 420 : (st === 'rain' || st === 'pillars') ? 520 : 340, A * Math.min(1, p * 4) * (1 - p * 0.5)); }
            else if (st === 'beam' && age < 1.0) circ(320, A * Math.min(1, age * 2));
            else if (st === 'windup' && this.atkName === 'rush') circ(360 * (0.5 + 0.5 * clamp(age / this.phaseDur, 0, 1)), A * 0.9);
        }
        // quả cầu meme xoay quanh boss (đầu meme pixel hoá)
        for (const o of this.orbs) {
            if (!o.alive) continue;
            const ox = cxp + Math.cos(o.a) * 120, oy = cyp + Math.sin(o.a) * 36 - 20, big = Math.sin(o.a) > 0;
            ctx.save(); ctx.globalAlpha = (alpha || 1) * (big ? 1 : 0.7); PXFX.drawOrb(ctx, ox, oy, 24, Heads.get(o.key), t + o.a, '#1b1240', col); ctx.restore();
        }
        const spr = this._sprite();
        if (this.phase === 3 && !this.dead) {     // glitch: bóng đỏ / xanh lệch pha
            const j = Math.sin(t * 30) * 6;
            ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.28;
            Rig.render(ctx, this.style, POSE0, { x: x + j, y, facing: dir, t, aura: null, spr });
            Rig.render(ctx, this.style, POSE0, { x: x - j, y: y + 2, facing: dir, t, aura: null, spr });
            ctx.restore();
        }
        if (this.atkName === 'rush' && st === 'active') {      // hậu ảnh khi lao
            for (let i = 1; i <= 4; i++) { ctx.save(); ctx.globalAlpha = 0.34 / i * A; ctx.globalCompositeOperation = 'lighter'; Rig.render(ctx, this.style, POSE0, { x: x - dir * i * 62, y, facing: dir, t, aura: null, spr }); ctx.restore(); }
        }
        Rig.draw(ctx, this.style, POSE0, { x, y, facing: dir, t, flash, alpha, aura: this.auraColor(), spr });
        // vệt chém khi đấm
        if (st === 'active' && this.atk && this.atkName !== 'slam' && this.atkName !== 'rush') {
            const p = clamp(1 - this.stateTimer / this.phaseDur, 0, 1);
            LordSprite.fx(ctx, 'fx_slash', x + dir * (this.atkName === 'swipe' ? 95 : 118), y - 92, S * (0.9 + p * 0.35), A * (1 - p) * 0.95, dir < 0);
        }
        // bụi nổ khi đập đất
        if (this.landFx > 0) { const p = 1 - this.landFx / 0.6; LordSprite.fx(ctx, 'fx_burst', x, y + 8, S * (1.0 + p * 0.7), A * (1 - p), false); }
        // laser pixel: đường ngắm (nhấp nháy) rồi tia, mỗi loạt một độ cao
        if (st === 'beam') {
            const e = age, len = 900, pal = this.phase >= 3 ? ['#ffffff', '#fecaca', '#ef4444', '#7f1d1d'] : null;
            for (const sh of this.beamShots) {
                const by = y - sh[2] + 24;
                if (e >= sh[0] - 0.55 && e < sh[0]) PXFX.drawBeamAim(ctx, x + dir * 30, by, len, dir, t, '#ff4d4d');
                else if (e >= sh[0] && e < sh[1]) {
                    PXFX.drawBeam(ctx, x + dir * 30, by, len, dir, t, 46 + Math.sin(e * 50) * 6, pal);
                    LordSprite.fx(ctx, 'fx_beam', x + dir * 112, by, S * 0.55 * (0.95 + Math.sin(e * 40) * 0.05), A, dir < 0);
                }
            }
        }
    }
    drawBars() { /* thanh máu boss hiển thị trên HUD */ }
    drawStatus(ctx, cam, x, y) { if (this.state === 'windup' && this.atk && this.atk.tell) super.drawStatus(ctx, cam, x, y - 70); }
}

// ============================================================
// ENEMY MANAGER
// ============================================================
class EnemyManager {
    constructor() { this.enemies = []; this.projectiles = []; this.difficulty = 'normal'; this.floorLevel = 1; }
    clear() { this.enemies = []; this.projectiles = []; }
    setProgression(floor, difficulty = this.difficulty) { this.floorLevel = Math.max(1, Math.floor(floor)); this.difficulty = DIFFICULTIES[difficulty] ? difficulty : 'normal'; }
    spawnEnemy(type, x, y) {
        const map = { wojak: WojakNPC, doge: DogeEnemy, troll: TrollEnemy, chad: ChadEnemy, dancer: DancerEnemy, sigma: SigmaEnemy, boss: MemeLord };
        const C = map[type] || WojakNPC;
        const e = new C(x, y);
        const cfg = DIFFICULTIES[this.difficulty] || DIFFICULTIES.normal;
        e.hp = e.maxHp = Math.max(1, Math.round(e.maxHp * cfg.hp));
        e.damage = Math.max(1, Math.round(e.damage * cfg.damage));
        e.speed *= cfg.speed;
        if (e.attacks) Object.values(e.attacks).forEach(a => { if (a && Number.isFinite(a.dmg)) a.dmg = Math.max(1, Math.round(a.dmg * cfg.damage)); });
        e.floorLevel = this.floorLevel; e.difficulty = this.difficulty;
        e.floorSkillCooldown = rand(3.2, 5.2) * cfg.cooldown;
        this.enemies.push(e); return e;
    }
    getMinionCount() { return this.enemies.filter(e => !e.isBoss && !e.dead).length; }
    getAliveCount() { return this.enemies.filter(e => !e.dead).length; }
    getBoss() { return this.enemies.find(e => e.isBoss && !e.dead) || null; }
    update(dt, player, groundY, mapWidth, particles, floatText, audio, world) {
        for (let i = this.enemies.length - 1; i >= 0; i--) {
            const e = this.enemies[i];
            e.update(dt, player, groundY, mapWidth, particles, floatText, audio, this.projectiles, this, world);
            if (e.dead && e.stateTimer <= 0) this.enemies.splice(i, 1);
        }
        for (let i = this.projectiles.length - 1; i >= 0; i--) {
            const p = this.projectiles[i];
            p.update(dt, particles, groundY);
            if (p.dead || p.x < -150 || p.x > mapWidth + 150) this.projectiles.splice(i, 1);
        }
    }
    draw(ctx, cam, groundY) {
        const list = this.enemies.slice().sort((a, b) => (a.y + a.h) - (b.y + b.h));
        for (const e of list) e.draw(ctx, cam, groundY);
        for (const p of this.projectiles) p.draw(ctx, cam);
    }
}

// ============================================================
// COMBAT SYSTEM — hitbox / hurtbox, hit-stop, knockback, hiệu ứng trúng đòn, sóng xung kích, Block / Perfect Block
// Phân biệt: đòn thường (light) · đòn mạnh (heavy) · kỹ năng (skill / ult) · bị đỡ · bị né/phản · đánh trượt (MISS)
// ============================================================
const COMIC_WORDS = ['POW!', 'BAM!', 'WHAM!', 'BONK!', 'SMACK!', 'CRACK!'];
class CombatSystem {
    constructor() { this.waves = []; }
    clear() { this.waves.length = 0; }
    addWave(o) { this.waves.push(Object.assign({ r: 0, hit: new Set(), speed: 900, maxR: 300 }, o)); }
    update(dt, world) {
        const { player, enemyManager, particles, floatText, audio, camera, fx } = world;
        this._playerMelee(world);
        this._waves(dt, world);
        this._enemyMelee(world);
        this._projectiles(world);
    }

    // ---- đòn cận chiến của Ricardo (đòn thường / mạnh / THRUST) ----
    _playerMelee(world) {
        const { player, enemyManager, particles, floatText, audio } = world;
        const pHit = player.getHitbox(); if (!pHit) return;
        const kind = player.attackKind(), mv = player.state === 'attack' ? player.move : null;
        for (const e of enemyManager.enemies) {
            if (e.dead || player.hitTargets.has(e.id)) continue;
            if (!overlap(pHit, e.getHurtbox())) continue;
            player.hitTargets.add(e.id);
            const counter = player.counterTimer > 0;
            let dmg = player.getDamage() * (player.eternalTimer > 0 ? 1.8 : 1) * (counter ? 1.6 : 1);
            dmg = Math.round(dmg);
            const kbDir = player.facingRight ? 1 : -1;
            const info = { kind, stun: mv ? mv.stun : 0.8, launch: mv && mv.launch ? 420 : 0 };
            const res = e.takeDamage(dmg, kbDir, mv ? mv.kb : 380, particles, floatText, audio, info);
            if (res === 'hit') {
                if (counter) { player.counterTimer = 0; floatText.show(e.cx(), e.y - 44, 'COUNTER!', '#ffd45a', 22, 0.9); world.fx.star(e.cx(), e.y + e.h * 0.4, { r: 70, color: '#ffd45a' }); }
                this._onPlayerHit(world, e, dmg, kind, mv);
            } else if (res === 'parried' || res === 'dodged' || res === 'taunted') {      // bị né / đỡ / phản
                player.vx = -kbDir * 160; world.hitStop(0.05); audio.playBlock();
                world.fx.ring(e.cx(), e.y + e.h * 0.45, { r1: 44, life: 0.25, color: '#cbd5e1', w: 4 }); world.camera.shake(3, 0.12);
            }
        }
    }
    _onPlayerHit(world, e, dmg, kind, mv) {
        const { player, audio, camera, fx } = world;
        const px = e.cx(), py = e.y + e.h * 0.42;
        player.combo++; player.comboTimer = 2.4; player.totalDamageDealt += dmg;
        if ([5, 10, 15, 20].includes(player.combo)) audio.playComboUp(player.combo);
        const finisher = !!(mv && (mv.launch || player.chain.length >= 4));
        player.mp = Math.min(player.maxMp, player.mp + (mv ? mv.mp : 6));
        if (e.dead) player.killCount++;
        // hit-stop (khựng khung hình ngắn) + rung màn hình theo loại đòn
        const stop = finisher ? 0.12 : kind === 'heavy' ? 0.08 : kind === 'skill' ? 0.1 : 0.045;
        world.hitStop(stop);
        camera.shake(mv ? mv.shake : (kind === 'skill' ? 10 : 5), kind === 'light' ? 0.15 : 0.25);
        // hiệu ứng va chạm
        const col = mv ? mv.arc : '#ffe27a';
        const PF = pfx();
        if (PF) {      // hiệu ứng trúng đòn kiểu PIXEL: tia nổ ô vuông + vòng điểm ảnh + mảnh vỡ + chữ POW! pixel
            PF.punchHit(px, py, col, finisher ? 2 : kind === 'light' ? 0 : 1, player.facingRight ? 1 : -1, COMIC_WORDS[Math.floor(Math.random() * COMIC_WORDS.length)]);
        } else {
            fx.ring(px, py, { r1: kind === 'light' ? 46 : 74, life: 0.28, color: col, w: kind === 'light' ? 4 : 6 });
            fx.burst(px, py, { n: kind === 'light' ? 7 : 12, len: kind === 'light' ? 40 : 64, color: col, w: kind === 'light' ? 3 : 5 });
            if (kind !== 'light') { fx.star(px, py, { r: finisher ? 90 : 56, color: '#fff3a0' }); fx.comic(px + (Math.random() - 0.5) * 30, py - 38, COMIC_WORDS[Math.floor(Math.random() * COMIC_WORDS.length)], { color: finisher ? '#ff8a3d' : '#ffe27a', size: finisher ? 34 : 26 }); }
        }
        // âm thanh theo loại đòn
        if (finisher) audio.playBigImpact(); else if (kind === 'heavy') audio.playHeavyHit(); else if (kind === 'skill') audio.playBigImpact();
        if (e.isBoss && e.dead) world.slowMo(0.9, 0.3);
    }

    // ---- sóng xung kích (SHOCKWAVE / ETERNAL DANCE): mỗi kẻ địch chỉ trúng MỘT lần mỗi sóng ----
    _waves(dt, world) {
        const { player, enemyManager, particles, floatText, audio } = world;
        for (let i = this.waves.length - 1; i >= 0; i--) {
            const w = this.waves[i]; w.r += w.speed * dt;
            for (const e of enemyManager.enemies) {
                if (e.dead || w.hit.has(e.id)) continue;
                const dist = Math.abs(e.cx() - w.x);
                if (dist > w.r + e.w * 0.4) continue;
                if (!w.air && (e.y + e.h) < world.groundY - 60) continue;          // sóng đất: phải đứng gần mặt đất
                w.hit.add(e.id);
                const close = w.near && dist < 90;
                const dmg = Math.round((w.dmg + (close ? 16 : 0)) * (player.eternalTimer > 0 ? 1.4 : 1));
                const info = { kind: w.kind, stun: close ? w.stun * 1.3 : w.stun * 0.75, launch: w.launch || 0 };
                const res = e.takeDamage(dmg, e.cx() >= w.x ? 1 : -1, w.kb, particles, floatText, audio, info);
                if (res === 'hit') {
                    player.combo++; player.comboTimer = 2.4; player.totalDamageDealt += dmg; if (e.dead) player.killCount++;
                    world.fx.burst(e.cx(), e.y + e.h * 0.45, { n: 10, len: 56, color: w.color, w: 4 });
                    if (!w.stopped) { w.stopped = true; if (!w.final) world.hitStop(0.05); }
                    if (e.isBoss && e.dead) world.slowMo(0.9, 0.3);
                }
            }
            if (w.r >= w.maxR) this.waves.splice(i, 1);
        }
    }

    // ---- kẻ địch đánh Ricardo ----
    _enemyMelee(world) {
        const { player, enemyManager, particles, floatText, audio } = world;
        for (const e of enemyManager.enemies) {
            if (e.dead) continue;
            const hb = e.getHitbox();
            if (!hb || e.hitTargets.has('player')) continue;
            if (!overlap(hb, player.getHurtbox())) continue;
            e.hitTargets.add('player');
            const info = e.getAttackInfo();
            const kbDir = (e.atk && e.atk.spin) ? ((player.x + player.w / 2) > e.cx() ? 1 : -1) : (e.facingRight ? 1 : -1);
            const res = player.takeDamage(info.damage, kbDir, info.kb, particles, floatText, audio, { pierce: info.pierce, stun: info.stun });
            this._onPlayerHurt(world, res, e, info.shake || 7, kbDir);
        }
    }
    _projectiles(world) {
        const { player, enemyManager, particles, floatText, audio } = world;
        for (const p of enemyManager.projectiles) {
            if (p.dead || p.armT > 0) continue;
            if (!overlap(p.getHitbox(), player.getHurtbox())) continue;
            const kbDir = p.vx > 0 ? 1 : (p.vx < 0 ? -1 : (player.x > p.x ? 1 : -1));
            const res = player.takeDamage(p.damage, kbDir, p.kb, particles, floatText, audio, { pierce: p.pierce, stun: p.slip ? p.stun : 0 });
            if (res === 'none') continue;
            if (!p.pierce || res !== 'hit') p.dead = true; else p.dead = true;
            this._onPlayerHurt(world, res, null, 6, kbDir);
        }
    }
    _onPlayerHurt(world, res, enemy, shake, kbDir) {
        const { player, audio, camera, fx, floatText } = world;
        const px = player.x + player.w / 2, py = player.y + player.h * 0.45;
        if (res === 'hit') {
            camera.shake(shake, 0.28); world.hitStop(0.06);
            fx.burst(px, py, { n: 8, len: 50, color: '#ff5577', w: 4 }); fx.ring(px, py, { r1: 50, life: 0.25, color: '#ff5577', w: 4 });
        } else if (res === 'block') {
            camera.shake(3, 0.15); world.hitStop(0.04); audio.playBlock();
            const sx = px + (player.facingRight ? 44 : -44);
            fx.burst(sx, py, { n: 10, len: 46, color: '#bfdbfe', w: 3 }); fx.ring(sx, py, { r1: 40, life: 0.22, color: '#60a5fa', w: 5, sq: 1 });
        } else if (res === 'perfect') {
            camera.shake(5, 0.2); world.hitStop(0.12); audio.playPerfect();
            const sx = px + (player.facingRight ? 44 : -44);
            fx.star(sx, py, { r: 80, color: '#fff3a0' }); fx.ring(sx, py, { r1: 90, life: 0.4, color: '#ffd45a', w: 8, sq: 1 }); fx.burst(sx, py, { n: 14, len: 80, color: '#ffd45a', w: 5 });
            if (enemy) enemy.stagger(0.9, floatText);
            world.flash(0.25);
        } else if (res === 'guardbreak') {
            camera.shake(10, 0.3); world.hitStop(0.08); fx.star(px, py, { r: 70, color: '#fb923c' });
        }
    }
}

// ============================================================
// UI MANAGER (Arcade HUD, Menus, Modals)
// ============================================================
const FONT_ARCADE = '"Press Start 2P", "Courier New", monospace';
const FONT_TEXT = '"Trebuchet MS", "Segoe UI", Verdana, sans-serif';
const asciiUp = s => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').toUpperCase();
const KEY_COL = { J: '#f5c542', H: '#fb923c', K: '#60a5fa', L: '#38bdf8', U: '#c084fc', I: '#f472b6', O: '#4ade80', P: '#fb923c' };

class UIManager {
    constructor() {
        this.displayedHp = 100;
        this.displayedEnemyHp = 0;
        this.announcement = '';
        this.announcementSub = '';
        this.announcementTimer = 0;
        this.announceDur = 1.8;
        this.showControlsOverlay = false;
        this.time = 0;
        this.audio = null;
        this._crt = null;
        this.showSettings = false;
        this.settingsRow = 0;
        this.toastText = '';
        this.toastTimer = 0;
        this.engine = null; this.mouse = { x: -1, y: -1, down: false, moved: false }; this.btns = []; this.topId = null; this._hoverNow = null; this.hoverId = null;
        this.pressedId = null; this.dragBtn = null; this.selectedChar = 'ricardo'; this.dlgIdx = 0; this.dlgButtons = [];
    }
    toast(text, dur = 2.8) { this.toastText = text; this.toastTimer = dur; }
    bigBanner(text, sub, dur, color, big) { this.bannerText = text; this.bannerSub = sub || ''; this.bannerDur = dur; this.bannerT = dur; this.bannerColor = color || '#ffd45a'; this.bannerBig = !!big; }
    drawBanner(ctx) {
        if (!(this.bannerT > 0)) return;
        const age = this.bannerDur - this.bannerT, pop = age < 0.25 ? 2.0 - 1.0 * (age / 0.25) : 1, fade = this.bannerT < 0.4 ? this.bannerT / 0.4 : 1;
        ctx.save(); ctx.globalAlpha = fade;
        if (this.bannerBig) { const g = ctx.createLinearGradient(0, H / 2 - 80, 0, H / 2 + 80); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.5, 'rgba(0,0,0,0.65)'); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(0, H / 2 - 80, W, 160); }
        ctx.translate(W / 2, H * 0.36); ctx.scale(pop, pop);
        this.txt(ctx, this.bannerText, 0, 0, { size: this.bannerBig ? 40 : 46, align: 'center', stroke: '#1a0a00', sw: 12, shadow: '#000', sx: 4, sy: 5, grad: ['#ffffff', this.bannerColor, '#f59e0b'] });
        if (this.bannerSub) this.txt(ctx, this.bannerSub, 0, 40, { size: 14, align: 'center', stroke: '#000', sw: 6, color: '#fff3c4' });
        ctx.restore();
    }
    announce(text, sub = '', dur = 1.8) {
        this.announcement = text;
        this.announcementSub = sub;
        this.announcementTimer = dur;
        this.announceDur = dur;
        if (this.audio) this.audio.playAnnounce(text, sub);
    }
    update(dt) {
        this.time += dt;
        if (this.toastTimer > 0) this.toastTimer -= dt;
        if (this.announcementTimer > 0) this.announcementTimer -= dt;
        if (this.bannerT > 0) this.bannerT -= dt;
    }

    // ---------------------------------------------------------------
    // Công cụ vẽ phong cách arcade cổ điển
    // ---------------------------------------------------------------
    txt(ctx, s, x, y, o = {}) {
        const size = o.size || 16;
        const isText = o.font === 'text';
        ctx.font = `${isText ? (o.weight || 'bold') + ' ' : ''}${size}px ${isText ? FONT_TEXT : FONT_ARCADE}`;
        ctx.textAlign = o.align || 'left';
        ctx.textBaseline = 'alphabetic';
        ctx.lineJoin = 'round';
        ctx.miterLimit = 2;
        if (o.shadow) { ctx.fillStyle = o.shadow; ctx.fillText(s, x + (o.sx || 3), y + (o.sy || 3)); }
        if (o.stroke) { ctx.strokeStyle = o.stroke; ctx.lineWidth = o.sw || 4; ctx.strokeText(s, x, y); }
        if (o.grad) {
            const g = ctx.createLinearGradient(0, y - size, 0, y);
            o.grad.forEach((c, i) => g.addColorStop(i / (o.grad.length - 1), c));
            ctx.fillStyle = g;
        } else ctx.fillStyle = o.color || '#fff3c4';
        if (o.glow) { ctx.shadowColor = o.glow; ctx.shadowBlur = o.gb || 14; }
        ctx.fillText(s, x, y);
        ctx.shadowBlur = 0;
    }
    frame(ctx, x, y, w, h, o = {}) {
        const gold = o.border || ['#fff0a8', '#d9a521', '#7a4c0c'];
        ctx.fillStyle = '#000'; ctx.fillRect(x - 2, y - 2, w + 4, h + 4);
        let g = ctx.createLinearGradient(0, y, 0, y + h);
        g.addColorStop(0, gold[0]); g.addColorStop(0.5, gold[1]); g.addColorStop(1, gold[2]);
        ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
        ctx.fillStyle = '#000'; ctx.fillRect(x + 3, y + 3, w - 6, h - 6);
        const f = ctx.createLinearGradient(0, y + 4, 0, y + h - 4);
        f.addColorStop(0, o.fillTop || '#2b2145'); f.addColorStop(1, o.fillBot || '#0c0916');
        ctx.fillStyle = f; ctx.fillRect(x + 4, y + 4, w - 8, h - 8);
        ctx.fillStyle = 'rgba(255,255,255,0.10)'; ctx.fillRect(x + 4, y + 4, w - 8, 2);
        if (!o.noStuds) {
            ctx.fillStyle = gold[0];
            [[x - 1, y - 1], [x + w - 6, y - 1], [x - 1, y + h - 6], [x + w - 6, y + h - 6]].forEach(([a, b]) => ctx.fillRect(a, b, 7, 7));
            ctx.fillStyle = gold[2];
            [[x + 1, y + 1], [x + w - 4, y + 1], [x + 1, y + h - 4], [x + w - 4, y + h - 4]].forEach(([a, b]) => ctx.fillRect(a, b, 3, 3));
        }
    }
    bar(ctx, x, y, w, h, pct, trail, o = {}) {
        const dir = o.dir || 1;
        ctx.fillStyle = '#000'; ctx.fillRect(x - 4, y - 4, w + 8, h + 8);
        ctx.fillStyle = o.rim || '#d9a521'; ctx.fillRect(x - 3, y - 3, w + 6, h + 6);
        ctx.fillStyle = '#000'; ctx.fillRect(x - 1, y - 1, w + 2, h + 2);
        ctx.fillStyle = '#1b1226'; ctx.fillRect(x, y, w, h);
        const seg = (p) => { const ww = Math.round(clamp(p, 0, 1) * w); return [dir > 0 ? x : x + w - ww, ww]; };
        let [tx, tw] = seg(trail);
        ctx.fillStyle = '#d1122b'; ctx.fillRect(tx, y, tw, h);
        const [fx, fw] = seg(pct);
        const c = o.colors || ['#fff59d', '#f5b400', '#b45309'];
        const g = ctx.createLinearGradient(0, y, 0, y + h);
        g.addColorStop(0, c[0]); g.addColorStop(0.45, c[1]); g.addColorStop(1, c[2]);
        ctx.fillStyle = g; ctx.fillRect(fx, y, fw, h);
        ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(fx, y + 1, fw, Math.max(1, Math.round(h * 0.18)));
        const n = o.ticks || 10;
        ctx.fillStyle = 'rgba(0,0,0,0.45)';
        for (let i = 1; i < n; i++) ctx.fillRect(x + Math.round(w * i / n) - 1, y, 2, h);
    }
    keycap(ctx, x, y, s, letter, color) {
        letter = KEY_DISPLAY[letter] || letter;
        ctx.fillStyle = '#000'; ctx.fillRect(x - 1, y - 1, s + 2, s + 2);
        const g = ctx.createLinearGradient(0, y, 0, y + s);
        g.addColorStop(0, '#ffffff'); g.addColorStop(0.15, color); g.addColorStop(1, '#00000088');
        ctx.fillStyle = color; ctx.fillRect(x, y, s, s);
        ctx.fillStyle = g; ctx.globalAlpha = 0.55; ctx.fillRect(x, y, s, s); ctx.globalAlpha = 1;
        ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(x, y + s - 3, s, 3);
        this.txt(ctx, letter, x + s / 2, y + s * 0.72, { size: Math.round(s * 0.5), align: 'center', color: '#1a1020' });
    }
    portrait(ctx, x, y, s, color, drawFn) {
        this.frame(ctx, x, y, s, s, { noStuds: true, border: color });
        ctx.save();
        ctx.beginPath(); ctx.rect(x + 5, y + 5, s - 10, s - 10); ctx.clip();
        const g = ctx.createLinearGradient(0, y, 0, y + s);
        g.addColorStop(0, '#3a2d63'); g.addColorStop(1, '#120d22');
        ctx.fillStyle = g; ctx.fillRect(x + 5, y + 5, s - 10, s - 10);
        drawFn(x + 5, y + 5, s - 10, s - 10);
        ctx.restore();
    }

    // ---------------------------------------------------------------
    // HUD trong trận
    // ---------------------------------------------------------------
    drawHUD(ctx, player, enemyManager, zone, timer, round, mode, modes) {
        ctx.save();
        // Dải tối mờ phía trên cho dễ đọc
        const top = ctx.createLinearGradient(0, 0, 0, 110);
        top.addColorStop(0, 'rgba(0,0,0,0.65)'); top.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = top; ctx.fillRect(0, 0, W, 110);

        // ---- Người chơi (trái) ----
        this.displayedHp = lerp(this.displayedHp, player.hp, 0.12);
        this.portrait(ctx, 16, 14, 80, ['#fff0a8', '#d9a521', '#7a4c0c'], (px, py, pw, ph) => {
            portraitOf(ctx, 'ricardo', px, py, pw, ph);
        });
        this.txt(ctx, 'RICARDO MILOS', 112, 34, { size: 15, stroke: '#000', sw: 5, grad: ['#fffbe0', '#ffd45a'] });
        const hpPct = player.hp / player.maxHp;
        const low = hpPct < 0.25 && Math.floor(this.time * 6) % 2 === 0;
        this.bar(ctx, 112, 44, 420, 24, hpPct, this.displayedHp / player.maxHp, {
            colors: low ? ['#ffb3b3', '#ef4444', '#7f1d1d'] : ['#fff59d', '#f5b400', '#b45309']
        });
        this.txt(ctx, `${Math.ceil(player.hp)}`, 524, 62, { size: 12, align: 'right', stroke: '#000', sw: 4, color: '#fff' });
        // Thanh năng lượng
        this.txt(ctx, 'POW', 112, 90, { size: 9, stroke: '#000', sw: 4, color: '#9ad7ff' });
        const full = player.mp >= player.maxMp;
        this.bar(ctx, 160, 78, 260, 11, player.mp / player.maxMp, player.mp / player.maxMp, {
            colors: full ? ['#ffffff', '#ffd45a', '#f97316'] : ['#bfe8ff', '#38a8f0', '#1b4fa8'], ticks: 4, rim: full ? '#ffd45a' : '#6b7a99'
        });
        if (full) {
            const on = Math.floor(this.time * 5) % 2 === 0;
            this.txt(ctx, 'MAX! [F]', 432, 88, { size: 9, stroke: '#000', sw: 4, color: on ? '#ffd45a' : '#ffffff' });
        }

        // ---- Trung tâm: đồng hồ / màn chơi ----
        this.frame(ctx, W / 2 - 62, 12, 124, 70, { fillTop: '#3b1d2a', fillBot: '#12060c' });
        if (mode === 'arcade') {
            this.txt(ctx, `ROUND ${round}`, W / 2, 30, { size: 9, align: 'center', stroke: '#000', sw: 4, color: '#ffd45a' });
            this.txt(ctx, String(Math.max(0, Math.ceil(timer))).padStart(2, '0'), W / 2, 68, {
                size: 34, align: 'center', stroke: '#000', sw: 6,
                grad: timer < 10 ? ['#ffffff', '#ff6b6b'] : ['#ffffff', '#ffd45a']
            });
        } else {
            let l1 = 'STAGE', l2 = '', l3 = '';
            if (mode === 'story' && modes) { l2 = String(modes.currentZoneIndex + 1); l3 = modes.currentZoneIndex === 3 ? 'BOSS' : `WAVE ${modes.currentWave}/${modes.maxWaves}`; }
            else if (mode === 'survival' && modes) { l1 = 'SURVIVAL'; l2 = String(modes.survivalWave); l3 = 'WAVE'; }
            this.txt(ctx, l1, W / 2, 30, { size: 9, align: 'center', stroke: '#000', sw: 4, color: '#ffd45a' });
            this.txt(ctx, l2, W / 2, 62, { size: 28, align: 'center', stroke: '#000', sw: 6, grad: ['#ffffff', '#ffd45a'] });
            this.txt(ctx, l3, W / 2, 77, { size: 8, align: 'center', color: '#fff3c4' });
        }
        this.txt(ctx, `${asciiUp(zone.name)}  ·  ${(DIFFICULTIES[modes && modes.difficulty] || DIFFICULTIES.normal).label}  ·  FLOOR ${modes && modes.currentFloor || 1}`, W / 2, 104, { size: 8, align: 'center', stroke: '#000', sw: 4, color: '#c9b6ff' });
        if (mode === 'story' && modes) this.txt(ctx, `${STORY.chapters[modes.currentZoneIndex].num} · ${STORY.chapters[modes.currentZoneIndex].name}`, W / 2, 120, { size: 7, align: 'center', stroke: '#000', sw: 3, color: '#ffd45a' });
        if (player.eternalTimer > 0) {
            const pu = 0.75 + 0.25 * Math.sin(this.time * 8);
            this.frame(ctx, W / 2 - 170, 132, 340, 40, { fillTop: '#5a3a10', fillBot: '#1a0f05' });
            this.txt(ctx, 'THE ETERNAL DANCE', W / 2, 156, { size: 14, align: 'center', stroke: '#000', sw: 5, grad: ['#ffffff', pu > 0.9 ? '#ffd45a' : '#ff9ad5'] });
            ctx.fillStyle = '#ffd45a'; ctx.fillRect(W / 2 - 160, 164, 320 * (player.eternalTimer / 20), 3);
        }

        // ---- Kẻ địch (phải) ----
        const boss = enemyManager.getBoss();
        let topEnemy = boss;
        if (!topEnemy) {
            let best = 1e9;
            for (const e of enemyManager.enemies) {
                if (e.dead) continue;
                const d = Math.abs(e.x - player.x);
                if (d < best) { best = d; topEnemy = e; }
            }
        }
        if (topEnemy) {
            this.displayedEnemyHp = lerp(this.displayedEnemyHp, topEnemy.hp, 0.12);
            const bc = boss ? ['#fff0a8', '#d1122b', '#7a4c0c'] : ['#fff0a8', '#d9a521', '#7a4c0c'];
            this.portrait(ctx, W - 96, 14, 80, bc, (px, py, pw, ph) => {
                portraitOf(ctx, topEnemy.type, px, py, pw, ph);
            });
            const nm = boss ? `${asciiUp(topEnemy.displayName)}  P${boss.phase}` : asciiUp(topEnemy.displayName);
            this.txt(ctx, nm, W - 112, 34, { size: 15, align: 'right', stroke: '#000', sw: 5, grad: boss ? ['#ffffff', '#ff8a8a'] : ['#fffbe0', '#ffd45a'] });
            this.bar(ctx, W - 112 - 420, 44, 420, 24, topEnemy.hp / topEnemy.maxHp, this.displayedEnemyHp / topEnemy.maxHp, {
                dir: -1, colors: boss ? ['#ffc2c2', '#ef4444', '#7f1d1d'] : ['#ffd1f0', '#ec4899', '#831843']
            });
            if (boss) {
                ctx.fillStyle = '#ffd45a';
                [0.33, 0.66].forEach(pct => ctx.fillRect(W - 112 - 420 * pct - 1, 40, 3, 32));
            }
            const left = enemyManager.getAliveCount();
            this.txt(ctx, `ENEMY x${left}`, W - 112, 90, { size: 9, align: 'right', stroke: '#000', sw: 4, color: '#ffb3d9' });
        }

        // ---- Chuỗi combo & số đòn trúng (trái) ----
        this._drawComboPanel(ctx, player);

        // ---- Thanh phím đòn / kỹ năng (dưới giữa) ----
        this._drawActionBar(ctx, player);

        // ---- Minimap ----
        this.drawMinimap(ctx, player, enemyManager, zone);

        // ---- Thông báo ROUND / FIGHT ----
        if (this.announcementTimer > 0) this._drawAnnouncement(ctx);
        this.drawBanner(ctx);

        // ---- Gợi ý ----
        this.txt(ctx, '[F1] HUONG DAN  [N] DOI NHAC  [M] TAT NHAC  [ESC] TAM DUNG', 20, H - 18, { size: 8, stroke: '#000', sw: 4, color: '#cbd5e1' });

        this.hudButtons(ctx);
        ctx.restore();
    }
    _drawComboPanel(ctx, player) {
        const x = 20;
        // Chuỗi phím đang thực hiện
        if (player.chain && (player.state === 'attack' || player.chainTimer > 0)) {
            const alpha = player.state === 'attack' ? 1 : clamp(player.chainTimer / CHAIN_GRACE + 0.2, 0, 1);
            ctx.save(); ctx.globalAlpha = alpha;
            this.txt(ctx, 'COMBO', x, 134, { size: 9, stroke: '#000', sw: 4, color: '#ffd45a' });
            const letters = player.chain.split('');
            letters.forEach((c, i) => {
                const kx = x + i * 40;
                this.keycap(ctx, kx, 142, 32, c, KEY_COL[c] || '#fff');
                if (i < letters.length - 1) this.txt(ctx, '>', kx + 36, 164, { size: 10, color: '#fff3c4', stroke: '#000', sw: 3 });
            });
            this.txt(ctx, player.moveName || '', x, 198, { size: 12, stroke: '#000', sw: 5, grad: ['#ffffff', '#ffd45a'] });
            ctx.restore();
        }
        // Số lần đánh trúng
        if (player.combo > 1) {
            const n = player.combo;
            const rank = n >= 15 ? 'GODLIKE!!' : n >= 10 ? 'AMAZING!' : n >= 5 ? 'GREAT!' : 'NICE!';
            const grad = n >= 10 ? ['#ffffff', '#ff5a5a'] : n >= 5 ? ['#ffffff', '#ffb347'] : ['#ffffff', '#7dd3fc'];
            const pulse = 1 + 0.06 * Math.sin(this.time * 14);
            ctx.save();
            ctx.translate(x, 262); ctx.scale(pulse, pulse);
            this.txt(ctx, String(n), 0, 0, { size: 44, stroke: '#000', sw: 8, grad, glow: '#000', gb: 0 });
            const nw = String(n).length * 44 + 10;
            this.txt(ctx, 'HITS', nw, -4, { size: 16, stroke: '#000', sw: 6, color: '#ffd45a' });
            ctx.restore();
            this.txt(ctx, rank, x, 288, { size: 12, stroke: '#000', sw: 5, grad });
            this.txt(ctx, `DAMAGE ${player.totalDamageDealt}`, x, 308, { size: 8, stroke: '#000', sw: 4, color: '#e2e8f0' });
        }
    }
    _drawAnnouncement(ctx) {
        const t = this.announcementTimer, dur = this.announceDur;
        const age = dur - t;
        const pop = age < 0.25 ? 1.7 - 0.7 * easeOut(age / 0.25) : 1;
        const fade = t < 0.35 ? t / 0.35 : 1;
        ctx.save();
        ctx.globalAlpha = fade;
        const bh = this.announcementSub ? 150 : 120, by = H / 2 - bh / 2 - 20;
        const g = ctx.createLinearGradient(0, by, 0, by + bh);
        g.addColorStop(0, 'rgba(70,6,18,0.0)'); g.addColorStop(0.2, 'rgba(70,6,18,0.85)'); g.addColorStop(0.8, 'rgba(70,6,18,0.85)'); g.addColorStop(1, 'rgba(70,6,18,0.0)');
        ctx.fillStyle = g; ctx.fillRect(0, by, W, bh);
        ctx.fillStyle = '#ffd45a'; ctx.fillRect(0, by + bh * 0.2, W, 3); ctx.fillRect(0, by + bh * 0.8 - 3, W, 3);
        ctx.translate(W / 2, by + bh / 2 + (this.announcementSub ? -6 : 14));
        ctx.scale(pop, pop);
        this.txt(ctx, asciiUp(this.announcement), 0, 0, { size: 50, align: 'center', stroke: '#2a0000', sw: 12, shadow: '#7a1020', sx: 5, sy: 6, grad: ['#ffffff', '#ffe27a', '#f59e0b'] });
        ctx.restore();
        if (this.announcementSub) {
            ctx.save(); ctx.globalAlpha = fade;
            this.txt(ctx, this.announcementSub, W / 2, by + bh * 0.8 - 14, { font: 'text', size: 20, align: 'center', stroke: '#000', sw: 5, color: '#fff3c4' });
            ctx.restore();
        }
    }
    drawMinimap(ctx, player, enemyManager, zone) {
        const mw = 200, mh = 46, mx = W - mw - 24, my = H - mh - 24;
        this.frame(ctx, mx, my, mw, mh, { noStuds: true });
        const lx = mx + 12, lw = mw - 24, ly = my + mh - 14;
        ctx.fillStyle = '#4b5563'; ctx.fillRect(lx, ly, lw, 2);
        this.txt(ctx, 'RADAR', mx + 10, my + 17, { size: 7, color: '#9ca3af' });
        for (const e of enemyManager.enemies) {
            if (e.dead) continue;
            const ex = lx + clamp(e.x / zone.width, 0, 1) * lw;
            ctx.fillStyle = e.isBoss ? '#ef4444' : '#ec4899';
            const r = e.isBoss ? 6 : 4;
            ctx.fillRect(ex - r / 2, ly - r + 1, r, r);
        }
        const px = lx + clamp(player.x / zone.width, 0, 1) * lw;
        ctx.fillStyle = '#ffd45a'; ctx.fillRect(px - 3, ly - 6, 7, 7);
        ctx.fillStyle = '#000'; ctx.fillRect(px - 1, ly - 4, 3, 3);
    }

    // ---------------------------------------------------------------
    // Bảng hướng dẫn: điều khiển + danh sách combo
    // ---------------------------------------------------------------
    drawToast(ctx) {
        if (this.toastTimer <= 0 || !this.toastText) return;
        const a = clamp(this.toastTimer / 0.4, 0, 1);
        let txt = this.toastText; if (txt.length > 52) txt = txt.slice(0, 49) + '...';
        ctx.save(); ctx.globalAlpha = a;
        const ty = (this.showSettings || !this.engine || !['story', 'arcade', 'survival'].includes(this.engine.modes.mode)) ? 8 : H - 150;     // trong màn cài đặt thì nằm phía trên khung
        this.frame(ctx, W / 2 - 280, ty, 560, 38, { noStuds: true, fillTop: '#2a1f45', fillBot: '#0c0916' });
        this.txt(ctx, txt, W / 2, ty + 25, { font: 'text', size: 16, align: 'center', color: '#fff3c4', stroke: '#000', sw: 3 });
        ctx.restore();
    }
    drawCRT(ctx) {
        if (!this._crt) {
            const c = document.createElement('canvas');
            c.width = W; c.height = H;
            const x = c.getContext('2d');
            x.fillStyle = 'rgba(0,0,0,0.13)';
            for (let y = 0; y < H; y += 3) x.fillRect(0, y, W, 1);
            const v = x.createRadialGradient(W / 2, H / 2, H * 0.45, W / 2, H / 2, W * 0.75);
            v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.55)');
            x.fillStyle = v; x.fillRect(0, 0, W, H);
            this._crt = c;
        }
        ctx.drawImage(this._crt, 0, 0);
    }
}

// ============================================================
// UI MỚI — hệ thống nút bấm (chuột + bàn phím), chọn nhân vật, HUD kỹ năng, cài đặt, pause, game over
// ============================================================
const CHAR_INFO = {
    ricardo: { name: 'RICARDO MILOS', role: 'Huyền thoại Meme Dance — NHÂN VẬT CHƠI', playable: true, hp: 4, atk: 4, spd: 4,
        desc: 'Đấu sĩ cơ bắp mang khăn bandana đỏ, sống bằng Meme Energy: càng đánh trúng càng nạp năng lượng.',
        skills: [['Z · X · C', 'Đấm nhẹ · đấm mạnh · đá. Nối tiếp phím để tung combo tối đa 4 đòn.'],
                 ['K / ↓ (giữ)', 'ĐỠ ĐÒN, giảm 80% sát thương. Đỡ đúng lúc = PERFECT BLOCK và cơ hội phản công.'],
                 ['↑ + ↑', 'Nhảy đôi: nhấn nhảy lần 2 khi đang ở trên không.'],
                 ['A', 'DACNE — nhảy meme tại chỗ để hồi máu (vẫn có thể bị đánh).'],
                 ['S', 'THRUST — lao tới xuyên qua kẻ địch, gây sát thương và choáng.'],
                 ['D', 'CHƯỞNG — nạp khí rồi bắn tia năng lượng xuyên thẳng, gây sát thương liên tục và choáng.'],
                 ['F', 'ETERNAL DANCE — ultimate điện ảnh, cần đủ 100 MP.']] },
    troll: { name: 'TROLLFACE', role: 'Kẻ đánh lừa & phản đòn', hp: 3, atk: 3, spd: 4,
        desc: 'Cái đầu cười toe toét che giấu những chiêu lừa. Đừng đánh hắn khi hắn đang cười!',
        skills: [['LOL', 'Chế giễu: né sạch đòn rồi PHẢN CÔNG mạnh. Hãy đợi hắn ngừng cười.'], ['Dịch chuyển', 'Biến mất, xuất hiện sau lưng bạn rồi đá.'], ['Vỏ chuối', 'Ném bẫy làm bạn trượt ngã và choáng.']] },
    chad: { name: 'GIGACHAD', role: 'Đấu sĩ cận chiến — sát thương & phòng thủ cao', hp: 5, atk: 5, spd: 1,
        desc: 'Cơ bắp tuyệt đối. Chậm nhưng mỗi cú đấm đều có thể đổi cả trận đấu.',
        skills: [['Giáp cơ', 'Đòn nhẹ bị giảm 50% sát thương; đánh từ phía sau hiệu quả hơn.'], ['Gồng cơ', 'Giảm 80% sát thương, không bị choáng — rồi giáng cú đấm.'], ['Đấm giáng', 'Đòn nặng, hất bay xa. Có thể đỡ nếu đúng lúc.'], ['Dậm đất', 'Tạo sóng đất 2 bên — hãy nhảy qua.']] },
    doge: { name: 'DOGE', role: 'Nhanh nhẹn & có khả năng NÉ ĐÒN', hp: 2, atk: 2, spd: 5,
        desc: 'Swole Doge: nhỏ gọn, lướt như gió. Đánh lúc hắn chuẩn bị né sẽ trượt.',
        skills: [['Né đòn', 'Thấy bạn ra đòn thì lùi nhanh và phản công bằng cú cào.'], ['Cào liên hoàn', 'Hai đòn cào liên tiếp.'], ['Zoomies', 'Lao thẳng qua người bạn với tốc độ cao.']] },
    wojak: { name: 'NPC WOJAK', role: 'Kiểu tấn công khó đoán', hp: 2, atk: 2, spd: 3,
        desc: 'Đôi khi đứng đờ ra như bị lag, rồi bất ngờ ra đòn — hoặc chỉ giả vờ.',
        skills: [['Tát · Dậm', 'Đòn tầm gần, thời điểm ra đòn ngẫu nhiên.'], ['COPE', 'Ném bong bóng chữ (COPE / SEETHE / DILATE...).'], ['SEETHE', 'Lao thẳng vào bạn.'], ['Giả vờ', 'Làm động tác đánh nhưng hủy giữa chừng.']] },
    dancer: { name: 'DANCING MEME', role: 'Vũ công Disco — đánh theo nhịp 128 BPM', hp: 3, atk: 4, spd: 3,
        desc: 'Mỗi bước nhảy đều theo beat. Vòng sáng dưới chân đổi màu theo từng phách — đọc nhịp là đọc được đòn. Dưới 40% máu hắn bước vào DISCO FEVER.',
        skills: [['Moonwalk Groove', 'Bước / lùi đúng từng phách (128 BPM). Phách 3 là ra đòn.'], ['Fever Spin', 'Nhảy xoay 360°, tiếp đất tạo 2 sóng sáng sát đất — nhảy qua.'], ['Note Barrage', 'Bắn nốt nhạc lượn sóng (5 nốt khi Fever). Hãy lách theo nhịp.'], ['Spotlight Drop', 'Đèn khoá vị trí bạn: vòng sáng thu nhỏ rồi cột sáng giáng xuống.'], ['Disco Fever', 'Dưới 40% máu: nhanh hơn, 5 nốt nhạc, thêm 2 cột đèn.']] },
    sigma: { name: 'SIGMA MEME', role: 'Tinh nhuệ có khả năng PHẢN CÔNG', hp: 3, atk: 4, spd: 4,
        desc: 'Lạnh lùng, kỷ luật. Khi khoanh tay thủ thế, đòn thường của bạn sẽ bị bắt lại.',
        skills: [['Guard', 'Khoanh tay: bắt đòn thường rồi phản công. Đòn MẠNH (H) và kỹ năng phá được thế thủ.'], ['Chém liên hoàn', 'Hai nhát chém nhanh.'], ['Dash slash', 'Lao tới chém từ xa.'], ['Grindset', 'Dưới 40% máu: nhanh hơn, hung hãn hơn.']] },
    lord: { name: 'ULTIMATE MEME LORD', role: 'Boss cuối — 3 giai đoạn', hp: 5, atk: 5, spd: 2,
        desc: 'Kẻ thống trị Memeverse. Càng bị đánh yếu đi, hắn càng điên cuồng.',
        skills: [['Giai đoạn 1', 'Niệm phép bắn quả cầu meme (Doge / Chad / Troll) + đấm vệt chém.'], ['Giai đoạn 2', 'Nhảy đập đất tạo sóng xuyên giáp, mở trận pháp triệu hồi quân meme.'], ['Giai đoạn 3 — OVERDRIVE', 'Spam kỹ năng: mưa thiên thạch Troll, 4 đợt cột lửa, đạn toả quạt, lao xuyên màn, laser 3 loạt (có loạt thấp phải nhảy), dịch chuyển, đập đất 4 sóng. Dưới 12% máu nổi điên.']] }
};
const CHAR_ORDER = ['ricardo', 'troll', 'chad', 'doge', 'wojak', 'dancer', 'sigma', 'lord'];
const CHAR_RIG = { ricardo: 'ricardo', troll: 'troll', chad: 'chad', wojak: 'wojak', dancer: 'dancer', sigma: 'sigma', lord: 'lord' };

function portraitOf(ctx, id, x, y, w, h) {
    const key = { ricardo: 'ricardo', troll: 'troll', chad: 'chad', doge: 'doge_full', wojak: 'npc', dancer: 'disco', sigma: 'sigma', boss: 'lord', lord: 'lord' }[id] || id;
    const img = Heads.get(key);
    if (!img) { ctx.fillStyle = '#334'; ctx.fillRect(x, y, w, h); return; }
    let sx = 0, sy = 0, sw = img.naturalWidth, sh = img.naturalHeight;
    if (key === 'doge_full') { sx = 112; sy = 0; sw = 96; sh = 98; }
    const ar = sw / sh; let dh = h * 0.95, dw = dh * ar;
    if (dw > w * 0.98) { dw = w * 0.98; dh = dw / ar; }
    ctx.drawImage(img, sx, sy, sw, sh, x + (w - dw) / 2, y + (h - dh) / 2 + 2, dw, dh);
    if (id === 'boss' || id === 'lord') {
        const cx = x + w / 2, cy = y + (h - dh) / 2 + 2;
        ctx.fillStyle = '#ffd45a'; ctx.strokeStyle = '#2a1a05'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(cx - 16, cy + 6); ctx.lineTo(cx - 20, cy - 10); ctx.lineTo(cx - 8, cy - 2); ctx.lineTo(cx, cy - 14); ctx.lineTo(cx + 8, cy - 2); ctx.lineTo(cx + 20, cy - 10); ctx.lineTo(cx + 16, cy + 6); ctx.closePath(); ctx.fill(); ctx.stroke();
    }
}
function drawIcon(ctx, kind, cx, cy, s, color) {
    ctx.save(); ctx.translate(cx, cy); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.fillStyle = color; ctx.strokeStyle = '#0a0612'; ctx.lineWidth = 3;
    const k = s / 20;
    if (kind === 'heart') {
        ctx.beginPath(); ctx.moveTo(0, 8 * k); ctx.bezierCurveTo(-18 * k, -4 * k, -9 * k, -16 * k, 0, -7 * k); ctx.bezierCurveTo(9 * k, -16 * k, 18 * k, -4 * k, 0, 8 * k); ctx.closePath(); ctx.stroke(); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.font = `bold ${12 * k}px Arial`; ctx.textAlign = 'center'; ctx.fillText('\u266A', 0, 4 * k);
    } else if (kind === 'dash') {
        ctx.beginPath(); ctx.moveTo(-14 * k, -5 * k); ctx.lineTo(4 * k, -5 * k); ctx.lineTo(4 * k, -12 * k); ctx.lineTo(16 * k, 0); ctx.lineTo(4 * k, 12 * k); ctx.lineTo(4 * k, 5 * k); ctx.lineTo(-14 * k, 5 * k); ctx.closePath(); ctx.stroke(); ctx.fill();
        ctx.strokeStyle = color; ctx.lineWidth = 2.5; for (const y of [-9, 0, 9]) { ctx.beginPath(); ctx.moveTo(-20 * k, y * k); ctx.lineTo(-15 * k, y * k); ctx.stroke(); }
    } else if (kind === 'wave') {
        ctx.fillStyle = 'rgba(0,0,0,0)'; ctx.strokeStyle = color; ctx.lineWidth = 3.2;
        for (const r of [6, 12, 18]) { ctx.beginPath(); ctx.ellipse(0, 7 * k, r * k, r * k * 0.4, 0, 0, 6.283); ctx.stroke(); }
        ctx.fillStyle = '#fff3a0'; ctx.beginPath(); for (let i = 0; i < 10; i++) { const r = i % 2 ? 3 * k : 8 * k, a = i * Math.PI / 5 - Math.PI / 2; ctx.lineTo(Math.cos(a) * r, -6 * k + Math.sin(a) * r); } ctx.closePath(); ctx.fill();
    } else if (kind === 'star') {
        ctx.shadowColor = color; ctx.shadowBlur = 10;
        ctx.beginPath(); for (let i = 0; i < 10; i++) { const r = i % 2 ? 7 * k : 17 * k, a = i * Math.PI / 5 - Math.PI / 2; ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); } ctx.closePath(); ctx.stroke(); ctx.fill();
    } else if (kind === 'shield') {
        ctx.beginPath(); ctx.moveTo(0, -15 * k); ctx.lineTo(13 * k, -9 * k); ctx.lineTo(11 * k, 6 * k); ctx.quadraticCurveTo(7 * k, 13 * k, 0, 16 * k); ctx.quadraticCurveTo(-7 * k, 13 * k, -11 * k, 6 * k); ctx.lineTo(-13 * k, -9 * k); ctx.closePath(); ctx.stroke(); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(0, -10 * k); ctx.lineTo(0, 10 * k); ctx.stroke();
    } else if (kind === 'target') {
        ctx.strokeStyle = color; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, 14 * k, 0, 6.283); ctx.moveTo(-19 * k, 0); ctx.lineTo(-8 * k, 0); ctx.moveTo(8 * k, 0); ctx.lineTo(19 * k, 0); ctx.moveTo(0, -19 * k); ctx.lineTo(0, -8 * k); ctx.moveTo(0, 8 * k); ctx.lineTo(0, 19 * k); ctx.stroke();
    } else if (kind === 'sword') {
        ctx.beginPath(); ctx.moveTo(-2 * k, 13 * k); ctx.lineTo(2 * k, 9 * k); ctx.lineTo(-7 * k, -3 * k); ctx.lineTo(0, -16 * k); ctx.lineTo(7 * k, -3 * k); ctx.lineTo(-2 * k, 9 * k); ctx.closePath(); ctx.stroke(); ctx.fill(); ctx.beginPath(); ctx.moveTo(-8 * k, 5 * k); ctx.lineTo(8 * k, -3 * k); ctx.stroke();
    } else if (kind === 'jump') {
        ctx.beginPath(); ctx.moveTo(-12 * k, 2 * k); ctx.lineTo(0, -10 * k); ctx.lineTo(12 * k, 2 * k); ctx.lineTo(8 * k, 6 * k); ctx.lineTo(0, -2 * k); ctx.lineTo(-8 * k, 6 * k); ctx.closePath(); ctx.stroke(); ctx.fill();
        ctx.beginPath(); ctx.moveTo(-12 * k, 12 * k); ctx.lineTo(0, 1 * k); ctx.lineTo(12 * k, 12 * k); ctx.lineTo(8 * k, 15 * k); ctx.lineTo(0, 8 * k); ctx.lineTo(-8 * k, 15 * k); ctx.closePath(); ctx.stroke(); ctx.fill();
    }
    ctx.restore();
}

Object.assign(UIManager.prototype, {
    // ---------------------------------------------------------------
    // HỆ THỐNG NÚT BẤM — mỗi khung hình vẽ lại và đăng ký vùng click; chuột / bàn phím đều dùng được
    // ---------------------------------------------------------------
    beginFrame() {
        const m = this.mouse; let top = null;
        for (let i = this.btns.length - 1; i >= 0; i--) { const b = this.btns[i]; if (m.x >= b.x && m.x <= b.x + b.w && m.y >= b.y && m.y <= b.y + b.h) { top = b; break; } }
        this.topId = top ? top.id : null; this.btns = []; this._hoverNow = null;
    },
    button(ctx, id, x, y, w, h, label, o = {}) {
        const en = o.enabled !== false, m = this.mouse;
        const hover = en && this.topId === id && m.x >= x && m.x <= x + w && m.y >= y && m.y <= y + h;
        const active = hover && m.down && this.pressedId === id;
        const sel = !!o.selected;
        if (hover) this._hoverNow = id;
        this.btns.push({ id, x, y, w, h, enabled: en, onClick: o.onClick, onClickAt: o.onClickAt, tip: o.tip });
        const dy = active ? 2 : 0;
        let top = '#2b2145', bot = '#120c26', border = ['#c9b6ff', '#6d5bd0', '#2f2a66'];
        if (!en) { top = '#34343c'; bot = '#1b1b21'; border = ['#8b8b99', '#52525e', '#2a2a33']; }
        else if (o.danger) { top = hover ? '#a32020' : '#7f1d1d'; bot = '#2a0707'; border = ['#fca5a5', '#dc2626', '#7f1d1d']; }
        else if (hover || sel) { top = active ? '#3b2870' : '#5a3c9a'; bot = '#241450'; border = ['#fff0a8', '#d9a521', '#7a4c0c']; }
        this.frame(ctx, x, y + dy, w, h, { noStuds: true, border, fillTop: top, fillBot: bot });
        if (hover && !active) { ctx.fillStyle = 'rgba(255,255,255,0.08)'; ctx.fillRect(x + 4, y + 4, w - 8, h - 8); }
        const col = !en ? '#76767f' : (hover || sel ? '#ffffff' : '#fff3c4');
        if (label) this.txt(ctx, label, x + w / 2, y + dy + h / 2 + (o.size || 18) * 0.36, { font: 'text', size: o.size || 18, align: 'center', color: col, stroke: '#000', sw: 4 });
        return hover;
    },
    slider(ctx, id, x, y, w, h, value, onSet, sel) {
        const m = this.mouse, hover = this.topId === id;
        if (hover) this._hoverNow = id;
        this.btns.push({ id, x: x - 6, y: y - 8, w: w + 12, h: h + 16, enabled: true, onClickAt: (mx) => onSet(clamp((mx - x) / w, 0, 1)), drag: true });
        this.bar(ctx, x, y, w, h, value, value, { ticks: 10, colors: ['#bfe8ff', '#38a8f0', '#1b4fa8'], rim: (sel || hover) ? '#ffd45a' : '#6b7a99' });
        const kx = x + w * value;
        ctx.fillStyle = '#fff3c4'; ctx.strokeStyle = '#000'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(kx, y + h / 2, h * 0.75, 0, 6.283); ctx.fill(); ctx.stroke();
    },
    // ---------------------------------------------------------------
    // SẢNH CHỜ (Main Menu)
    // ---------------------------------------------------------------
    drawMenu(ctx, selectedIndex, options, title = 'RICARDO MILOS', subtitle = 'MEME FIGHTER') {
        const t = this.time, E = this.engine;
        const bg = ctx.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, '#1a0b3a'); bg.addColorStop(0.55, '#3a0f4a'); bg.addColorStop(1, '#09040f');
        ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
        ctx.save(); ctx.translate(W / 2, 250); ctx.rotate(t * 0.08);
        for (let i = 0; i < 18; i++) { ctx.rotate(Math.PI * 2 / 18); ctx.fillStyle = i % 2 ? 'rgba(255,212,90,0.07)' : 'rgba(255,90,160,0.05)'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(1200, -90); ctx.lineTo(1200, 90); ctx.closePath(); ctx.fill(); }
        ctx.restore();
        for (let i = 0; i < 70; i++) { const sx = (i * 197 + 31) % W, sy = (i * 89 + 17) % 330; ctx.fillStyle = `rgba(255,255,255,${0.25 + 0.5 * Math.abs(Math.sin(t * 1.5 + i))})`; ctx.fillRect(sx, sy, 2, 2); }
        const fy = 580;
        const fg = ctx.createLinearGradient(0, fy, 0, H); fg.addColorStop(0, '#2b1048'); fg.addColorStop(1, '#07030c'); ctx.fillStyle = fg; ctx.fillRect(0, fy, W, H - fy);
        ctx.strokeStyle = 'rgba(255,90,200,0.35)'; ctx.lineWidth = 1;
        for (let i = -12; i <= 12; i++) { ctx.beginPath(); ctx.moveTo(W / 2 + i * 30, fy); ctx.lineTo(W / 2 + i * 150, H); ctx.stroke(); }
        for (let i = 1; i < 6; i++) { const yy = fy + (i * i) * 4; ctx.beginPath(); ctx.moveTo(0, yy); ctx.lineTo(W, yy); ctx.stroke(); }
        ctx.fillStyle = '#ffd45a'; ctx.fillRect(0, fy, W, 3);
        // nhân vật: Ricardo nhảy bên trái, boss bên phải
        ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.beginPath(); ctx.ellipse(190, fy + 8, 90, 14, 0, 0, 6.283); ctx.fill();
        Rig.render(ctx, RIG_STYLES.ricardo, dancePose(t), { x: 190, y: fy + 6, facing: 1, scale: 2.5, t, aura: '#ffd45a', spr: RicardoSprite.dance(t) });
        ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.beginPath(); ctx.ellipse(W - 190, fy + 8, 110, 14, 0, 0, 6.283); ctx.fill();
        Rig.render(ctx, Object.assign({}, RIG_STYLES.lord), POSE0, { x: W - 190, y: fy + 6, facing: -1, scale: 1.25, t, aura: '#a855f7', spr: LordSprite.idle(t) });
        // logo
        const bob = Math.sin(t * 2) * 3;
        this.txt(ctx, asciiUp(title.split(' ')[0]), W / 2, 110 + bob, { size: 60, align: 'center', stroke: '#3b0a0a', sw: 14, shadow: '#7a1020', sx: 5, sy: 7, grad: ['#ffffff', '#ffe27a', '#f59e0b', '#c2410c'] });
        this.txt(ctx, asciiUp(title.split(' ').slice(1).join(' ')), W / 2, 176 + bob, { size: 60, align: 'center', stroke: '#3b0a0a', sw: 14, shadow: '#7a1020', sx: 5, sy: 7, grad: ['#ffffff', '#ffe27a', '#f59e0b', '#c2410c'] });
        ctx.fillStyle = '#9b1226'; ctx.fillRect(W / 2 - 220, 192, 440, 30); ctx.fillStyle = '#ffd45a'; ctx.fillRect(W / 2 - 220, 192, 440, 3); ctx.fillRect(W / 2 - 220, 219, 440, 3);
        this.txt(ctx, asciiUp(subtitle), W / 2, 214, { size: 14, align: 'center', stroke: '#000', sw: 5, color: '#fff3c4' });
        // nút menu
        const bw = 440, bh = 44, gap = 8, bx = W / 2 - bw / 2, by = 246;
        this.frame(ctx, bx - 16, by - 12, bw + 32, options.length * (bh + gap) + 8, { fillTop: '#20153a', fillBot: '#0a0612' });
        options.forEach((opt, i) => {
            const hover = this.button(ctx, 'menu' + i, bx, by + i * (bh + gap), bw, bh, opt, { selected: i === selectedIndex, onClick: () => E._menuClick(i), size: 19 });
            if (hover && this.mouse.moved && E.modes.selectedMenuIndex !== i) E.modes.selectedMenuIndex = i;
        });
        // nút nhạc nhanh
        this.button(ctx, 'menuMusic', W - 210, 16, 190, 34, (E.audio.settings.musicOn ? '\u266A NHẠC: BẬT' : '\u266A NHẠC: TẮT'), { onClick: () => E.ui.toast(E.audio.toggleMusic() ? 'Nhạc: TẮT' : 'Nhạc: BẬT', 1.6), size: 14 });
        if (Math.floor(t * 2) % 2 === 0) this.txt(ctx, 'CLICK HOẶC NHẤN ENTER', W / 2, H - 26, { font: 'text', size: 14, align: 'center', stroke: '#000', sw: 5, color: '#ffd45a' });
        this.txt(ctx, '\u2191\u2193 chọn · Enter xác nhận · F1 hướng dẫn · N đổi nhạc · M tắt nhạc', W / 2, H - 6, { font: 'text', size: 11, weight: 'normal', align: 'center', stroke: '#000', sw: 3, color: '#a3a3b8' });
        const guest = window.MemeLeaderboard && window.MemeLeaderboard.getPlayer();
        if (guest) this.txt(ctx, 'PLAYER: ' + asciiUp(guest.nickname), 22, 28, { font: 'text', size: 11, align: 'left', stroke: '#000', sw: 4, color: '#ffe27a' });
        // Phiên bản game hiển thị cố định tại sảnh chờ.
        this.txt(ctx, 'VERSION V1', W - 24, H - 26, { font: 'text', size: 13, weight: 'bold', align: 'right', stroke: '#000', sw: 5, color: '#ffd45a', shadow: '#7a1020', sx: 2, sy: 2 });
    },
    // ---------------------------------------------------------------
    // CHỌN ĐỘ KHÓ
    // ---------------------------------------------------------------
    drawDifficultySelect(ctx, selected) {
        const E = this.engine, t = this.time;
        const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#160b35'); g.addColorStop(1, '#08030f'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
        for (let i = 0; i < 54; i++) { ctx.fillStyle = `rgba(255,255,255,${0.12 + 0.3 * Math.abs(Math.sin(t * 1.8 + i))})`; ctx.fillRect((i * 211 + 17) % W, (i * 97 + 11) % H, 3, 3); }
        this.txt(ctx, 'SELECT DIFFICULTY', W / 2, 125, { size: 34, align: 'center', stroke: '#000', sw: 9, grad: ['#fff', '#ffe27a', '#f59e0b'] });
        this.txt(ctx, 'CHỌN MỨC THỬ THÁCH TRƯỚC KHI BẮT ĐẦU', W / 2, 165, { font: 'text', size: 16, align: 'center', color: '#c4b5fd' });
        const cards = [
            { id: 'easy', title: 'EASY', color: '#4ade80', desc: 'Quái ít máu, đánh chậm, cảnh báo lâu.', extra: 'Dành cho người mới chơi' },
            { id: 'normal', title: 'NORMAL', color: '#facc15', desc: 'Chỉ số cân bằng, nhịp chiến đấu tiêu chuẩn.', extra: 'Trải nghiệm mặc định' },
            { id: 'hard', title: 'HARD', color: '#fb7185', desc: 'Quái mạnh, AI chủ động, combo dồn dập.', extra: 'Dành cho người chơi thành thạo' }
        ];
        const cw = 330, ch = 230, gap = 28, sx = (W - (cw * 3 + gap * 2)) / 2, y = 245;
        cards.forEach((c, i) => {
            const x = sx + i * (cw + gap), active = i === selected;
            ctx.save();
            this.frame(ctx, x, y, cw, ch, { fillTop: active ? '#33204d' : '#171126', fillBot: '#090611', border: active ? [c.color, '#fff', '#7c3aed'] : ['#8b7ca8', '#514568', '#211833'] });
            ctx.fillStyle = c.color; ctx.fillRect(x + 16, y + 16, cw - 32, 5);
            this.txt(ctx, c.title, x + cw / 2, y + 78, { size: 27, align: 'center', stroke: '#000', sw: 7, color: c.color });
            this.txt(ctx, c.desc, x + cw / 2, y + 125, { font: 'text', size: 15, align: 'center', color: '#fff' });
            this.txt(ctx, c.extra, x + cw / 2, y + 157, { font: 'text', size: 13, align: 'center', color: '#c4b5fd' });
            this.button(ctx, 'difficulty' + i, x + 28, y + 178, cw - 56, 38, active ? 'ĐANG CHỌN' : 'CHỌN MỨC NÀY', { selected: active, onClick: () => E._confirmDifficulty(i), size: 13 });
            ctx.restore();
        });
        this.txt(ctx, '← → CHỌN   ·   ENTER XÁC NHẬN   ·   ESC QUAY LẠI', W / 2, 635, { font: 'text', size: 14, align: 'center', color: '#e9d5ff', stroke: '#000', sw: 4 });
    },
    // ---------------------------------------------------------------
    // CHỌN NHÂN VẬT
    // ---------------------------------------------------------------
    drawCharSelect(ctx) {
        const t = this.time, E = this.engine, sel = this.selectedChar, info = CHAR_INFO[sel];
        const bg = ctx.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, '#150a30'); bg.addColorStop(1, '#07030f'); ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
        for (let i = 0; i < 50; i++) { const sx = (i * 211 + 19) % W, sy = (i * 97 + 13) % H; ctx.fillStyle = `rgba(255,255,255,${0.15 + 0.4 * Math.abs(Math.sin(t + i))})`; ctx.fillRect(sx, sy, 2, 2); }
        this.txt(ctx, 'CHỌN NHÂN VẬT', 40, 62, { font: 'text', size: 34, stroke: '#000', sw: 8, grad: ['#ffffff', '#ffd45a'] });
        this.txt(ctx, 'Click vào nhân vật để xem thông tin và kỹ năng', 42, 88, { font: 'text', size: 15, weight: 'normal', color: '#b8b0d8' });
        // lưới thẻ nhân vật 4 x 2
        const cw = 130, ch = 168, gx = 40, gy = 112, gap = 12;
        CHAR_ORDER.forEach((id, i) => {
            const x = gx + (i % 4) * (cw + gap), y = gy + Math.floor(i / 4) * (ch + gap), ci = CHAR_INFO[id], isSel = id === sel;
            const hover = this.button(ctx, 'card_' + id, x, y, cw, ch, '', { selected: isSel, onClick: () => { E.audio.playMenuSelect(); this.selectedChar = id; } });
            ctx.save(); ctx.beginPath(); ctx.rect(x + 8, y + 8, cw - 16, 92); ctx.clip();
            const g = ctx.createLinearGradient(0, y, 0, y + 100); g.addColorStop(0, '#3a2d63'); g.addColorStop(1, '#120d22'); ctx.fillStyle = g; ctx.fillRect(x + 8, y + 8, cw - 16, 92);
            portraitOf(ctx, id, x + 8, y + 8, cw - 16, 92);
            ctx.restore();
            this.txt(ctx, ci.name.length > 14 ? ci.name.split(' ').slice(0, 2).join(' ') : ci.name, x + cw / 2, y + 122, { font: 'text', size: 13, align: 'center', stroke: '#000', sw: 4, color: ci.playable ? '#ffd45a' : '#e2e8f0' });
            this.txt(ctx, ci.playable ? 'NHÂN VẬT CHƠI' : 'ĐỐI THỦ', x + cw / 2, y + 144, { size: 7, align: 'center', color: ci.playable ? '#86efac' : '#fca5a5', stroke: '#000', sw: 3 });
            if (!ci.playable) { ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(x + 4, y + 4, cw - 8, ch - 8); }
        });
        // khung chi tiết
        const dx = 640, dy = 40, dw = 600, dh = 560;
        this.frame(ctx, dx, dy, dw, dh, { fillTop: '#241a40', fillBot: '#0a0612' });
        // xem trước nhân vật
        ctx.save(); ctx.beginPath(); ctx.rect(dx + 8, dy + 8, 230, 300); ctx.clip();
        const pg = ctx.createRadialGradient(dx + 123, dy + 200, 20, dx + 123, dy + 200, 190); pg.addColorStop(0, '#4b3a86'); pg.addColorStop(1, '#120d22'); ctx.fillStyle = pg; ctx.fillRect(dx + 8, dy + 8, 230, 300);
        const px = dx + 123, py = dy + 282;
        ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.beginPath(); ctx.ellipse(px, py + 4, 60, 10, 0, 0, 6.283); ctx.fill();
        if (sel === 'doge') DogePuppet.draw(ctx, { by: -Math.abs(Math.sin(t * 4)) * 2 }, { x: px, y: py, facing: 1, h: 210 });
        else {
            const st = RIG_STYLES[CHAR_RIG[sel]], base = ((st.thigh + st.shin) * 0.98 + st.torso + st.neck + st.headSize) * st.scale, k = 230 / base;
            Rig.render(ctx, st, sel === 'ricardo' ? dancePose(t) : (sel === 'lord' ? epose('beam') : idlePose(t)), { x: px, y: py, facing: 1, scale: sel === 'lord' ? k * 1.1 : k, t, spr: sel === 'ricardo' ? RicardoSprite.dance(t) : (sel === 'chad' ? ChadSprite.idle(t) : (sel === 'lord' ? ((Math.floor(t / 2) % 2) ? { k: 'skill_1' } : LordSprite.idle(t)) : undefined)) });
        }
        ctx.restore();
        const ix = dx + 256;
        this.txt(ctx, info.name, ix, dy + 52, { font: 'text', size: 26, stroke: '#000', sw: 6, grad: ['#ffffff', '#ffd45a'] });
        this.txt(ctx, info.role, ix, dy + 78, { font: 'text', size: 14, color: info.playable ? '#86efac' : '#fca5a5', stroke: '#000', sw: 3 });
        ctx.font = 'normal 14px "Trebuchet MS", sans-serif';
        const words = info.desc.split(' '); let line = '', ly = dy + 108;
        for (const w of words) { const test = line ? line + ' ' + w : w; if (ctx.measureText(test).width > dw - 276 && line) { this.txt(ctx, line, ix, ly, { font: 'text', size: 14, weight: 'normal', color: '#e2e8f0' }); ly += 20; line = w; } else line = test; }
        if (line) this.txt(ctx, line, ix, ly, { font: 'text', size: 14, weight: 'normal', color: '#e2e8f0' });
        // chỉ số
        const stat = (label, v, y, col) => { this.txt(ctx, label, ix, y + 11, { size: 8, color: '#9ad7ff', stroke: '#000', sw: 3 }); for (let i = 0; i < 5; i++) { ctx.fillStyle = i < v ? col : '#2a2440'; ctx.fillRect(ix + 70 + i * 26, y, 22, 12); ctx.strokeStyle = '#000'; ctx.lineWidth = 2; ctx.strokeRect(ix + 70 + i * 26, y, 22, 12); } };
        stat('HP', info.hp, dy + 190, '#f87171'); stat('ATK', info.atk, dy + 214, '#fb923c'); stat('SPD', info.spd, dy + 238, '#4ade80');
        // kỹ năng
        this.txt(ctx, 'KỸ NĂNG & CÁCH CHIẾN ĐẤU', dx + 20, dy + 330, { size: 10, stroke: '#000', sw: 4, color: '#ffd45a' });
        info.skills.forEach((sk, i) => {
            const y = dy + 350 + i * 28;
            if (y > dy + dh - 20) return;
            const keys = sk[0];
            this.txt(ctx, keys, dx + 24, y + 16, { font: 'text', size: 13, color: '#ffd45a', stroke: '#000', sw: 3 });
            ctx.font = 'normal 13px "Trebuchet MS", sans-serif'; let txt = sk[1]; while (ctx.measureText(txt).width > dw - 170 && txt.length > 10) txt = txt.slice(0, -2);
            if (txt !== sk[1]) txt += '…';
            this.txt(ctx, txt, dx + 140, y + 16, { font: 'text', size: 13, weight: 'normal', color: '#e2e8f0' });
        });
        // nút
        const canPlay = info.playable;
        this.button(ctx, 'csStart', 40, H - 120, 330, 52, canPlay ? 'BẮT ĐẦU GAME' : 'CHỈ RICARDO CÓ THỂ CHƠI', { enabled: canPlay, onClick: () => E._startFromCharSelect(), size: 20 });
        this.button(ctx, 'csBack', 390, H - 120, 200, 52, 'QUAY LẠI', { onClick: () => E._backToMenu(), size: 18 });
        this.txt(ctx, '← → chọn · Enter bắt đầu · Esc quay lại', 40, H - 40, { font: 'text', size: 12, weight: 'normal', color: '#a3a3b8' });
    },
    // ---------------------------------------------------------------
    // THANH KỸ NĂNG TRONG TRẬN: vòng cooldown, icon, sáng khi sẵn sàng, tối khi hồi / thiếu MP
    // ---------------------------------------------------------------
    _drawActionBar(ctx, player) {
        const S = 62, G = 10, y = H - 92;
        const items = [
            { type: 'info', key: 'J·H·L', name: 'ĐÁNH', w: 78 },
            { type: 'block', key: 'K', name: 'ĐỠ ĐÒN', icon: 'shield', color: '#60a5fa' },
            { type: 'jump', key: 'W×2', name: 'NHẢY ĐÔI', icon: 'jump', color: '#a5f3fc' },
            { type: 'gap', w: 18 },
            { type: 'skill', id: 'skill1', icon: 'heart' }, { type: 'skill', id: 'skill2', icon: 'dash' }, { type: 'skill', id: 'skill3', icon: 'wave' }, { type: 'skill', id: 'ultimate', icon: 'star' }
        ];
        const total = items.reduce((a, it) => a + (it.w || S) + G, -G);
        let x = W / 2 - total / 2;
        for (const it of items) {
            const w = it.w || S;
            if (it.type === 'gap') { x += w + G; continue; }
            if (it.type === 'info') {          // ba phím đánh cơ bản
                this.frame(ctx, x, y, w, S, { noStuds: true, fillTop: '#2a2144', fillBot: '#0a0812' });
                [['J', '#f5c542'], ['H', '#fb923c'], ['L', '#38bdf8']].forEach(([k, c], i) => this.keycap(ctx, x + 6 + (i % 2) * 34, y + 8 + Math.floor(i / 2) * 26 + (i === 2 ? 0 : 0), 24, k, c));
                this.txt(ctx, it.name, x + w / 2, y + S - 6, { size: 7, align: 'center', color: '#fff3c4' });
                x += w + G; continue;
            }
            let ready = true, cd = 0, maxCd = 1, color = it.color, label = it.name, cost = 0, key = it.key, flash = 0, deny = 0, active = false;
            if (it.type === 'skill') {
                const d = SKILL_DEF[it.id]; cd = player.cooldowns[it.id]; maxCd = d.cd; color = d.color; label = d.name === 'ETERNAL DANCE' ? 'ULTIMATE' : d.name; cost = d.mp; key = d.key;
                ready = cd <= 0 && player.mp >= d.mp; flash = player.readyFlash[it.id]; deny = player.denyFlash[it.id]; active = player.state === ({ skill1: 'skill1', skill2: 'skill2', skill3: 'skill3', ultimate: 'ultimate' })[it.id];
            } else if (it.type === 'block') { ready = player.blockCd <= 0; active = player.blocking; cd = player.blockCd; maxCd = 0.22; }
            else if (it.type === 'jump') { ready = player.jumpsUsed < 2; active = player.jumpsUsed > 0; }
            const lit = ready || active;
            ctx.save();
            this.frame(ctx, x, y, w, S, { noStuds: true, border: lit ? ['#fff0a8', '#d9a521', '#7a4c0c'] : ['#8b8b99', '#52525e', '#2a2a33'], fillTop: lit ? '#33264f' : '#17171f', fillBot: '#0a0810' });
            if (ready && it.type === 'skill') { ctx.fillStyle = `rgba(255,212,90,${0.1 + 0.1 * Math.sin(this.time * 7)})`; ctx.fillRect(x + 4, y + 4, w - 8, S - 8); }
            ctx.globalAlpha = lit ? 1 : 0.5;
            drawIcon(ctx, it.icon, x + w / 2, y + 28, 22, lit ? color : '#6b7280');
            ctx.globalAlpha = 1;
            // lớp phủ cooldown dạng vòng (quét theo chiều kim đồng hồ)
            if (cd > 0 && it.type === 'skill') {
                ctx.save(); ctx.beginPath(); ctx.rect(x + 4, y + 4, w - 8, S - 8); ctx.clip();
                ctx.fillStyle = 'rgba(0,0,0,0.68)'; ctx.beginPath(); ctx.moveTo(x + w / 2, y + S / 2); ctx.arc(x + w / 2, y + S / 2, S, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (cd / maxCd)); ctx.closePath(); ctx.fill();
                ctx.restore();
                this.txt(ctx, cd >= 10 ? Math.ceil(cd) + '' : cd.toFixed(1), x + w / 2, y + 34, { size: 12, align: 'center', stroke: '#000', sw: 4, color: '#fff' });
            } else if (it.type === 'skill' && player.mp < cost) {
                ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(x + 4, y + 4, w - 8, S - 8);
            }
            if (flash > 0) { ctx.fillStyle = `rgba(255,255,255,${flash * 0.7})`; ctx.fillRect(x + 3, y + 3, w - 6, S - 6); }
            if (deny > 0) { ctx.fillStyle = `rgba(239,68,68,${deny * 0.5})`; ctx.fillRect(x + 3, y + 3, w - 6, S - 6); }
            if (active) { ctx.strokeStyle = color; ctx.lineWidth = 3; ctx.strokeRect(x + 2, y + 2, w - 4, S - 4); }
            this.txt(ctx, label, x + w / 2, y + S - 5, { size: 7, align: 'center', color: lit ? '#fff3c4' : '#7b7b88' });
            if (it.type === 'skill') this.txt(ctx, `${cost}MP`, x + w - 6, y + 14, { size: 7, align: 'right', color: player.mp >= cost ? '#9ad7ff' : '#f87171', stroke: '#000', sw: 3 });
            if (it.type === 'jump') { for (let k = 0; k < 2; k++) { ctx.fillStyle = k >= player.jumpsUsed ? '#a5f3fc' : '#374151'; ctx.beginPath(); ctx.arc(x + w / 2 - 8 + k * 16, y + 50, 3.5, 0, 6.283); ctx.fill(); } }
            ctx.restore();
            this.keycap(ctx, x + w / 2 - (key.length > 1 ? 14 : 10), y - 12, key.length > 1 ? 28 : 20, key, KEY_COL[key] || '#94a3b8');
            x += w + G;
        }
    },
    // nút nhỏ góc phải trên: tạm dừng / hướng dẫn / nhạc
    hudButtons(ctx) {
        const E = this.engine, y = 122;
        this.button(ctx, 'hudPause', W - 116, y, 30, 28, '\u23F8', { onClick: () => E.togglePause(), size: 14 });
        this.button(ctx, 'hudHelp', W - 80, y, 30, 28, '?', { onClick: () => { this.showControlsOverlay = true; }, size: 15 });
        this.button(ctx, 'hudMusic', W - 44, y, 30, 28, E.audio.settings.musicOn ? '\u266A' : '\u2715', { onClick: () => this.toast(E.audio.toggleMusic() ? 'Nhạc: TẮT' : 'Nhạc: BẬT', 1.6), size: 15 });
    },
    // ---------------------------------------------------------------
    // CÀI ĐẶT ÂM THANH & NHẠC
    // ---------------------------------------------------------------
    drawSettings(ctx, audio) {
        const E = this.engine, S = audio.settings;
        ctx.fillStyle = 'rgba(0,0,0,0.86)'; ctx.fillRect(0, 0, W, H);
        this.btns.push({ id: 'blocker', x: 0, y: 0, w: W, h: H, enabled: true });
        const cw = 1000, ch = 640, cx = W / 2 - cw / 2, cy = H / 2 - ch / 2;
        this.frame(ctx, cx, cy, cw, ch);
        this.txt(ctx, 'CÀI ĐẶT NHẠC & ÂM THANH', W / 2, cy + 56, { font: 'text', size: 32, align: 'center', stroke: '#000', sw: 7, grad: ['#ffffff', '#ffd45a'] });
        ctx.fillStyle = '#d9a521'; ctx.fillRect(cx + 30, cy + 74, cw - 60, 3);
        const rows = [
            { label: 'NHẠC NỀN', kind: 'toggle', on: S.musicOn },
            { label: 'ÂM LƯỢNG NHẠC', kind: 'vol', v: S.volMusic },
            { label: 'BÀI NHẠC SẢNH', kind: 'sel', value: audio.labelOf(S.menu) },
            { label: 'BÀI NHẠC TRẬN', kind: 'sel', value: audio.labelOf(S.game) },
            { label: 'ÂM LƯỢNG HIỆU ỨNG', kind: 'vol', v: S.volSfx },
            { label: 'HIỆU ỨNG ÂM THANH', kind: 'toggle', on: S.sfxOn },
            { label: 'THÊM NHẠC TỪ MÁY...', kind: 'btn' },
            { label: 'ĐÓNG', kind: 'close' }
        ];
        rows.forEach((r, i) => {
            const ry = cy + 96 + i * 56, sel = i === this.settingsRow, vx = cx + cw - 60;
            const hv = this.mouse.x >= cx + 30 && this.mouse.x <= cx + cw - 30 && this.mouse.y >= ry && this.mouse.y <= ry + 48;
            if (hv && this.mouse.moved) this.settingsRow = i;
            if (sel) { const g = ctx.createLinearGradient(cx + 30, 0, cx + cw - 30, 0); g.addColorStop(0, 'rgba(217,165,33,0)'); g.addColorStop(0.15, 'rgba(217,165,33,0.32)'); g.addColorStop(0.85, 'rgba(217,165,33,0.32)'); g.addColorStop(1, 'rgba(217,165,33,0)'); ctx.fillStyle = g; ctx.fillRect(cx + 30, ry, cw - 60, 48); }
            if (r.kind !== 'btn' && r.kind !== 'close') this.txt(ctx, r.label, cx + 70, ry + 32, { font: 'text', size: 19, color: sel ? '#fff3c4' : '#b6aed6', stroke: '#000', sw: 4 });
            if (r.kind === 'toggle') {
                this.button(ctx, 'set' + i, vx - 130, ry + 6, 130, 36, r.on ? 'BẬT' : 'TẮT', { selected: r.on, onClick: () => E._settingsAct(i, 0), size: 17 });
            } else if (r.kind === 'vol') {
                this.button(ctx, 'set' + i + 'm', vx - 330, ry + 6, 34, 36, '−', { onClick: () => E._settingsAct(i, -1), size: 20 });
                this.slider(ctx, 'set' + i + 's', vx - 285, ry + 17, 200, 14, r.v, (v) => { audio.setVolume(i === 1 ? 'volMusic' : 'volSfx', v); }, sel);
                this.button(ctx, 'set' + i + 'p', vx - 68, ry + 6, 34, 36, '+', { onClick: () => E._settingsAct(i, 1), size: 20 });
                this.txt(ctx, Math.round(r.v * 100) + '%', vx, ry + 32, { size: 11, align: 'right', color: '#ffd45a', stroke: '#000', sw: 4 });
            } else if (r.kind === 'sel') {
                this.button(ctx, 'set' + i + 'l', vx - 440, ry + 6, 40, 36, '\u25C0', { onClick: () => E._settingsAct(i, -1), size: 16 });
                let v = r.value; if (v.length > 30) v = v.slice(0, 28) + '..';
                this.txt(ctx, v, vx - 240, ry + 32, { font: 'text', size: 17, align: 'center', color: sel ? '#ffd45a' : '#e2e8f0', stroke: '#000', sw: 3 });
                this.button(ctx, 'set' + i + 'r', vx - 40, ry + 6, 40, 36, '\u25B6', { onClick: () => E._settingsAct(i, 1), size: 16 });
            } else if (r.kind === 'btn') {
                this.button(ctx, 'set' + i, cx + 70, ry + 4, 360, 40, r.label, { onClick: () => E._settingsAct(i, 0), size: 17 });
            } else if (r.kind === 'close') {
                this.button(ctx, 'set' + i, cx + 70, ry + 4, 360, 40, r.label, { onClick: () => E._settingsAct(i, 0), size: 18, danger: true });
            }
        });
        const n = audio.playlist.length;
        this.txt(ctx, `Đã tìm thấy ${n} file nhạc. Nhạc không bị ngắt khi vào trận / mở menu.`, cx + 70, cy + ch - 36, { font: 'text', size: 14, weight: 'normal', color: '#86efac', stroke: '#000', sw: 3 });
        this.txt(ctx, 'Thả mp3 vào assets/music/ rồi chạy update_lists. Phím N đổi bài · M bật/tắt nhạc · Esc đóng', cx + 70, cy + ch - 14, { font: 'text', size: 12, weight: 'normal', color: '#9ca3af' });
    },
    // ---------------------------------------------------------------
    // BẢNG HƯỚNG DẪN
    // ---------------------------------------------------------------
    drawControlsModal(ctx) {
        ctx.fillStyle = 'rgba(0,0,0,0.84)'; ctx.fillRect(0, 0, W, H);
        this.btns.push({ id: 'blocker', x: 0, y: 0, w: W, h: H, enabled: true });
        const cw = 1080, ch = 640, cx = W / 2 - cw / 2, cy = H / 2 - ch / 2;
        this.frame(ctx, cx, cy, cw, ch);
        this.txt(ctx, 'HƯỚNG DẪN ĐIỀU KHIỂN & COMBO', W / 2, cy + 52, { font: 'text', size: 28, align: 'center', stroke: '#000', sw: 7, grad: ['#ffffff', '#ffd45a'] });
        ctx.fillStyle = '#d9a521'; ctx.fillRect(cx + 30, cy + 68, cw - 60, 3);
        const left = [
            ['← → (đúp = chạy)', 'Di chuyển · nhấn đúp + giữ = CHẠY NHANH'], ['↑ / Space', 'Nhảy · nhấn lần 2 trên không = NHẢY ĐÔI'], ['K / ↓ (giữ)', 'ĐỠ ĐÒN −80% · đỡ đúng lúc = PERFECT BLOCK'], ['Shift + hướng', 'Lướt nhanh'],
            ['J', 'Đấm nhẹ'], ['H', 'Đấm mạnh'], ['L', 'Đá'], ['U', 'DACNE — hồi máu bằng điệu nhảy'], ['I', 'THRUST — lao tới, gây choáng'], ['O', 'CHƯỞNG — bắn tia năng lượng'], ['P', 'ETERNAL DANCE (đủ 100 MP)'], ['Esc', 'Tạm dừng']
        ];
        this.txt(ctx, 'ĐIỀU KHIỂN', cx + 40, cy + 100, { size: 11, stroke: '#000', sw: 5, color: '#7dd3fc' });
        left.forEach((r, i) => {
            const ry = cy + 134 + i * 36;
            if (KEY_COL[r[0]]) this.keycap(ctx, cx + 40, ry - 20, 26, r[0], KEY_COL[r[0]]);
            else this.txt(ctx, r[0], cx + 40, ry, { font: 'text', size: 15, color: '#ffd45a', stroke: '#000', sw: 3 });
            this.txt(ctx, r[1], cx + 230, ry, { font: 'text', size: 15, color: '#f8fafc', stroke: '#000', sw: 3 });
        });
        const rx = cx + 640;
        ctx.fillStyle = '#d9a521'; ctx.fillRect(rx - 20, cy + 86, 3, ch - 160);
        this.txt(ctx, 'COMBO (Z · X · C)', rx, cy + 100, { size: 11, stroke: '#000', sw: 5, color: '#ffb3d9' });
        this.txt(ctx, 'Bấm tiếp phím ngay khi đòn trước vừa tung để nối chuỗi.', rx, cy + 128, { font: 'text', size: 13, weight: 'normal', color: '#cbd5e1' });
        this.txt(ctx, 'Tối đa 4 đòn, đòn thứ 4 là FINISHER. Đánh trúng nạp MP.', rx, cy + 148, { font: 'text', size: 13, weight: 'normal', color: '#cbd5e1' });
        COMBO_LIST.forEach((r, i) => {
            const ry = cy + 176 + i * 40;
            r[0].split(' ').forEach((c, k) => this.keycap(ctx, rx + k * 34, ry, 26, c, KEY_COL[c] || '#fff'));
            this.txt(ctx, r[1], rx + 4 * 34 + 12, ry + 19, { font: 'text', size: 14, color: '#fff3c4', stroke: '#000', sw: 3 });
        });
        this.button(ctx, 'helpClose', W / 2 - 110, cy + ch - 56, 220, 40, 'ĐÓNG (Esc)', { onClick: () => { this.showControlsOverlay = false; }, size: 17, danger: true });
    },
    // ---------------------------------------------------------------
    // HỘP THOẠI CÓ NÚT: Pause / Game Over / Victory
    // ---------------------------------------------------------------
    _dialog(ctx, title, tgrad, lines, buttons, border, author) {
        ctx.fillStyle = 'rgba(0,0,0,0.78)'; ctx.fillRect(0, 0, W, H);
        this.btns.push({ id: 'blocker', x: 0, y: 0, w: W, h: H, enabled: true });
        const bw = 640, rows = lines.length, authorH = author ? 52 : 0, bh = 120 + rows * 38 + authorH + 24 + buttons.length * 58, bx = W / 2 - bw / 2, by = H / 2 - bh / 2;
        this.frame(ctx, bx, by, bw, bh, border ? { border } : {});
        this.txt(ctx, title, W / 2, by + 78, { size: 38, align: 'center', stroke: '#000', sw: 12, shadow: '#000', sx: 4, sy: 5, grad: tgrad });
        lines.forEach((l, i) => {
            const ly = by + 122 + i * 38;
            if (Array.isArray(l)) {
                this.txt(ctx, l[0], bx + 80, ly, { size: 9, color: '#9ad7ff', stroke: '#000', sw: 4 });
                this.txt(ctx, String(l[1]), bx + bw - 80, ly, { size: 12, align: 'right', color: '#ffd45a', stroke: '#000', sw: 4 });
                ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fillRect(bx + 80, ly + 10, bw - 160, 1);
            } else this.txt(ctx, l, W / 2, ly, { font: 'text', size: 19, align: 'center', color: '#fff3c4', stroke: '#000', sw: 4 });
        });
        if (author) {
            const ay = by + 112 + rows * 38;
            const ax = bx + 112, aw = bw - 224, ah = 34;
            // Khung credit pixel-art ở cuối màn hình kết thúc
            ctx.fillStyle = 'rgba(8, 12, 28, 0.96)'; ctx.fillRect(ax, ay, aw, ah);
            ctx.fillStyle = '#8b5e16'; ctx.fillRect(ax, ay, aw, 3); ctx.fillRect(ax, ay + ah - 3, aw, 3);
            ctx.fillStyle = '#f5c451'; ctx.fillRect(ax, ay + 3, 3, ah - 6); ctx.fillRect(ax + aw - 3, ay + 3, 3, ah - 6);
            this.txt(ctx, 'CREATED BY', W / 2, ay + 14, { font: 'text', size: 10, align: 'center', color: '#9ca3af', stroke: '#000', sw: 3 });
            this.txt(ctx, author, W / 2, ay + 27, { font: 'text', size: 15, align: 'center', color: '#ffd45a', stroke: '#000', sw: 4, shadow: '#8b5e16', sx: 1, sy: 1 });
        }
        const by0 = by + 130 + rows * 38 + authorH;
        buttons.forEach((b, i) => {
            const hv = this.button(ctx, 'dlg' + i, W / 2 - 200, by0 + i * 58, 400, 48, b.label, { onClick: b.onClick, enabled: b.enabled, danger: b.danger, selected: i === this.dlgIdx, size: 19 });
            if (hv && this.mouse.moved) this.dlgIdx = i;
        });
        this.dlgButtons = buttons;
    },
    drawPause(ctx) {
        const E = this.engine;
        this._dialog(ctx, 'TẠM DỪNG', ['#ffffff', '#ffe27a', '#f59e0b'], [], [
            { label: 'TIẾP TỤC', onClick: () => E.togglePause() },
            { label: 'CÀI ĐẶT NHẠC & ÂM THANH', onClick: () => { this.showSettings = true; this.settingsRow = 0; } },
            { label: 'HƯỚNG DẪN & COMBO', onClick: () => { this.showControlsOverlay = true; } },
            { label: 'CHƠI LẠI MÀN NÀY', onClick: () => E.restartCurrent() },
            { label: 'VỀ SẢNH CHỜ', danger: true, onClick: () => E.toMenu() }
        ]);
    },
    drawGameOver(ctx, player) {
        const E = this.engine;
        this._dialog(ctx, 'GAME OVER', ['#ffffff', '#ff8a8a', '#b91c1c'], [
            ['ĐÃ HẠ GỤC', player.killCount], ['COMBO CAO NHẤT', player.maxCombo], ['TỔNG SÁT THƯƠNG', player.totalDamageDealt]
        ], [
            { label: 'CHƠI LẠI (Enter)', onClick: () => E._retry() },
            { label: 'VỀ SẢNH CHỜ (Esc)', danger: true, onClick: () => E.toMenu() }
        ], ['#ffb3b3', '#d1122b', '#5c0a14'], 'HUYKIBO');
    },
    drawVictory(ctx, player) {
        const E = this.engine;
        this._dialog(ctx, 'VICTORY!', ['#ffffff', '#b9ffd8', '#10b981'], [
            'Ricardo Milos phá đảo thế giới meme!',
            ['ĐÃ HẠ GỤC', player.killCount], ['COMBO CAO NHẤT', player.maxCombo], ['TỔNG SÁT THƯƠNG', player.totalDamageDealt]
        ], [
            { label: 'CHƠI LẠI TỪ ĐẦU (Enter)', onClick: () => E._retry() },
            { label: 'VỀ SẢNH CHỜ (Esc)', danger: true, onClick: () => E.toMenu() }
        ], undefined, 'HUYKIBO');
    }
});

// ============================================================
// STORY — kịch bản cốt truyện (xem CutsceneManager bên dưới để hiểu các trường)
// ============================================================
const CHARS = {
    ricardo: { name: 'RICARDO MILOS', color: '#ffd45a' },
    troll:   { name: 'TROLLFACE',     color: '#e5e7eb', skin: 'troll' },
    chad:    { name: 'GIGACHAD',      color: '#fca5a5', skin: 'chad' },
    doge:    { name: 'DOGE',          color: '#fdba74', skin: 'doge' },
    demon:   { name: 'THE DELETER',   color: '#ff3355', skin: 'lord' },
    deleter: { name: 'THE DELETER',   color: '#ff3355', procedural: 'deleter' },
    sys:     { name: 'HỆ THỐNG',      color: '#7dd3fc' }
};
const STORY = {
    prologue: [
        { bg: 'cosmos', theme: 'violet', floaters: true, sfx: 'dark', text: 'Trong một vũ trụ nơi sức mạnh được quyết định bởi độ viral...' },
        { bg: 'cosmos', theme: 'violet', floaters: true, fx: ['glitch'], sfx: 'glitch', text: '...nơi những meme có thể bẻ cong thực tại,' },
        { bg: 'cosmos', theme: 'gold', rings: true, fx: ['shake'], sfx: 'riser', ricardo: { x: 0.5, h: 150, y: 470, anim: 'dance', sil: true }, text: 'và một điệu nhảy có thể làm rung chuyển cả thiên hà.' },
        { bg: 'cosmos', theme: 'gold', rays: true, fx: ['flash', 'shake'], sfx: 'impact', ricardo: { x: 0.5, h: 330, y: 560, anim: 'dance' }, title: { big: 'RICARDO MILOS', small: 'HUYỀN THOẠI MEME DANCE' }, text: 'Một huyền thoại đã thức tỉnh.' },
        { bg: 'energy', sfx: 'reveal', ricardo: { x: 0.5, h: 300, y: 560, anim: 'dance' }, text: 'Từng là biểu tượng bất tử của nền văn hóa meme Internet, Ricardo sở hữu sức mạnh tối thượng mang tên MEME ENERGY —' },
        { bg: 'energy', ricardo: { x: 0.5, h: 300, y: 560, anim: 'dance' }, text: 'nguồn năng lượng được tạo ra từ tiếng cười, sự hỗn loạn và hàng tỷ lượt xem.' },
        { bg: 'cosmos', theme: 'violet', freeze: true, sfx: 'freeze', ricardo: { x: 0.5, h: 300, y: 560, anim: 'dance' }, text: 'Chỉ cần một điệu nhảy, anh có thể khiến thời gian ngừng trôi, phá vỡ mọi quy luật vật lý và khiến kẻ thù rơi vào trạng thái mất kiểm soát.' },
        { bg: 'throne', theme: 'dark', sfx: 'dark', text: 'Nhưng khi chiếc ngai vàng MEMEVERSE bị bỏ trống...' },
        { bg: 'throne', theme: 'red', cracked: true, fx: ['flash', 'shake', 'glitch'], sfx: 'impact', text: '...một cuộc chiến chưa từng có đã bùng nổ.' },
        { bg: 'cosmos', theme: 'red', floaters: true, fx: ['glitch'], sfx: 'glitch', text: 'Những nhân vật meme nguy hiểm nhất từ mọi ngóc ngách Internet đồng loạt xuất hiện.' },
        { bg: 'cosmos', theme: 'red', sfx: 'reveal', hold: 1.9, cards: [{ id: 'chad', name: 'GIGACHAD', tag: 'Sức mạnh cơ bắp tuyệt đối' }] },
        { bg: 'cosmos', theme: 'red', sfx: 'reveal', hold: 1.9, cards: [{ id: 'troll', name: 'TROLLFACE', tag: 'Thao túng cả thực tại' }] },
        { bg: 'cosmos', theme: 'red', sfx: 'reveal', hold: 1.9, cards: [{ id: 'doge', name: 'DOGE', tag: 'Tài sản vô hạn' }] },
        { bg: 'cosmos', theme: 'red', lineup: true, sfx: 'riser', text: 'Cùng hàng loạt thực thể meme bí ẩn khác — tất cả đều khao khát trở thành MEME LORD, Bá Chủ Meme.' },
        { bg: 'void', big: true, fast: true, sfx: 'impact', text: 'KHÔNG AI CÓ THỂ TIN TƯỞNG AI.' },
        { bg: 'void', big: true, fast: true, sfx: 'impact', text: 'KHÔNG LUẬT LỆ.' },
        { bg: 'void', big: true, fast: true, sfx: 'impact', fx: ['shake'], text: 'KHÔNG GIỚI HẠN.' },
        { bg: 'cosmos', theme: 'violet', floaters: true, text: 'Chỉ có những trận chiến điên rồ quyết định kẻ nào xứng đáng thống trị Memeverse.' },
        { bg: 'void', big: true, fx: ['flash'], sfx: 'impact', spot: true, ricardo: { x: 0.5, h: 340, y: 560, anim: 'idle' }, text: 'VÀ RICARDO MILOS ĐÃ TRỞ LẠI.' },
        { bg: 'void', spot: true, ricardo: { x: 0.5, h: 340, y: 560, anim: 'idle' }, text: 'Không phải để cứu thế giới. Không phải để trả thù.' },
        { bg: 'cosmos', theme: 'gold', rays: true, fx: ['flash'], sfx: 'reveal', ricardo: { x: 0.5, h: 320, y: 560, anim: 'dance' }, title: { big: "LET'S DANCE!", small: '' }, text: 'Anh trở lại để chứng minh rằng không ai có thể vượt qua huyền thoại của những điệu nhảy.' }
    ],
    chapters: [
        { num: 'CHƯƠNG I', name: 'THE RETURN OF THE LEGEND',
          desc: 'Ricardo tỉnh giấc giữa một Memeverse đang sụp đổ. Anh phải đánh bại những meme cấp thấp, thu thập Meme Energy và khôi phục sức mạnh huyền thoại của mình.',
          talk: [
              { left: 'ricardo', speaker: 'left', text: '…Mình đã ngủ bao lâu rồi? Sao cả Memeverse trông như một video bị lag thế này?' },
              { left: 'ricardo', speaker: 'sys', text: '[CẢNH BÁO] Meme Energy: 3%. Khuyến nghị: đánh bại vài meme cấp thấp để nạp lại năng lượng.' },
              { left: 'ricardo', speaker: 'sys', text: 'Mẹo: nối Z · X · C để tung combo, giữ K (hoặc ↓) để đỡ đòn (đỡ đúng lúc = PERFECT BLOCK). Đánh trúng nạp thanh POW — đầy 100 thì bấm F để tung ETERNAL DANCE!' },
              { left: 'ricardo', speaker: 'left', text: 'Nghe như một lời mời nhảy. Bắt đầu thôi!' }
          ] },
        { num: 'CHƯƠNG II', name: 'WAR OF THE MEMES',
          desc: 'Các thế lực meme bắt đầu cuộc chiến toàn diện. Ricardo phải đối đầu với những đối thủ sở hữu sức mạnh phi lý, từ những chiến binh bất bại đến các thực thể có khả năng viết lại quy luật của vũ trụ.',
          talk: [
              { left: 'ricardo', right: 'troll', speaker: 'right', fx: ['glitch'], text: 'Problem, Ricardo? Ngươi tưởng cứ nhảy là thắng sao? Ở đây, chính ta viết lại luật chơi.' },
              { left: 'ricardo', right: 'troll', speaker: 'left', text: 'Luật à? Anh chỉ biết đúng một luật: nhạc bật lên thì phải nhảy.' },
              { left: 'ricardo', right: 'chad', speaker: 'right', text: 'Ngươi yếu. Ta tập gym cả khi đang ngủ.' },
              { left: 'ricardo', right: 'doge', speaker: 'right', text: 'Wow. Much power. Very dangerous. Such… đau.' },
              { left: 'ricardo', right: 'doge', speaker: 'left', text: 'Vậy thì đến đi. Cả ba cùng lúc cũng được.' }
          ] },
        { num: 'CHƯƠNG III', name: 'THE FORBIDDEN MEME',
          desc: 'Một bí mật kinh hoàng được hé lộ: có một thực thể cổ đại đứng sau mọi cuộc chiến. Hắn muốn xóa sạch toàn bộ meme để tạo ra một thế giới không tiếng cười, không hỗn loạn và không tự do.',
          talk: [
              { left: 'ricardo', right: 'doge', speaker: 'right', text: 'Khoan… đừng đánh nữa. Chúng ta đều bị lợi dụng. Có kẻ đứng sau tất cả những cuộc chiến này…' },
              { left: 'ricardo', speaker: 'sys', fx: ['shake'], sfx: 'dark', text: 'Bầu trời Memeverse nứt toác. Một giọng nói vang lên từ hư không.' },
              { left: 'ricardo', right: 'deleter', speaker: 'right', fx: ['glitch', 'shake'], sfx: 'glitch', text: 'Ta là DELETER — nút xóa đầu tiên của Internet. Mọi meme rồi sẽ bị xóa sạch: không tiếng cười, không hỗn loạn, không tự do.' },
              { left: 'ricardo', right: 'deleter', speaker: 'left', text: 'Ý tưởng tệ nhất anh từng nghe. Mà anh từng nghe cả bản remix 10 tiếng đấy.' }
          ] },
        { num: 'CHƯƠNG IV', name: 'THE FINAL DANCE',
          desc: 'Ricardo đối đầu với kẻ thù cuối cùng trong trận chiến quyết định vận mệnh Memeverse. Khi mọi sức mạnh đều thất bại, anh giải phóng hình thái tối thượng: THE ETERNAL DANCE.',
          talk: [
              { left: 'ricardo', right: 'demon', speaker: 'right', fx: ['shake'], sfx: 'impact', text: 'Ta đã nhập vào thân xác Ultimate Meme Lord. Hãy chứng kiến ngày tận thế của tiếng cười!' },
              { left: 'ricardo', right: 'demon', speaker: 'left', text: 'Anh không đến để cứu thế giới. Anh đến để chứng minh một điều…' },
              { left: 'ricardo', right: 'demon', speaker: 'left', fx: ['flash'], text: 'Không ai nhảy hay hơn anh.' }
          ] }
    ],
    eternal: [
        { bg: 'game', freeze: true, sfx: 'freeze', text: 'Sức lực cạn kiệt. Mọi chiêu thức đều thất bại…' },
        { bg: 'zone', left: 'ricardo', speaker: 'left', text: 'Chưa… xong đâu.' },
        { bg: 'energy', rays: true, fx: ['flash', 'shake'], sfx: 'eternal', ricardo: { x: 0.5, h: 340, y: 580, anim: 'dance' }, title: { big: 'THE ETERNAL DANCE', small: 'HÌNH THÁI TỐI THƯỢNG' }, text: 'Ricardo giải phóng toàn bộ Meme Energy!' }
    ],
    ending: [
        { bg: 'zone', shatter: 'lord', fx: ['flash', 'shake', 'glitch'], sfx: 'impact', text: 'Ultimate Meme Lord vỡ vụn thành hàng triệu điểm ảnh.' },
        { bg: 'zone', left: 'ricardo', right: 'deleter', speaker: 'right', fx: ['glitch'], sfx: 'glitch', text: 'Không thể nào… một điệu nhảy… lại có thể…' },
        { bg: 'zone', left: 'ricardo', right: 'deleter', speaker: 'left', text: 'Meme không bao giờ chết. Chúng chỉ chờ đúng lúc để viral trở lại.' },
        { bg: 'throne', theme: 'gold', sfx: 'reveal', text: 'Memeverse dần phục hồi. Tiếng cười vang lên khắp mọi ngóc ngách Internet.' },
        { bg: 'throne', theme: 'gold', text: 'Ngai vàng vẫn bỏ trống. Ricardo không ngồi lên đó.' },
        { bg: 'energy', ricardo: { x: 0.5, h: 320, y: 560, anim: 'dance' }, text: 'Vì huyền thoại không cần ngai vàng — chỉ cần một bản nhạc.' },
        { bg: 'cosmos', theme: 'gold', rays: true, dur: 4.5, sfx: 'reveal', ricardo: { x: 0.5, h: 300, y: 560, anim: 'dance' }, title: { big: 'THE END', small: 'RICARDO MILOS WILL DANCE AGAIN' } }
    ]
};
// Cảnh chương: thẻ tiêu đề + (lần đầu) hội thoại
function chapterScenes(idx, full) {
    const c = STORY.chapters[idx];
    const out = [{ bg: 'zone', chapter: { num: c.num, name: c.name }, sfx: 'gong', hold: full ? 2.6 : 0.8, fast: !full, text: full ? c.desc : '' }];
    if (full) c.talk.forEach(t => out.push(Object.assign({ bg: 'zone' }, t)));
    return out;
}

// ============================================================
// CUTSCENE MANAGER — dựng "phim" bằng canvas: nền thiên hà, ngai vàng, tia sáng,
// chữ chạy từng ký tự, thẻ nhân vật, hội thoại có chân dung, glitch / rung / chớp / đóng băng thời gian
// ============================================================
const CINE_THEMES = {
    violet: { sky: ['#05010f', '#150a33', '#34104a'], neb: ['rgba(255,60,166,0.22)', 'rgba(57,231,255,0.18)', 'rgba(160,90,255,0.2)'] },
    red:    { sky: ['#0a0000', '#2a0510', '#4a0a14'], neb: ['rgba(255,40,60,0.25)', 'rgba(255,120,0,0.16)', 'rgba(160,0,60,0.22)'] },
    gold:   { sky: ['#0a0618', '#2a1a40', '#5a3a10'], neb: ['rgba(255,212,90,0.25)', 'rgba(255,120,200,0.16)', 'rgba(255,170,60,0.2)'] },
    dark:   { sky: ['#000000', '#05050a', '#0c0a18'], neb: ['rgba(80,60,160,0.12)', 'rgba(40,40,100,0.1)', 'rgba(60,20,80,0.1)'] }
};
class CutsceneManager {
    constructor(engine) {
        this.e = engine;
        this.active = false;
        this.scenes = []; this.i = 0; this.cur = null; this.t = 0; this.total = 1;
        this.typed = 0; this.textLen = 0; this.cps = 30; this.textTime = 0;
        this.bars = 0; this.fade = 0; this.flash = 0; this.shake = 0; this.glitch = 0;
        this.onDone = null;
        let seed = 1234;
        const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
        this.stars = Array.from({ length: 170 }, () => ({ x: rnd() * W, y: rnd() * H, z: 0.2 + rnd() * 0.8, p: rnd() * 6.28 }));
        this.floatSkins = ['troll', 'chad', 'doge', 'wojak', 'dancer', 'sigma', 'lord'];
    }
    play(scenes, onDone) {
        this.scenes = scenes; this.i = -1; this.onDone = onDone || null;
        this.active = true; this.bars = 0; this.e.audio.duck(0.45);
        this._next();
    }
    _next() {
        this.i++;
        if (this.i >= this.scenes.length) { this._finish(); return; }
        const sc = this.cur = this.scenes[this.i];
        this.t = 0; this.typed = 0; this.fade = 1;
        this.textLen = (sc.text || '').length;
        this.cps = sc.fast ? 70 : (sc.speaker ? 36 : 32);
        this.textTime = this.textLen / this.cps;
        const hold = sc.hold !== undefined ? sc.hold : (sc.fast ? 1.0 : 1.9);
        this.total = Math.max(sc.dur || 0, this.textTime + hold + (sc.title ? 1.2 : 0) + (sc.cards ? 0.8 : 0));
        for (const f of (sc.fx || [])) {
            if (f === 'flash') this.flash = 1;
            if (f === 'shake') this.shake = 0.8;
            if (f === 'glitch') this.glitch = 0.9;
        }
        if (sc.sfx) this.e.audio.playCine(sc.sfx);
        if (sc.chapter) this.shake = 0.35;
    }
    _finish() {
        this.active = false; this.e.audio.duck(1);
        const cb = this.onDone; this.onDone = null;
        if (cb) cb();
    }
    update(dt) {
        if (!this.active) return;
        this.t += dt;
        this.bars = Math.min(1, this.bars + dt * 2.2);
        this.fade = Math.max(0, this.fade - dt * 4);
        this.flash = Math.max(0, this.flash - dt * 2.2);
        this.shake = Math.max(0, this.shake - dt);
        this.glitch = Math.max(0, this.glitch - dt);
        const prev = Math.floor(this.typed);
        this.typed = Math.min(this.textLen, this.typed + this.cps * dt);
        if (Math.floor(this.typed) > prev && Math.floor(this.typed) % 3 === 0 && !this.cur.fast && !this.cur.big) this.e.audio.playType();
        if (this.t >= this.total) this._next();
    }
    key(k) {
        if (k === 'escape') { this._finish(); return; }
        if (k === 'enter' || k === ' ' || k === 'j') {
            if (this.typed < this.textLen) { this.typed = this.textLen; this.t = Math.max(this.t, this.textTime); }
            else if (this.t > 0.35) this._next();
        }
    }

    // ---------------------------------------------------------------
    // Vẽ
    // ---------------------------------------------------------------
    draw(ctx) {
        const sc = this.cur, t = this.t;
        ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
        ctx.save();
        if (this.shake > 0) ctx.translate((Math.random() - 0.5) * this.shake * 24, (Math.random() - 0.5) * this.shake * 24);
        const zoom = 1 + Math.min(t, 9) * 0.006;
        ctx.translate(W / 2, H / 2); ctx.scale(zoom, zoom); ctx.translate(-W / 2, -H / 2);
        this._bg(ctx, sc, t);
        this._actors(ctx, sc, t);
        ctx.restore();
        if (sc.freeze) this._freeze(ctx, t);
        this._text(ctx, sc, t);
        if (this.glitch > 0) this._glitch(ctx);
        // tối góc
        const v = ctx.createRadialGradient(W / 2, H / 2, H * 0.4, W / 2, H / 2, W * 0.72);
        v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.6)');
        ctx.fillStyle = v; ctx.fillRect(0, 0, W, H);
        if (this.flash > 0) { ctx.fillStyle = `rgba(255,255,255,${this.flash})`; ctx.fillRect(0, 0, W, H); }
        if (this.fade > 0) { ctx.fillStyle = `rgba(0,0,0,${this.fade})`; ctx.fillRect(0, 0, W, H); }
        this._bars(ctx);
    }
    _bars(ctx) {
        const bh = 64 * (1 - Math.pow(1 - this.bars, 3));
        ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, bh); ctx.fillRect(0, H - bh, W, bh);
        ctx.fillStyle = '#d9a521'; ctx.fillRect(0, bh - 2, W, 2); ctx.fillRect(0, H - bh, W, 2);
        const ui = this.e.ui;
        ui.txt(ctx, 'CỐT TRUYỆN', 24, H - 24, { font: 'text', size: 14, color: '#7a6a3a' });
        if (Math.floor(ui.time * 2) % 2 === 0) ui.txt(ctx, 'ENTER \u25B6 TIẾP', W - 190, H - 24, { size: 9, align: 'right', color: '#cbd5e1' });
        ui.txt(ctx, 'ESC BỎ QUA', W - 24, H - 24, { size: 9, align: 'right', color: '#6b7280' });
        ctx.fillStyle = '#ffd45a'; ctx.fillRect(0, H - 3, W * (this.i + Math.min(1, this.t / this.total)) / this.scenes.length, 3);
    }
    _glitch(ctx) {
        const k = this.glitch;
        for (let n = 0; n < 12; n++) {
            const sy = Math.random() * H, sh = 6 + Math.random() * 34, off = (Math.random() - 0.5) * 120 * k;
            ctx.drawImage(ctx.canvas, 0, sy, W, sh, off, sy, W, sh);
            if (n % 3 === 0) { ctx.fillStyle = n % 2 ? 'rgba(255,0,120,0.22)' : 'rgba(0,255,255,0.22)'; ctx.fillRect(0, sy, W, sh); }
        }
    }
    _freeze(ctx, t) {   // thời gian ngừng trôi: mất màu + sóng xanh lan ra
        ctx.save();
        ctx.globalCompositeOperation = 'saturation'; ctx.fillStyle = '#808080'; ctx.fillRect(0, 0, W, H);
        ctx.globalCompositeOperation = 'source-over';
        ctx.fillStyle = 'rgba(120,170,255,0.12)'; ctx.fillRect(0, 0, W, H);
        ctx.strokeStyle = 'rgba(160,210,255,0.5)'; ctx.lineWidth = 3;
        for (let i = 0; i < 3; i++) { const p = ((t * 0.5) + i / 3) % 1; ctx.globalAlpha = 1 - p; ctx.beginPath(); ctx.arc(W / 2, H / 2, p * 700, 0, 6.283); ctx.stroke(); }
        ctx.restore();
    }

    // ---- nền ----
    _bg(ctx, sc, t) {
        const bg = sc.bg;
        if (bg === 'game') { this.e._renderScene(); return; }
        if (bg === 'zone') {
            const e = this.e;
            e.map.drawSky(ctx); e.map.drawBackground(ctx, e.camera); e.map.drawGround(ctx, e.camera);
            ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.fillRect(0, 0, W, H);
            return;
        }
        if (bg === 'void') {
            ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
            if (sc.spot) {
                const g = ctx.createRadialGradient(W / 2, 330, 20, W / 2, 330, 460);
                g.addColorStop(0, 'rgba(255,240,200,0.55)'); g.addColorStop(1, 'rgba(0,0,0,0)');
                ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
            }
            return;
        }
        if (bg === 'energy') {
            const g = ctx.createRadialGradient(W / 2, 360, 20, W / 2, 360, 760);
            g.addColorStop(0, '#6a1b6e'); g.addColorStop(0.5, '#2a0a4a'); g.addColorStop(1, '#05010f');
            ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
            this._rays(ctx, t, W / 2, 380, 'rgba(255,212,90,0.10)', 16);
            this._sparks(ctx, t, W / 2, 560, 70, ['#ffd45a', '#ff6ec7', '#7dd3fc']);
            return;
        }
        this._cosmos(ctx, t, sc.theme || 'violet');
        if (bg === 'throne') this._throne(ctx, t, sc);
        if (sc.floaters) this._floaters(ctx, t);
        if (sc.rays) { this._rays(ctx, t, W / 2, 400, 'rgba(255,212,90,0.13)', 18); this._sparks(ctx, t, W / 2, 560, 60, ['#ffd45a', '#ffffff', '#ff6ec7']); }
        if (sc.rings) for (let i = 0; i < 4; i++) { const p = ((t * 0.45) + i / 4) % 1; ctx.strokeStyle = `rgba(255,212,90,${0.5 * (1 - p)})`; ctx.lineWidth = 4; ctx.beginPath(); ctx.ellipse(W / 2, 470, 60 + p * 560, 14 + p * 130, 0, 0, 6.283); ctx.stroke(); }
    }
    _cosmos(ctx, t, theme) {
        const th = CINE_THEMES[theme] || CINE_THEMES.violet;
        const g = ctx.createLinearGradient(0, 0, 0, H);
        g.addColorStop(0, th.sky[0]); g.addColorStop(0.55, th.sky[1]); g.addColorStop(1, th.sky[2]);
        ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
        th.neb.forEach((c, i) => {
            const x = W * (0.25 + 0.25 * i) + Math.sin(t * 0.15 + i * 2) * 120, y = 280 + Math.cos(t * 0.12 + i) * 80;
            const r = ctx.createRadialGradient(x, y, 10, x, y, 420);
            r.addColorStop(0, c); r.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = r; ctx.fillRect(0, 0, W, H);
        });
        for (const s of this.stars) {
            const x = (s.x + t * 14 * s.z) % W;
            ctx.fillStyle = `rgba(255,255,255,${0.35 + 0.6 * Math.abs(Math.sin(t * 1.5 + s.p)) * s.z})`;
            ctx.fillRect(x, s.y, 1 + s.z * 2, 1 + s.z * 2);
        }
    }
    _rays(ctx, t, cx, cy, color, n) {
        ctx.save(); ctx.translate(cx, cy); ctx.rotate(t * 0.12); ctx.fillStyle = color;
        for (let i = 0; i < n; i++) { ctx.rotate(Math.PI * 2 / n); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(1400, -50); ctx.lineTo(1400, 50); ctx.closePath(); ctx.fill(); }
        ctx.restore();
    }
    _sparks(ctx, t, cx, cy, count, colors) {   // hạt Meme Energy bay lên
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        for (let i = 0; i < count; i++) {
            const p = (t * 0.5 + i / count) % 1, x = cx + Math.sin(i * 12.9) * 380 * (0.25 + p), y = cy - p * 560, sz = 2 + (i % 4) * 1.5;
            ctx.globalAlpha = Math.sin(p * Math.PI) * 0.9; ctx.fillStyle = colors[i % colors.length];
            ctx.beginPath(); ctx.arc(x, y, sz, 0, 6.283); ctx.fill();
        }
        ctx.restore();
    }
    // THE DELETER — "nút xóa đầu tiên của Internet": bóng đen khoác áo choàng, đầu là phím DEL, nhiễu glitch đỏ.
    // (Trước đây cảnh kết gọi hàm này nhưng chưa được viết -> TypeError -> vòng lặp game dừng, màn hình đứng.)
    _deleter(ctx, x, feetY, h, alpha, t) {
        const s = h / 380;
        ctx.save(); ctx.globalAlpha *= (alpha === undefined ? 1 : alpha);
        ctx.translate(x, feetY); ctx.scale(s, s);
        // hào quang đỏ
        const g = ctx.createRadialGradient(0, -190, 10, 0, -190, 240);
        g.addColorStop(0, 'rgba(255,40,70,0.38)'); g.addColorStop(1, 'rgba(255,40,70,0)');
        ctx.fillStyle = g; ctx.fillRect(-260, -440, 520, 470);
        const bob = Math.sin(t * 2) * 4;
        const body = (ox, tint) => {
            ctx.save(); ctx.translate(ox, bob);
            // áo choàng
            ctx.fillStyle = tint || '#12051a'; ctx.strokeStyle = '#ff3355'; ctx.lineWidth = 3; ctx.lineJoin = 'round';
            ctx.beginPath(); ctx.moveTo(-46, -250); ctx.lineTo(-96, -40); ctx.lineTo(-120, 0); ctx.lineTo(120, 0); ctx.lineTo(96, -40); ctx.lineTo(46, -250); ctx.closePath(); ctx.fill(); ctx.stroke();
            // tay dài buông thõng
            for (const d of [-1, 1]) {
                ctx.beginPath(); ctx.moveTo(d * 46, -240); ctx.quadraticCurveTo(d * 98, -170, d * 88, -64); ctx.lineTo(d * 70, -62); ctx.quadraticCurveTo(d * 74, -168, d * 38, -222); ctx.closePath(); ctx.fill(); ctx.stroke();
                ctx.fillStyle = '#ff3355'; ctx.beginPath(); ctx.arc(d * 79, -58, 9, 0, 6.283); ctx.fill(); ctx.fillStyle = tint || '#12051a';
            }
            // đầu = phím DEL
            const kg = ctx.createLinearGradient(0, -372, 0, -252); kg.addColorStop(0, '#3a3a46'); kg.addColorStop(1, '#14141a');
            ctx.fillStyle = kg; ctx.strokeStyle = '#ff3355'; ctx.lineWidth = 4;
            ctx.shadowColor = '#ff3355'; ctx.shadowBlur = 18;
            roundRect(ctx, -58, -372, 116, 112, 16); ctx.fill(); ctx.stroke();
            ctx.shadowBlur = 0;
            ctx.fillStyle = 'rgba(255,255,255,0.08)'; roundRect(ctx, -48, -364, 96, 38, 10); ctx.fill();
            ctx.fillStyle = '#ff3355'; ctx.font = '900 40px Impact, Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.fillText('DEL', 0, -314);
            ctx.restore();
        };
        body(0);
        // nhiễu glitch: vài dải ngang bị lệch + nhuộm đỏ
        const k = Math.floor(t * 9);
        for (let i = 0; i < 3; i++) {
            const r = Math.abs(Math.sin((k + i * 7) * 12.9898)), on = Math.sin(t * 5 + i * 2.1) > 0.35;
            if (!on) continue;
            const by = -380 + r * 340, bh = 14 + r * 26;
            ctx.save(); ctx.beginPath(); ctx.rect(-200, by, 400, bh); ctx.clip();
            body((r - 0.5) * 46, i % 2 ? '#3a0a18' : '#12051a'); ctx.restore();
        }
        // ô vuông đỏ "xoá" trôi quanh người
        ctx.fillStyle = 'rgba(255,51,85,0.75)';
        for (let i = 0; i < 7; i++) {
            const a = t * 0.9 + i * 0.9, px = Math.cos(a) * (110 + i * 9), py = -190 + Math.sin(a * 1.3) * 120, q = 5 + (i % 3) * 3;
            ctx.fillRect(px, py, q, q);
        }
        ctx.restore();
    }
    _crown(ctx, x, y, s) {
        ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
        ctx.shadowColor = '#ffd45a'; ctx.shadowBlur = 30;
        ctx.fillStyle = '#ffd45a'; ctx.strokeStyle = '#7a4c0c'; ctx.lineWidth = 4;
        ctx.beginPath(); ctx.moveTo(-60, 30); ctx.lineTo(-70, -30); ctx.lineTo(-32, 0); ctx.lineTo(0, -48); ctx.lineTo(32, 0); ctx.lineTo(70, -30); ctx.lineTo(60, 30); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#ff3c6e'; ctx.beginPath(); ctx.arc(0, 8, 8, 0, 6.283); ctx.fill();
        ctx.restore();
    }
    _throne(ctx, t, sc) {
        const cx = W / 2, sy = 520, K = 0.78, gold = sc.theme === 'gold';
        ctx.save(); ctx.translate(cx, sy); ctx.scale(K, K);
        const glow = gold ? '#ffd45a' : (sc.cracked ? '#ff3355' : '#7a6aff');
        ctx.shadowColor = glow; ctx.shadowBlur = 24 + Math.sin(t * 3) * 8;
        const g = ctx.createLinearGradient(0, -420, 0, 80); g.addColorStop(0, '#2a1d4a'); g.addColorStop(1, '#0a0618');
        ctx.fillStyle = g; ctx.strokeStyle = glow; ctx.lineWidth = 3;
        const back = [[-120, 0], [-120, -330], [-80, -300], [-60, -380], [-30, -320], [0, -420], [30, -320], [60, -380], [80, -300], [120, -330], [120, 0]];
        ctx.beginPath(); back.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)); ctx.closePath(); ctx.fill(); ctx.stroke();
        [[-150, 0, 300, 50], [-175, -70, 45, 130], [130, -70, 45, 130], [-260, 50, 520, 30], [-330, 80, 660, 36]].forEach(([x, y, w, h]) => { ctx.fillRect(x, y, w, h); ctx.strokeRect(x, y, w, h); });
        ctx.restore();
        this._crown(ctx, cx, sy - 420 * K - 70 + Math.sin(t * 2) * 10, 1.0);
        if (sc.cracked) {   // vết nứt chớp nháy từ ngai vàng
            const seed = Math.floor(t * 8);
            let s = seed * 9301 + 49297; const r = () => (s = (s * 9301 + 49297) % 233280) / 233280;
            ctx.save(); ctx.strokeStyle = '#ff5a7a'; ctx.shadowColor = '#ff3355'; ctx.shadowBlur = 18;
            for (let k = 0; k < 7; k++) {
                let x = cx + (r() - 0.5) * 120, y = sy - 80 - r() * 220, ang = r() * 6.283; ctx.lineWidth = 2 + r() * 3; ctx.beginPath(); ctx.moveTo(x, y);
                for (let n = 0; n < 9; n++) { ang += (r() - 0.5) * 1.6; x += Math.cos(ang) * 70; y += Math.sin(ang) * 70; ctx.lineTo(x, y); }
                ctx.stroke();
            }
            ctx.restore();
            ctx.fillStyle = `rgba(255,30,60,${0.06 + 0.05 * Math.sin(t * 9)})`; ctx.fillRect(0, 0, W, H);
        }
    }

    // ---- nhân vật ----
    _char(ctx, id, x, feetY, h, side, alpha) {
        const c = CHARS[id]; if (!c) return;
        if (id === 'ricardo') this._ricardo(ctx, x, feetY, h * 0.72, 'idle', alpha, false);
        else if (c.procedural === 'deleter') { if (typeof this._deleter === 'function') this._deleter(ctx, x, feetY, h, alpha, this.t); }
        else this._meme(ctx, c.skin, x, feetY, h, side === 'right', alpha);
    }
    _actors(ctx, sc, t) {
        const ease = x => 1 - Math.pow(1 - clamp(x, 0, 1), 3);
        if (sc.ricardo) {
            const r = sc.ricardo;
            if (sc.spot || sc.title) { ctx.save(); ctx.globalAlpha = 0.5; ctx.fillStyle = '#000'; ctx.beginPath(); ctx.ellipse(r.x * W, r.y + 8, 120, 16, 0, 0, 6.283); ctx.fill(); ctx.restore(); }
            this._ricardo(ctx, r.x * W, r.y, r.h * (r.sil ? 1 : (0.9 + 0.1 * ease(t / 0.6))), r.anim, clamp(t / 0.5, 0, 1), r.sil);
        }
        if (sc.cards) {
            const n = sc.cards.length;
            sc.cards.forEach((c, i) => {
                const p = ease((t - i * 0.5) / 0.6), x = W * (i + 1) / (n + 1), ch = CHARS[c.id];
                ctx.save(); ctx.translate(0, (1 - p) * 80);
                this._char(ctx, c.id, x, 520, 360, 'left', p);
                ctx.globalAlpha = p;
                this.e.ui.txt(ctx, c.name, x, 560, { size: 26, align: 'center', stroke: '#000', sw: 8, grad: ['#ffffff', ch ? ch.color : '#ffd45a'] });
                this.e.ui.txt(ctx, c.tag, x, 596, { font: 'text', size: 20, align: 'center', stroke: '#000', sw: 4, color: '#fff3c4' });
                ctx.restore();
            });
        }
        if (sc.lineup) {
            this.floatSkins.forEach((sk, i) => {
                const p = ease((t - i * 0.12) / 0.5), x = 110 + i * 150;
                this._meme(ctx, sk, x, 500 + Math.sin(t * 2 + i) * 6, 150 + (sk === 'lord' ? 50 : 0), false, p * 0.95);
            });
            this._crown(ctx, W / 2, 160 + Math.sin(t * 2) * 8, 1.5);
            this.e.ui.txt(ctx, 'MEME LORD', W / 2, 262, { size: 28, align: 'center', stroke: '#000', sw: 8, grad: ['#ffffff', '#ffd45a'] });
        }
        if (sc.shatter) {   // boss tan thành điểm ảnh
            const img = this._lordSnap || (this._lordSnap = Rig.snapshot(RIG_STYLES.lord, POSE0, 440, 420, 220, 410, 1.0, { k: 'idle_1' }));
            const IW = img.width, IH = img.height, h = 330, w = h * IW / IH, x0 = W * 0.7 - w / 2, y0 = 520 - h, strips = 48, sw = IW / strips;
            for (let s2 = 0; s2 < strips; s2++) {
                const rr = Math.abs(Math.sin(s2 * 91.7)), p = clamp((t - 0.25) / 1.6, 0, 1);
                ctx.save(); ctx.globalAlpha = clamp(1 - p * (0.8 + rr * 0.6), 0, 1);
                ctx.drawImage(img, s2 * sw, 0, sw, IH, x0 + s2 * (w / strips) + (rr - 0.5) * 160 * p, y0 - p * (80 + rr * 320), w / strips + 1, h);
                ctx.restore();
            }
        }
        // hội thoại: hai nhân vật đứng hai bên, người đang nói sáng hơn
        if (sc.left || sc.right) {
            const sp = sc.speaker;
            if (sc.left) this._char(ctx, sc.left, 300, 478, 380, 'left', sp === 'left' || !sc.right ? 1 : 0.5);
            if (sc.right) this._char(ctx, sc.right, W - 300, 478, 380, 'right', sp === 'right' ? 1 : 0.5);
        }
    }

    // ---- chữ ----
    _wrap(ctx, text, maxW) {
        const out = []; let cur = '';
        for (const w of text.split(' ')) {
            const test = cur ? cur + ' ' + w : w;
            if (ctx.measureText(test).width > maxW && cur) { out.push(cur); cur = w; } else cur = test;
        }
        if (cur) out.push(cur);
        return out;
    }
    _typed(ctx, lines, x, y, lh, o, align) {
        let n = Math.floor(this.typed);
        for (const ln of lines) {
            if (n <= 0) break;
            this.e.ui.txt(ctx, ln.slice(0, n), x, y, Object.assign({ align }, o));
            n -= ln.length + 1; y += lh;
        }
    }
    _text(ctx, sc, t) {
        const ui = this.e.ui;
        ctx.font = `bold 26px ${FONT_TEXT}`;
        if (sc.chapter) {
            const p = clamp(t / 0.7, 0, 1);
            ctx.save(); ctx.globalAlpha = p;
            ui.txt(ctx, sc.chapter.num, W / 2, 230, { size: 22, align: 'center', stroke: '#000', sw: 7, color: '#ffd45a' });
            ctx.fillStyle = '#d9a521'; const lw = 300 * p; ctx.fillRect(W / 2 - lw, 252, lw * 2, 3);
            ui.txt(ctx, sc.chapter.name, W / 2, 312 + (1 - p) * 20, { size: 42, align: 'center', stroke: '#2a0a0a', sw: 12, shadow: '#7a1020', grad: ['#ffffff', '#ffe27a', '#f59e0b'] });
            ctx.restore();
            if (sc.text) {
                ctx.font = `bold 24px ${FONT_TEXT}`;
                this._typed(ctx, this._wrap(ctx, sc.text, 900), W / 2, 400, 36, { font: 'text', size: 24, stroke: '#000', sw: 5, color: '#fff3c4' }, 'center');
            }
            return;
        }
        if (sc.title) {
            const p = clamp((t - 0.3) / 0.35, 0, 1), sl = 1 + (1 - p) * 2.2;
            ctx.save(); ctx.globalAlpha = p; ctx.translate(W / 2, 150); ctx.scale(sl, sl);
            ui.txt(ctx, sc.title.big, 0, 0, { size: sc.title.big.length > 12 ? 44 : 62, align: 'center', stroke: '#2a0a0a', sw: 14, shadow: '#7a1020', sx: 5, sy: 7, grad: ['#ffffff', '#ffe27a', '#f59e0b', '#c2410c'] });
            if (sc.title.small) ui.txt(ctx, sc.title.small, 0, 44, { size: 14, align: 'center', stroke: '#000', sw: 6, color: '#fff3c4' });
            ctx.restore();
            if (sc.text) { ctx.font = `bold 24px ${FONT_TEXT}`; this._typed(ctx, this._wrap(ctx, sc.text, 960), W / 2, H - 120, 34, { font: 'text', size: 24, stroke: '#000', sw: 5, color: '#fff3c4' }, 'center'); }
            return;
        }
        if (!sc.text) return;
        if (sc.big) {   // câu ngắn đập thẳng vào mặt
            const p = clamp(t / 0.25, 0, 1), sl = 1 + (1 - p) * 1.6;
            ctx.save(); ctx.globalAlpha = p; ctx.translate(W / 2, sc.ricardo ? H - 150 : H / 2 + 12); ctx.scale(sl, sl);
            ui.txt(ctx, sc.text, 0, 0, { size: sc.text.length > 22 ? 30 : 42, align: 'center', stroke: '#000', sw: 10, grad: ['#ffffff', '#ffd45a'] });
            ctx.restore();
            return;
        }
        if (sc.speaker) {   // hộp hội thoại
            const bx = 110, by = H - 64 - 196, bw = 1060, bh = 176;
            const side = sc.speaker, who = side === 'sys' ? 'sys' : (side === 'left' ? sc.left : sc.right), ch = CHARS[who] || CHARS.sys;
            ui.frame(ctx, bx, by, bw, bh, { fillTop: '#2a1f45', fillBot: '#0c0916' });
            ui.frame(ctx, bx + 24, by - 30, 330, 40, { noStuds: true, fillTop: '#3b2a63', fillBot: '#150f26' });
            ui.txt(ctx, ch.name, bx + 189, by - 2, { size: 13, align: 'center', stroke: '#000', sw: 5, color: ch.color });
            ctx.font = `bold 25px ${FONT_TEXT}`;
            this._typed(ctx, this._wrap(ctx, sc.text, bw - 80), bx + 40, by + 52, 36, { font: 'text', size: 25, stroke: '#000', sw: 4, color: side === 'sys' ? '#bae6fd' : '#ffffff' }, 'left');
            if (this.typed >= this.textLen && Math.floor(ui.time * 3) % 2 === 0) ui.txt(ctx, '\u25BC', bx + bw - 40, by + bh - 20, { font: 'text', size: 18, color: '#ffd45a' });
            return;
        }
        // chữ dẫn truyện ở giữa phần dưới màn hình
        const g = ctx.createLinearGradient(0, H - 280, 0, H - 64);
        g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.4, 'rgba(0,0,0,0.7)'); g.addColorStop(1, 'rgba(0,0,0,0.88)');
        ctx.fillStyle = g; ctx.fillRect(0, H - 280, W, 216);
        ctx.font = `bold 28px ${FONT_TEXT}`;
        const lines = this._wrap(ctx, sc.text, 980), y0 = H - 64 - 26 - (lines.length - 1) * 42;
        this._typed(ctx, lines, W / 2, y0, 42, { font: 'text', size: 28, stroke: '#000', sw: 6, grad: ['#ffffff', '#fff3c4'] }, 'center');
    }
}


function rigHeight(st) { return ((st.thigh + st.shin) * 0.98 + st.torso + st.neck + st.headSize) * st.scale; }
Object.assign(CutsceneManager.prototype, {
    _floaters(ctx, t) {      // các khuôn mặt meme trôi lơ lửng
        const keys = ['troll', 'chad', 'doge_full', 'npc', 'disco', 'sigma'];
        keys.forEach((k, i) => {
            const img = Heads.get(k); if (!img) return;
            const h = 90 + (i % 3) * 45, w = h * img.naturalWidth / img.naturalHeight;
            const x = ((i * 211 + t * (14 + i * 4)) % (W + 400)) - 200, y = 120 + (i * 83) % 380 + Math.sin(t * 0.8 + i) * 18;
            ctx.save(); ctx.globalAlpha = 0.4; ctx.translate(x, y); ctx.rotate(Math.sin(t * 0.5 + i) * 0.2);
            ctx.drawImage(img, -w / 2, -h / 2, w, h); ctx.restore();
        });
    },
    _ricardo(ctx, x, feetY, h, anim, alpha, sil) {
        const st = RIG_STYLES.ricardo, t = this.t, k = (h * 1.08) / rigHeight(st);
        ctx.save(); ctx.globalAlpha = alpha;
        if (sil && 'filter' in ctx) ctx.filter = 'brightness(0)';
        Rig.render(ctx, st, anim === 'dance' ? dancePose(t) : idlePose(t), { x, y: feetY, facing: 1, scale: k, t, aura: anim === 'dance' && !sil ? '#ffd45a' : null, spr: anim === 'dance' ? RicardoSprite.dance(t) : RicardoSprite.idle(t) });
        ctx.restore();
    },
    _meme(ctx, skin, x, feetY, h, flip, alpha) {
        const id = { trollskel: 'troll', trolldemon: 'lord', bigdoge: 'doge' }[skin] || skin;
        ctx.save(); ctx.globalAlpha = alpha; ctx.shadowColor = 'rgba(0,0,0,0.6)'; ctx.shadowBlur = 20;
        if (id === 'doge') DogePuppet.draw(ctx, { by: -Math.abs(Math.sin(this.t * 4)) * 2 }, { x, y: feetY, facing: flip ? -1 : 1, h: h * 0.95 });
        else if (RIG_STYLES[id]) {
            const st = RIG_STYLES[id], k = (h * 1.0) / rigHeight(st);
            Rig.render(ctx, st, id === 'lord' ? POSE0 : idlePose(this.t), { x, y: feetY, facing: flip ? -1 : 1, scale: k, t: this.t, spr: id === 'chad' ? ChadSprite.idle(this.t) : (id === 'lord' ? LordSprite.idle(this.t) : undefined) });
        }
        ctx.restore();
    }
});

// ============================================================
// FLOOR PROGRESSION + DIFFICULTY
// ============================================================
const DIFFICULTIES = {
    easy:   { label: 'EASY',   hp: 0.78, damage: 0.72, speed: 0.84, ai: 0.58, tell: 1.35, cooldown: 1.35 },
    normal: { label: 'NORMAL', hp: 1.00, damage: 1.00, speed: 1.00, ai: 1.00, tell: 1.00, cooldown: 1.00 },
    hard:   { label: 'HARD',   hp: 1.30, damage: 1.24, speed: 1.16, ai: 1.38, tell: 0.78, cooldown: 0.72 }
};
const FLOOR_SKILLS = [
    null,
    { name: 'BASIC ATTACK', icon: 'sword', desc: 'Quái chỉ sử dụng đòn đánh cơ bản.', tip: 'Giữ khoảng cách và canh thời điểm đỡ đòn.' },
    { name: 'DASH BREAKER', icon: 'dash', desc: 'Quái hạ thấp trọng tâm rồi lao nhanh về phía Ricardo.', tip: 'Nhảy qua đầu hoặc lướt né sang phía sau.' },
    { name: 'PIXEL SHOCKWAVE', icon: 'wave', desc: 'Cú dậm đất phóng sóng gai pixel chạy sát mặt đất.', tip: 'Nhảy lên đúng lúc để tránh sóng.' },
    { name: 'ENERGY ORB', icon: 'star', desc: 'Quái tích tụ năng lượng rồi bắn cầu đạn đuổi theo hướng người chơi.', tip: 'Di chuyển ngang hoặc đỡ đòn đúng nhịp.' },
    { name: 'RUNE STRIKE', icon: 'target', desc: 'Một vòng rune khóa vị trí rồi cột năng lượng giáng xuống.', tip: 'Rời khỏi vòng cảnh báo trước khi nó phát nổ.' },
    { name: 'TRIPLE VOLLEY', icon: 'star', desc: 'Quái bắn liên tiếp ba luồng đạn theo góc quạt.', tip: 'Lách qua khe đạn hoặc áp sát khi quái đang niệm.' },
    { name: 'AFTERIMAGE FEINT', icon: 'dash', desc: 'Quái giả vờ lao tới rồi đổi nhịp, tung đòn ở vị trí mới.', tip: 'Đừng phản công quá sớm; chờ cú lao kết thúc.' },
    { name: 'GROUND SNARE', icon: 'shield', desc: 'Quái ném bẫy pixel xuống mặt đất, gây choáng nếu đứng trên đó.', tip: 'Quan sát mặt đất và đổi vị trí liên tục.' },
    { name: 'METEOR MARK', icon: 'target', desc: 'Dấu ngắm xuất hiện dưới chân Ricardo trước khi thiên thạch rơi.', tip: 'Di chuyển khỏi dấu ngắm ngay khi thấy cảnh báo.' },
    { name: 'HELLFIRE GRID', icon: 'star', desc: 'Boss/quái tinh nhuệ gọi nhiều cột năng lượng theo chuỗi.', tip: 'Đọc thứ tự vòng rune và tìm vùng an toàn.' }
];

// ============================================================
// GAME MODE MANAGER
// ============================================================
class GameModeManager {
    constructor() {
        this.mode = 'menu'; // 'menu', 'difficulty', 'story', 'arcade', 'survival', 'pause', 'gameover', 'victory'
        this.difficulty = (() => { try { return DIFFICULTIES[localStorage.getItem('ricardoDifficulty')] ? localStorage.getItem('ricardoDifficulty') : 'normal'; } catch (_) { return 'normal'; } })();
        this.difficultyIndex = ['easy', 'normal', 'hard'].indexOf(this.difficulty); this.pendingPlayMode = 'story'; this.currentFloor = 1;
        this.selectedMenuIndex = 0;
        this.menuOptions = ['CHƠI CỐT TRUYỆN', 'ARCADE ĐỐI KHÁNG', 'SINH TỒN (SURVIVAL)', 'CHỌN NHÂN VẬT', 'XEM LẠI CỐT TRUYỆN', 'HƯỚNG DẪN & COMBO', 'CÀI ĐẶT NHẠC & ÂM THANH', 'BẢNG XẾP HẠNG ONLINE'];
        // Story mode state
        this.currentZoneIndex = 0;
        this.currentWave = 1;
        this.maxWaves = 3;
        this.waveTimer = 0;
        // Arcade mode state
        this.arcadeRound = 1;
        this.playerRoundsWon = 0;
        this.enemyRoundsWon = 0;
        this.arcadeTimer = 99;
        // Survival mode state
        this.survivalWave = 1;
        this.survivalScore = 0;
        this.survivalTimer = 0;
        this.reviveUsed = false;      // ETERNAL DANCE khi chết: chỉ 1 lần mỗi lượt chơi
    }
    startStory(zoneIdx = 0) {
        this.mode = 'story'; this.reviveUsed = false;
        this.currentZoneIndex = zoneIdx;
        this.currentWave = 1;
        this.waveTimer = 0;
    }
    startArcade() {
        this.mode = 'arcade'; this.reviveUsed = false;
        this.arcadeRound = 1;
        this.playerRoundsWon = 0;
        this.enemyRoundsWon = 0;
        this.arcadeTimer = 99;
    }
    startSurvival() {
        this.mode = 'survival'; this.reviveUsed = false;
        this.survivalWave = 1;
        this.survivalScore = 0;
        this.survivalTimer = 0;
    }
}

// ============================================================
// MAIN GAME ENGINE
// ============================================================
class GameEngine {
    constructor() {
        this.canvas = document.getElementById('game');
        this.ctx = this.canvas.getContext('2d');
        this.input = new InputManager();
        this.audio = new AudioManager();
        this.camera = new Camera();
        this.particles = new ParticleSystem(500);
        this.floatText = new FloatingTextSystem();
        this.map = new MapManager();
        this.player = new Player();
        this.fx = new FxSystem();
        this.enemyManager = new EnemyManager();
        this.combat = new CombatSystem();
        this.ui = new UIManager();
        this.ui.engine = this;
        this.ui.audio = this.audio;
        this.cutscene = new CutsceneManager(this);
        this.storyIntroPlayed = false;
        this.seenChapters = new Set();
        this.eternalUsed = false;
        this.endTimer = null;
        this.portal = null;           // cổng dịch chuyển sau khi dọn sạch màn
        this.entrance = null;         // cảnh Ricardo giáng thế từ trên trời khi vào màn mới
        if (PXFX) PXFX.init();
        this.audio.onNowPlaying = name => this.ui.toast('\u266A ' + name, 3.2);
        this.audio.onNotice = msg => this.ui.toast(msg, 4);
        this.modes = new GameModeManager();
        this.lastTime = 0;
        this.paused = false;
        this.timeScale = 1; this.hitStopT = 0; this.slowMoT = 0; this.camZoom = 1; this.camZoomTarget = 1; this.flashA = 0; this.groundY = GROUND_Y;

        this._loadSprites();
        this._bindEvents();
        this._initAudioUnlock();
    }
    _loadSprites() {
        // Ảnh đầu meme (cắt từ ảnh bạn cung cấp). Thiếu file -> dùng hình dự phòng, không làm game crash.
        RicardoSprite.load(); ChadSprite.load(); LordSprite.load();
        Heads.load('assets/heads/', ['ricardo', 'ricardo_side', 'ricardo_hurt', 'chad', 'lord', 'troll', 'doge_full', 'npc', 'disco', 'sigma', 'rp_head', 'rp_torso', 'rp_armBu', 'rp_armBf', 'rp_armFu', 'rp_armFf', 'rp_legBt', 'rp_legBs', 'rp_legFt', 'rp_legFs', 'tp_head', 'tp_torso', 'tp_armBu', 'tp_armBf', 'tp_armFu', 'tp_armFf', 'tp_legBt', 'tp_legBs', 'tp_legFt', 'tp_legFs', 'wk_head', 'wk_torso', 'wk_armBu', 'wk_armBf', 'wk_armFu', 'wk_armFf', 'wk_legBt', 'wk_legBs', 'wk_legFt', 'wk_legFs', 'dc_head', 'dc_torso', 'dc_armBu', 'dc_armBf', 'dc_armFu', 'dc_armFf', 'dc_legBt', 'dc_legBs', 'dc_legFt', 'dc_legFs', 'sg_head', 'sg_torso', 'sg_armBu', 'sg_armBf', 'sg_armFu', 'sg_armFf', 'sg_legBt', 'sg_legBs', 'sg_legFt', 'sg_legFs']);
    }
    // ---- API 'world' cho Player / Combat ----
    hitStop(t) { this.hitStopT = Math.max(this.hitStopT, t); }
    flash(a) { this.flashA = Math.max(this.flashA, a); }
    slowMo(dur, scale) { this.slowMoT = dur; this.timeScale = scale; }
    addWave(o) { this.combat.addWave(o); }
    banner(text, sub, dur, color, big) { this.ui.bigBanner(text, sub, dur, color, big); }
    _bindEvents() {
        window.addEventListener('keydown', e => {
            if (e.repeat) return;
            const k = keyId(e);
            this._gesture();        // trình duyệt chỉ cho phát âm thanh sau thao tác đầu tiên
            const ui = this.ui, mode = this.modes.mode;
            if (ui.showSettings) { this._settingsKey(k); return; }
            if (ui.showControlsOverlay) { if (k === 'escape' || k === 'f1' || k === '/' || k === 'enter') ui.showControlsOverlay = false; return; }
            if (this.cutscene.active && k !== 'm' && k !== 'n') { this.cutscene.key(k); return; }
            if (k === 'm') ui.toast(this.audio.toggleMusic() ? 'Nhạc: TẮT' : 'Nhạc: BẬT', 1.6);       // M: bật/tắt nhạc nền
            if (k === 'n' && !this.paused && ['menu', 'story', 'arcade', 'survival'].includes(mode)) {
                if (!this.audio.nextTrack()) ui.toast('Chỉ có một bài nhạc — thêm file vào assets/music/', 3.2);
            }
            if (k === 'f1' || k === '/') { ui.showControlsOverlay = true; return; }
            const playing = mode === 'story' || mode === 'arcade' || mode === 'survival';
            const dlgNav = () => {      // điều hướng hộp thoại (Pause / Game Over / Victory)
                const n = ui.dlgButtons.length || 1;
                if (k === 'arrowup' || k === 'w') { ui.dlgIdx = (ui.dlgIdx + n - 1) % n; this.audio.playMenuSelect(); }
                else if (k === 'arrowdown' || k === 's') { ui.dlgIdx = (ui.dlgIdx + 1) % n; this.audio.playMenuSelect(); }
                else if (k === 'enter') { const b = ui.dlgButtons[ui.dlgIdx]; if (b && b.enabled !== false) { this.audio.playMenuConfirm(); b.onClick(); } }
            };
            if (playing) {
                if (k === 'escape') this.togglePause();
                else if (this.paused) { if (k === 't') { ui.showSettings = true; ui.settingsRow = 0; } else dlgNav(); }
            } else if (mode === 'difficulty') {
                if (k === 'arrowleft' || k === 'a') { this.modes.difficultyIndex = (this.modes.difficultyIndex + 2) % 3; this.audio.playMenuSelect(); }
                else if (k === 'arrowright' || k === 'd') { this.modes.difficultyIndex = (this.modes.difficultyIndex + 1) % 3; this.audio.playMenuSelect(); }
                else if (k === 'enter') { this.audio.playMenuConfirm(); this._confirmDifficulty(this.modes.difficultyIndex); }
                else if (k === 'escape') this.modes.mode = 'menu';
            } else if (mode === 'menu') {
                const n = this.modes.menuOptions.length;
                if (k === 'arrowup' || k === 'w') { this.modes.selectedMenuIndex = (this.modes.selectedMenuIndex + n - 1) % n; this.audio.playMenuSelect(); }
                else if (k === 'arrowdown' || k === 's') { this.modes.selectedMenuIndex = (this.modes.selectedMenuIndex + 1) % n; this.audio.playMenuSelect(); }
                else if (k === 'enter') { this.audio.playMenuConfirm(); this._selectMenuItem(this.modes.selectedMenuIndex); }
            } else if (mode === 'charselect') {
                const i = CHAR_ORDER.indexOf(ui.selectedChar);
                if (k === 'arrowright' || k === 'd') { ui.selectedChar = CHAR_ORDER[(i + 1) % CHAR_ORDER.length]; this.audio.playMenuSelect(); }
                else if (k === 'arrowleft' || k === 'a') { ui.selectedChar = CHAR_ORDER[(i + CHAR_ORDER.length - 1) % CHAR_ORDER.length]; this.audio.playMenuSelect(); }
                else if (k === 'arrowdown' || k === 's') { ui.selectedChar = CHAR_ORDER[(i + 4) % CHAR_ORDER.length]; this.audio.playMenuSelect(); }
                else if (k === 'arrowup' || k === 'w') { ui.selectedChar = CHAR_ORDER[(i + 4) % CHAR_ORDER.length]; this.audio.playMenuSelect(); }
                else if (k === 'enter') { if (CHAR_INFO[ui.selectedChar].playable) { this.audio.playMenuConfirm(); this._startFromCharSelect(); } else this.audio.playDeny(); }
                else if (k === 'escape') this._backToMenu();
            } else if (mode === 'gameover' || mode === 'victory') {
                if (k === 'escape') this.toMenu(); else dlgNav();
            }
        });

        this._bindMouse();
    }
    _initAudioUnlock() {
        // Autoplay policy: nhạc bắt đầu ở lần click / nhấn phím / chạm đầu tiên của người chơi
        const g = () => this._gesture();
        window.addEventListener('pointerdown', g);      // phím đã được xử lý trong trình nghe phím chính
    }
    _gesture() {
        this.audio.unlock(); this.audio.resumePending();
        if (!this._musicStarted) {
            this._musicStarted = true;
            this.audio.startBGM(this.modes.mode === 'menu' ? 'menu' : (this.audio.currentTrack !== null && this.audio.currentTrack !== undefined ? this.audio.currentTrack : 0));
        }
    }
    _closeSettings() { this.ui.showSettings = false; }      // nhạc vẫn phát liên tục khi mở / đóng cài đặt
    _pickMusicFiles() {
        if (!this._picker) {
            const inp = document.createElement('input');
            inp.type = 'file'; inp.accept = 'audio/*,.mp3,.ogg,.wav,.m4a'; inp.multiple = true; inp.style.display = 'none';
            document.body.appendChild(inp);
            inp.addEventListener('change', () => {
                const n = this.audio.addFiles(inp.files);
                this.ui.toast(n ? `Đã thêm ${n} bài (chỉ trong phiên này — muốn giữ lâu hãy bỏ vào assets/music/)` : 'Không có file nhạc hợp lệ', 4);
                inp.value = '';
            });
            this._picker = inp;
        }
        this._picker.click();
    }
    // Hàng cài đặt: 0 nhạc bật/tắt · 1 âm lượng nhạc · 2 bài sảnh · 3 bài trận · 4 âm lượng hiệu ứng · 5 hiệu ứng bật/tắt · 6 thêm nhạc · 7 đóng
    _settingsAct(row, dir) {
        const A = this.audio, S = A.settings, inMenu = this.modes.mode === 'menu';
        switch (row) {
            case 0: A.toggleMusic(); break;
            case 1: if (dir) A.setVolume('volMusic', S.volMusic + dir * 0.1); break;
            case 2: if (dir) { A.cycle('menu', dir); if (inMenu) A.startBGM('menu'); } break;
            case 3: if (dir) { A.cycle('game', dir); if (!inMenu && A.currentTrack !== null) A.startBGM(A.currentTrack); } break;
            case 4: if (dir) { A.setVolume('volSfx', S.volSfx + dir * 0.1); A.playHit(1.2); } break;
            case 5: A.toggleSfx(); break;
            case 6: this._pickMusicFiles(); break;
            case 7: this._closeSettings(); break;
        }
    }
    _settingsKey(k) {
        const u = this.ui, A = this.audio, rows = 8;
        if (k === 'escape') { this._closeSettings(); return; }
        if (k === 'arrowup' || k === 'w') { u.settingsRow = (u.settingsRow + rows - 1) % rows; A.playMenuSelect(); }
        else if (k === 'arrowdown' || k === 's') { u.settingsRow = (u.settingsRow + 1) % rows; A.playMenuSelect(); }
        else if (['arrowleft', 'a', 'arrowright', 'd'].includes(k)) { this._settingsAct(u.settingsRow, (k === 'arrowright' || k === 'd') ? 1 : -1); A.playMenuSelect(); }
        else if (k === 'enter') { A.playMenuConfirm(); this._settingsAct(u.settingsRow, 0); }
    }
    // ---- menu / chọn nhân vật / pause / chơi lại ----
    _menuClick(i) { this.modes.selectedMenuIndex = i; this._selectMenuItem(i); }
    _selectMenuItem(index) {
        switch (index) {
            case 0: this._beginDifficulty('story'); break;
            case 1: this._beginDifficulty('arcade'); break;
            case 2: this._beginDifficulty('survival'); break;
            case 3: this.ui.selectedChar = 'ricardo'; this.modes.mode = 'charselect'; break;
            case 4: this.cutscene.play(STORY.prologue, () => {}); break;
            case 5: this.ui.showControlsOverlay = true; break;
            case 6: this.ui.showSettings = true; this.ui.settingsRow = 0; break;
            case 7: if (window.MemeLeaderboard) window.MemeLeaderboard.showLeaderboard('ALL'); break;
        }
    }
    _beginDifficulty(playMode) { this.modes.pendingPlayMode = playMode; this.modes.difficultyIndex = ['easy', 'normal', 'hard'].indexOf(this.modes.difficulty); this.modes.mode = 'difficulty'; }
    _confirmDifficulty(index) {
        if (window.MemeLeaderboard && !window.MemeLeaderboard.requirePlayer(() => this._confirmDifficulty(index))) return;
        const id = ['easy', 'normal', 'hard'][clamp(index, 0, 2)];
        this.modes.difficulty = id; this.modes.difficultyIndex = ['easy', 'normal', 'hard'].indexOf(id);
        try { localStorage.setItem('ricardoDifficulty', id); } catch (_) {}
        const mode = this.modes.pendingPlayMode || 'story';
        if (window.MemeLeaderboard) window.MemeLeaderboard.beginRun(id, mode);
        this.enemyManager.setProgression(1, id);
        if (mode === 'story') { this.playMode = 'story'; this.modes.startStory(0); this._enterZone(0, !this.storyIntroPlayed); this.storyIntroPlayed = true; }
        else if (mode === 'arcade') { this.playMode = 'arcade'; this.modes.startArcade(); this.initArcadeRound(); }
        else { this.playMode = 'survival'; this.modes.startSurvival(); this.initSurvivalWave(); }
    }
    _startFromCharSelect() { this._beginDifficulty('story'); }
    _backToMenu() { this.modes.mode = 'menu'; this.audio.startBGM('menu'); }
    togglePause() {
        if (!['story', 'arcade', 'survival'].includes(this.modes.mode)) return;
        this.paused = !this.paused; this.audio.playPause(this.paused); this.ui.dlgIdx = 0;
    }
    restartCurrent() {
        this.paused = false;
        if (window.MemeLeaderboard) window.MemeLeaderboard.beginRun(this.modes.difficulty, this.playMode || 'story');
        if (this.modes.mode === 'story') { this.modes.startStory(this.modes.currentZoneIndex); this._enterZone(this.modes.currentZoneIndex, false); }
        else if (this.modes.mode === 'arcade') { this.modes.startArcade(); this.initArcadeRound(); }
        else if (this.modes.mode === 'survival') { this.modes.startSurvival(); this.initSurvivalWave(); }
    }
    toMenu() {
        this.paused = false; this.cutscene.active = false; this.modes.mode = 'menu'; this.ui.dlgIdx = 0; this.ui.showSettings = false;
        this.timeScale = 1; this.camZoom = this.camZoomTarget = 1; this.flashA = 0; this.audio.duck(1);
        this.audio.startBGM('menu'); // Trở về sảnh: phát lại Multifandom_Dancin.mp3
    }
    _retry() {
        this.ui.dlgIdx = 0;
        if (window.MemeLeaderboard) window.MemeLeaderboard.beginRun(this.modes.difficulty, this.playMode || 'story');
        if (this.modes.mode === 'victory' && this.playMode === 'story' && this.modes.currentZoneIndex < 3) { this.modes.startStory(this.modes.currentZoneIndex + 1); this._enterZone(this.modes.currentZoneIndex, false); }
        else if (this.playMode === 'arcade') { this.modes.startArcade(); this.initArcadeRound(); }
        else if (this.playMode === 'survival') { this.modes.startSurvival(); this.initSurvivalWave(); }
        else { this.playMode = 'story'; this.modes.startStory(0); this._enterZone(0, false); }
    }
    // ---- chuột / cảm ứng ----
    _bindMouse() {
        const c = this.canvas, ui = this.ui;
        const pos = (e) => { const r = c.getBoundingClientRect(); const t = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e; return { x: (t.clientX - r.left) * (W / r.width), y: (t.clientY - r.top) * (H / r.height) }; };
        const hit = (x, y) => { for (let i = ui.btns.length - 1; i >= 0; i--) { const b = ui.btns[i]; if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) return b; } return null; };
        const down = (e) => {
            this._gesture(); const p = pos(e); ui.mouse.x = p.x; ui.mouse.y = p.y; ui.mouse.down = true; ui.mouse.moved = true;
            const b = hit(p.x, p.y); ui.pressedId = b ? b.id : null;
            if (b && b.enabled && b.drag && b.onClickAt) { ui.dragBtn = b; b.onClickAt(p.x, p.y); }
        };
        const move = (e) => { const p = pos(e); ui.mouse.x = p.x; ui.mouse.y = p.y; ui.mouse.moved = true; if (ui.dragBtn && ui.dragBtn.onClickAt) ui.dragBtn.onClickAt(p.x, p.y); };
        const up = (e) => {
            ui.dragBtn = null; ui.mouse.down = false; const p = pos(e); const b = hit(p.x, p.y);
            if (b && b.enabled && b.id === ui.pressedId && !b.drag && b.onClick) { this.audio.playMenuConfirm(); b.onClick(); }
            ui.pressedId = null;
        };
        c.addEventListener('mousedown', e => { if (e.button === 0) down(e); });
        c.addEventListener('mousemove', move);
        window.addEventListener('mouseup', e => { if (e.button === 0) up(e); });
        c.addEventListener('mouseleave', () => { ui.mouse.x = -1; ui.mouse.y = -1; });
        c.addEventListener('touchstart', e => { down(e); e.preventDefault(); }, { passive: false });
        c.addEventListener('touchmove', e => { move(e); e.preventDefault(); }, { passive: false });
        c.addEventListener('touchend', e => { up(e); ui.mouse.x = -1; ui.mouse.y = -1; e.preventDefault(); }, { passive: false });
        c.addEventListener('contextmenu', e => e.preventDefault());
    }
    // Vào một màn Story: dựng cảnh, phát phim (prologue nếu cần + thẻ chương + hội thoại), xong mới báo tên màn
    _enterZone(idx, prologue) {
        const a = this.ui.audio; this.ui.audio = null;      // tránh tiếng cồng "MÀN" trùng với phim
        this.initZone(idx);
        this.ui.audio = a; this.ui.announcementTimer = 0;
        this.camera.x = 0; this.camera.targetX = 0;
        this.eternalUsed = false; this.endTimer = null;
        const full = !this.seenChapters.has(idx);
        this.seenChapters.add(idx);
        let scenes = prologue ? STORY.prologue.slice() : [];
        scenes = scenes.concat(chapterScenes(idx, full));
        if (prologue) this.audio.startBGM('menu');
        this.cutscene.play(scenes, () => {
            this.audio.startBGM(idx);
            this._startEntrance(idx);        // Ricardo giáng thế từ trên trời; tên màn hiện ra ở khoảnh khắc chạm đất
        });
    }
    // =====================================================================
    // RA MẮT KHI VÀO MÀN: cột sáng báo hiệu -> Ricardo lao từ trên trời xuống như sao băng -> đạp đất nổ tung
    // -> gồng khí tức (3 nhịp xung năng lượng) -> BÙNG NỔ KHÍ TỨC rồi mới trả quyền điều khiển cho người chơi
    // =====================================================================
    _startEntrance(zoneIdx) {
        const pl = this.player, gy = this.map.getGroundY(), F = pfx(), lx = pl.x + pl.w / 2;
        this.entrance = { t: 0, phase: 'warn', zone: zoneIdx, lx, gy, topY: -pl.h - 140, landY: gy - pl.h, ct: 0, pulses: 0, burst: false, power: 0, dim: 0 };
        pl.hidden = true; pl.y = this.entrance.topY; pl.vx = pl.vy = 0; pl.state = 'jump'; pl.facingRight = true; pl.blocking = false; pl.invulnTimer = 6;
        pl.entr = { spr: { k: 'jump_1', sx: 0.92, sy: 1.12 } };
        this.enemyManager.projectiles.length = 0;
        this.audio.playCine('riser');
        if (F) {
            F.mark(lx, gy, 0.55, '#ffd45a');
            F.circle(lx, gy, 380, 1.0, '#ffd45a', '#ffffff', { grow: 0.5, fade: 0.3, spin: 3 });
            F.pillar(lx, gy, 80, gy + 40, 0.62, '#ffd45a', '#ff9ad5');
        }
    }
    _updateEntrance(dt) {
        const E = this.entrance, pl = this.player, F = pfx(), cx = E.lx, g = E.gy, FALL_AT = 0.55, FALL_DUR = 0.4;
        E.t += dt; pl.t += dt; pl.vx = pl.vy = 0; pl.facingRight = true;
        const COLS = ['#ffffff', '#ffd45a', '#ff9ad5', '#7dd3fc'];
        if (E.phase === 'warn') {
            E.dim = Math.min(1, E.t / 0.45);
            if (!E._rum || E.t - E._rum > 0.08) { E._rum = E.t; this.camera.shake(3 + E.t * 9, 0.1); }
            if (F && Math.random() < 0.7) F.sparks(cx + rand(-130, 130), g - 4, 2, { col: ['#ffffff', '#ffd45a'], angle: -Math.PI / 2, cone: 0.5, min: 90, max: 300, g: -80, life: 0.6 });
            if (E.t >= FALL_AT) { E.phase = 'fall'; pl.hidden = false; this.audio.playCine('whoosh'); }
        }
        if (E.phase === 'fall') {
            const u = clamp((E.t - FALL_AT) / FALL_DUR, 0, 1);
            pl.y = lerp(E.topY, E.landY, u * u);
            pl.entr.spr = { k: 'jump_1', sx: 0.9, sy: 1.14 };
            if (F) F.sparks(cx, pl.y + pl.h * 0.45, 5, { col: COLS, angle: -Math.PI / 2, cone: 0.55, min: 80, max: 340, g: 0, life: 0.35, sx: 46 });
            if (u >= 1) this._entranceImpact();
            return;
        }
        // ---- phase 'charge': đã chạm đất ----
        E.ct += dt; const ct = E.ct, cy = pl.y + pl.h * 0.5;
        E.power = ct < 0.25 ? 0.55 : lerp(0.7, 1.25, clamp((ct - 0.25) / 0.75, 0, 1));
        if (!E.burst) {
            pl.entr.spr = ct < 0.25 ? { k: 'jump_2', sx: 1.08, sy: 0.9 } : { k: 'skill_0', sx: 1.04, sy: 1.04, by: Math.sin(pl.t * 50) * 1.2 };
            if (ct >= 0.25 + E.pulses * 0.25 && E.pulses < 3) {      // 3 nhịp gồng khí: vòng xung + hút năng lượng về thân
                const col = ['#ffd45a', '#ff9ad5', '#7dd3fc'][E.pulses]; E.pulses++;
                this.fx.ring(cx, cy, { r0: 20, r1: 150 + E.pulses * 70, life: 0.45, color: col, w: 7 });
                this.camera.shake(8 + E.pulses * 3, 0.15);
                if (F) { F.ring(cx, cy, 30, 220 + E.pulses * 70, 0.5, col, { n: 40 }); F.implode(cx, cy, 300, COLS, 26, 0.35); }
                this.particles.energyBurst(cx, cy, col);
            }
            if (F && Math.random() < 0.9) F.sparks(cx + rand(-34, 34), cy + rand(-10, 60), 2, { col: ['#fff7c2', '#ffd45a', '#ff9ad5'], angle: -Math.PI / 2, cone: 0.5, min: 120, max: 420, g: -120, life: 0.6 });
            if (ct >= 1.0) this._entranceBurst(cx, cy, g);
        } else {
            pl.entr.spr = { k: 'attack_1', sx: 1.1, sy: 1.1 };
        }
        if (ct >= 1.5) {
            this.entrance = null; pl.entr = null; pl.state = 'idle'; pl.auraT = 2.2; pl.invulnTimer = 1.2; pl.landT = 0; pl.hidden = false;
        }
    }
    _entranceImpact() {
        const E = this.entrance, pl = this.player, F = pfx(), cx = E.lx, g = E.gy; E.phase = 'charge'; E.ct = 0;
        pl.y = E.landY; pl.grounded = true; pl.state = 'idle';
        const cy = pl.y + pl.h * 0.5, GOLD = ['#ffffff', '#ffd45a', '#fb923c', '#ff9ad5'];
        this.flash(1); this.camera.shake(46, 1.0); this.hitStop(0.12); this.audio.playBigImpact(); this.audio.playCine('gong');
        this.fx.shock(cx, g, { r1: 760, life: 0.8, color: '#ffd45a' }); this.fx.shock(cx, g, { r1: 480, life: 0.6, color: '#ff6ec7' });
        this.fx.comic(cx, g - 230, 'BOOM!', { size: 56, color: '#ffd45a', life: 0.9 }); this.fx.star(cx, g - 30, { r: 150, life: 0.4, color: '#ffffff' });
        this.particles.dust(cx - 40, g); this.particles.dust(cx + 40, g);
        for (const c of GOLD) this.particles.energyBurst(cx, cy, c);
        if (F) {
            F.groundBlast(cx, g, 560, GOLD);
            F.pillar(cx, g, 240, 820, 1.2, '#ffd45a', '#ff9ad5');
            F.circle(cx, g, 720, 1.6, '#ffd45a', '#ffffff', { grow: 0.2, fade: 0.4, spin: 2 });
            F.ring(cx, cy, 20, 700, 0.7, '#ffffff', { n: 72 }); F.ring(cx, g, 10, 760, 0.8, '#ffd45a', { sq: 0.28, n: 80 });
            F.sparks(cx, g - 20, 80, { col: ['#ffd45a', '#fb923c', '#a16207', '#ffffff'], angle: -Math.PI / 2, cone: 2.6, min: 200, max: 760, g: 900, life: 0.9 });   // mảnh đá vỡ bay tung
        }
        this.addWave({ x: cx, y: g, dmg: 10, stun: 1.0, kb: 420, maxR: 820, speed: 1600, kind: 'skill', color: '#ffd45a', launch: 300, air: true });
        this.ui.announce(ZONES[E.zone].name, `MÀN ${E.zone + 1} / 4`, 2.2);
    }
    _entranceBurst(cx, cy, g) {          // BÙNG NỔ KHÍ TỨC
        const E = this.entrance, F = pfx(); E.burst = true;
        this.flash(0.9); this.camera.shake(34, 0.7); this.audio.playBigImpact(); this.audio.playCine('reveal');
        this.fx.shock(cx, g, { r1: 900, life: 0.8, color: '#ff6ec7' }); this.fx.star(cx, cy, { r: 220, life: 0.35, color: '#ffffff' });
        this.floatText.show(cx, cy - 130, 'AURA BREAK!!', '#ffd45a', 26, 1.4);
        for (const c of ['#ffd45a', '#ff9ad5', '#7dd3fc', '#ffffff']) this.particles.energyBurst(cx, cy, c);
        if (F) {
            F.ring(cx, cy, 20, 900, 0.9, '#ffffff', { n: 96 }); F.ring(cx, cy, 20, 700, 0.7, '#ff9ad5', { n: 72 }); F.ring(cx, cy, 10, 520, 0.6, '#7dd3fc', { n: 56 });
            F.circle(cx, g, 820, 1.5, '#ffd45a', '#ff9ad5', { grow: 0.2, fade: 0.4, spin: 2.5 });
            F.pillar(cx, g, 300, 900, 1.5, '#ffd45a', '#ffffff');
            F.sparks(cx, cy, 160, { col: ['#ffd45a', '#ff9ad5', '#7dd3fc', '#ffffff'], min: 240, max: 900, g: 0, life: 1.1, drag: 0.03 });
        }
        this.addWave({ x: cx, y: g, dmg: 6, stun: 0.8, kb: 300, maxR: 900, speed: 1700, kind: 'skill', color: '#ff9ad5', launch: 220, air: true });
    }
    // lớp nền phía sau Ricardo: tối màn + cột sáng, đuôi sao băng, ngọn lửa khí tức, hào quang, tia sáng xoay
    _drawEntranceBack(ctx) {
        const E = this.entrance, pl = this.player, cam = this.camera, t = this.ui.time, TAU = Math.PI * 2;
        if (pl.hidden && E) { if (E.phase === 'warn') { /* vẫn tối màn + cột sáng */ } }
        const cx = E ? E.lx : pl.x + pl.w / 2, g = E ? E.gy : this.groundY;
        const sx = cam.screenX(cx), sg = cam.screenY(g), by = cam.screenY(pl.y + pl.h * 0.5), feetY = cam.screenY(pl.y + pl.h);
        let power = 0;
        ctx.save();
        if (E) {
            const dim = E.phase === 'warn' ? E.dim : E.phase === 'fall' ? 1 : Math.max(0, 1 - E.ct / 0.35);
            if (dim > 0) {
                const gr = ctx.createRadialGradient(sx, sg - 100, 60, sx, sg - 100, 900);
                gr.addColorStop(0, 'rgba(8,4,24,0)'); gr.addColorStop(0.5, `rgba(8,4,24,${0.28 * dim})`); gr.addColorStop(1, `rgba(8,4,24,${0.65 * dim})`);
                ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
            }
            if (E.phase === 'fall') {            // đuôi sao băng + vạch tốc độ
                const len = Math.min(by + 100, 560);
                ctx.globalCompositeOperation = 'lighter';
                let tg = ctx.createLinearGradient(0, by, 0, by - len); tg.addColorStop(0, 'rgba(255,245,190,0.9)'); tg.addColorStop(0.4, 'rgba(255,170,60,0.5)'); tg.addColorStop(1, 'rgba(255,80,140,0)');
                ctx.fillStyle = tg; ctx.fillRect(sx - 48, by - len, 96, len);
                tg = ctx.createLinearGradient(0, by, 0, by - len); tg.addColorStop(0, 'rgba(255,255,255,0.95)'); tg.addColorStop(1, 'rgba(255,255,255,0)');
                ctx.fillStyle = tg; ctx.fillRect(sx - 13, by - len, 26, len);
                ctx.fillStyle = 'rgba(255,255,255,0.35)';
                for (let i = 0; i < 16; i++) { const lx = ((i * 197 + 41) % W), ly = ((t * 3200 + i * 131) % (H + 260)) - 130; if (Math.abs(lx - sx) > 40) ctx.fillRect(lx, ly, 3, 120 + (i % 3) * 40); }
            }
            power = E.phase === 'fall' ? 0.75 : E.phase === 'charge' ? E.power : 0;
        } else if (pl.state === 'ultimate') {      // gồng khí tức khi tung ETERNAL DANCE: mạnh dần lúc nạp, bùng cao ở đòn kết
            const T = pl.ultT; power = T < 0.7 ? 0.35 + 0.8 * (T / 0.7) : (T >= 3.3 ? 1.45 : 1.05 + 0.15 * Math.sin(t * 14));
        } else if (pl.auraT > 0) power = 0.5 * clamp(pl.auraT / 1.2, 0, 1);
        if (power > 0 && !pl.hidden) {
            ctx.globalCompositeOperation = 'lighter';
            const R = 120 + 120 * power + Math.sin(t * 18) * 8, rg = ctx.createRadialGradient(sx, by, 10, sx, by, R);
            rg.addColorStop(0, 'rgba(255,248,200,0.75)'); rg.addColorStop(0.45, 'rgba(255,212,90,0.4)'); rg.addColorStop(1, 'rgba(255,110,199,0)');
            ctx.fillStyle = rg; ctx.fillRect(sx - R, by - R, R * 2, R * 2);
            if ((E && E.phase === 'charge') || (!E && pl.state === 'ultimate')) {         // tia sáng xoay quanh thân
                const L = 200 + 260 * power; ctx.fillStyle = `rgba(255,236,150,${E && E.burst ? 0.3 : 0.18})`;
                for (let i = 0; i < 12; i++) { const a = i * TAU / 12 + t * 0.9; ctx.beginPath(); ctx.moveTo(sx, by); ctx.lineTo(sx + Math.cos(a - 0.05) * L, by + Math.sin(a - 0.05) * L); ctx.lineTo(sx + Math.cos(a + 0.05) * L, by + Math.sin(a + 0.05) * L); ctx.closePath(); ctx.fill(); }
            }
            // ngọn lửa khí tức dạng điểm ảnh bốc lên từ thân
            const n = 26, sn = v => Math.round(v / 3) * 3;
            for (let i = 0; i < n; i++) {
                const k = i / (n - 1), ox = (k - 0.5) * 78 * (1 + power * 0.5);
                const hh = (50 + (Math.sin(t * 9 + i * 1.7) * 0.5 + 0.5) * 90 + (1 - Math.abs(k - 0.5) * 2) * 90) * power;
                for (let j = 0; j < hh; j += 6) {
                    const f = j / hh; ctx.globalAlpha = (1 - f) * 0.9;
                    ctx.fillStyle = f < 0.3 ? '#fff7c2' : f < 0.6 ? '#ffd45a' : f < 0.85 ? '#ff9a3c' : '#ff4d8d';
                    ctx.fillRect(sn(sx + ox + Math.sin(t * 14 + i + j * 0.08) * 7 * f), sn(feetY - 14 - j), f < 0.5 ? 6 : 3, f < 0.5 ? 6 : 3);
                }
            }
        }
        ctx.restore();
    }
    // ---- ETERNAL DANCE hồi sinh: nổ năng lượng vàng, đẩy lùi + gây sát thương kẻ địch xung quanh ----
    _eternalBlast() {
        const pl = this.player, cx = pl.x + pl.w / 2, cy = pl.y + pl.h * 0.5, F = pfx();
        pl.activateEternal(this.particles, this.camera, this.audio, 0.85);
        this.enemyManager.projectiles.length = 0; pl.invulnTimer = 2.5;
        this.flash(1); this.camera.shake(34, 0.9); this.audio.playBigImpact(); this.audio.playCine('eternal');
        this.banner('THE ETERNAL DANCE', 'SUC MANH TOI THUONG', 2.4, '#ffd45a', true);
        this.fx.shock(cx, this.groundY, { r1: 520, life: 0.7, color: '#ffd45a' });
        if (F) {
            const g = this.groundY;
            F.circle(cx, g, 640, 1.6, '#ffd45a', '#ffffff', { grow: 0.2, fade: 0.4, spin: 2 }); F.pillar(cx, g, 220, 800, 1.3, '#ffd45a', '#ff9ad5');
            F.ring(cx, cy, 20, 640, 0.9, '#ffffff', { n: 64 }); F.ring(cx, g, 10, 620, 0.9, '#ffd45a', { sq: 0.28, n: 72 });
            F.sparks(cx, cy, 90, { col: ['#ffd45a', '#ff9ad5', '#7dd3fc', '#ffffff'], min: 160, max: 760, g: 0, life: 1.0, drag: 0.03 });
        }
        for (const e of this.enemyManager.enemies) {
            if (e.dead) continue;
            const dx = e.cx() - cx; if (Math.abs(dx) > 600) continue;
            e.takeDamage(e.isBoss ? 40 : 70, dx >= 0 ? 1 : -1, 560, this.particles, this.floatText, this.audio, { kind: 'skill', stun: 1.4, launch: 260 });
        }
    }
    // ---- cổng dịch chuyển ----
    _openPortal() {
        const pl = this.player, mapW = this.map.getWidth(), px = pl.x + pl.w / 2, z = this.modes.currentZoneIndex, n = z + 1;
        let x = px + 480; if (x > mapW - 240) x = Math.max(240, px - 480);
        this.portal = new PXFX.Portal(x, this.groundY, ['forest', 'lava', 'demon'][z] || 'gold', ZONES[n].name, `MAN ${n + 1} / 4`);
    }
    _updatePortal(dt) {
        const pt = this.portal; pt.update(dt, this);
        if (pt.state === 'open' && pt.contains(this.player)) {
            pt.begin(); const pl = this.player; this._suckFrom = { x: pl.x, y: pl.y }; pl.vx = pl.vy = 0; pl.blocking = false;
            this.ui.toast('BUOC VAO CONG!', 1.2);
        }
        if (pt.state === 'entering') this.flashA = Math.max(this.flashA, pt.fade);
        if (pt.done) {
            this.portal = null; this.player.hidden = false; this.player.suck = null;
            this.modes.currentZoneIndex++; this.modes.currentWave = 1; this._enterZone(this.modes.currentZoneIndex, false);
            this.flashA = 1;
        }
    }
    _suckPlayer() {
        const pt = this.portal, pl = this.player, p = clamp(pt.stT / 1.1, 0, 1), e = p * p, f = this._suckFrom || { x: pl.x, y: pl.y };
        pl.x = lerp(f.x, pt.x - pl.w / 2, e); pl.y = lerp(f.y, pt.cy - pl.h / 2, e); pl.state = 'jump'; pl.vx = pl.vy = 0;
        pl.suck = { s: Math.max(0.05, 1 - p * 0.95), rot: p * 9 }; if (p >= 0.98) pl.hidden = true;
        const F = pfx(); if (F && !pl.hidden && Math.random() < 0.7) F.sparks(pl.x + pl.w / 2, pl.y + pl.h / 2, 2, { col: ['#ffffff', PXFX.THEMES[pt.theme].light], min: 20, max: 120, g: 0, life: 0.4 });
    }
    _submitOnlineResult(outcome) {
        if (!window.MemeLeaderboard) return;
        const p = this.player, m = this.modes;
        const floor = Math.max(1, m.currentFloor || (m.currentZoneIndex + 1) * 3 || 1);
        const arcadeBonus = this.playMode === 'arcade' ? (m.playerRoundsWon || 0) * 1500 : 0;
        const score = Math.floor((p.killCount || 0) * 250 + (p.totalDamageDealt || 0) * 0.5 + (p.maxCombo || 0) * 30 + floor * 1000 + (m.survivalScore || 0) + arcadeBonus);
        window.MemeLeaderboard.finishRun({ score, floor, kills: p.killCount, maxCombo: p.maxCombo, outcome });
    }
    _playEnding() {
        this.audio.startBGM('menu');
        this.cutscene.play(STORY.ending, () => { this._submitOnlineResult('victory'); this.modes.mode = 'victory'; this.player.victory = true; this.audio.playVictory(); });
    }
    _setFloorProgression(floor) {
        this.modes.currentFloor = Math.max(1, Math.floor(floor));
        this.enemyManager.setProgression(this.modes.currentFloor, this.modes.difficulty);
        // Floor skill progression remains active; only the unlock notification is disabled.
    }
    initZone(zoneIdx) {
        this.map.setZone(zoneIdx);
        this.player.reset(150);
        this.enemyManager.clear(); this.combat.clear(); this.fx.clear(); this.timeScale = 1; this.camZoom = this.camZoomTarget = 1; this.flashA = 0;
        this.portal = null; this.entrance = null; this.player.entr = null; if (pfx()) pfx().clear();
        this.spawnWave(zoneIdx, 1);
        this.ui.announce(ZONES[zoneIdx].name, `MÀN ${zoneIdx + 1} / 4`, 2.2);
        this.audio.startBGM(zoneIdx);
    }
    spawnWave(zoneIdx, waveNum) {
        const floor = zoneIdx === 3 ? 10 : zoneIdx * 3 + waveNum;
        this._setFloorProgression(floor);
        const zone = ZONES[zoneIdx];
        const groundY = zone.groundY;
        if (zoneIdx === 3) {
            // Demon Arena Boss
            this.enemyManager.spawnEnemy('boss', 1400, groundY - 190);
        } else {
            const types = zone.enemyTypes;
            const count = waveNum + 1;
            for (let i = 0; i < count; i++) {
                const type = types[i % types.length];
                const spawnX = clamp(this.player.x + rand(450, 950), 300, zone.width - 200);
                this.enemyManager.spawnEnemy(type, spawnX, groundY - 100);
            }
        }
    }
    initArcadeRound() {
        this._setFloorProgression(Math.min(10, this.modes.arcadeRound));
        this.map.setZone(3); // Arena for arcade
        this.player.reset(300);
        this.enemyManager.clear();
        this.enemyManager.spawnEnemy('boss', 1200, GROUND_Y - 190);
        this.modes.arcadeTimer = 99;
        this.ui.announce(`ROUND ${this.modes.arcadeRound}`, 'FIGHT!', 2.0);
        this.audio.startBGM(3);
    }
    initSurvivalWave() {
        const wave = this.modes.survivalWave;
        this._setFloorProgression(Math.min(10, wave));
        const zoneIdx = (wave - 1) % 4;
        this.map.setZone(zoneIdx);
        this.player.reset(400);
        this.enemyManager.clear();

        const count = Math.min(2 + wave, 8);
        const types = ['wojak', 'doge', 'troll', 'dancer', 'sigma', 'chad'];
        for (let i = 0; i < count; i++) {
            const t = types[i % Math.min(types.length, 1 + Math.floor(wave / 2))];
            this.enemyManager.spawnEnemy(t, clamp(this.player.x + rand(350, 800), 200, this.map.getWidth() - 200), GROUND_Y - 100);
        }
        this.ui.announce(`WAVE ${wave}`, 'SURVIVE!', 1.8);
        this.audio.startBGM(zoneIdx);
    }
    update(dt) {
        // Lớp chớp trắng phải mờ dần theo thời gian thật (trước đây không bao giờ giảm -> màn hình trắng mãi sau khi bấm P)
        if (this.flashA > 0) this.flashA = Math.max(0, this.flashA - dt * 2.2);
        if (this.paused) { this.ui.update(dt); return; }

        if (this.cutscene.active) {       // đang xem phim: đóng băng game
            this.cutscene.update(dt);
            this.ui.time += dt;
            if (this.ui.toastTimer > 0) this.ui.toastTimer -= dt;
            return;
        }
        this.ui.update(dt);

        if (this.modes.mode === 'menu' || this.modes.mode === 'charselect' || this.modes.mode === 'difficulty') {
            this.particles.update(dt);
            return;
        }

        // hit-stop: đóng băng logic vài khung hình khi đòn đánh trúng
        if (this.hitStopT > 0) { this.hitStopT -= dt; this.camera.update(dt); this.particles.update(dt * 0.2); return; }
        if (this.slowMoT > 0) { this.slowMoT -= dt; if (this.slowMoT <= 0 && this.player.state !== 'ultimate') this.timeScale = 1; }
        if (this.player.state !== 'ultimate' && this.slowMoT <= 0 && this.timeScale !== 1) this.timeScale = 1;
        const wdt = dt * this.timeScale;
        this.camZoom += (this.camZoomTarget - this.camZoom) * Math.min(1, dt * 6);
        if (this.player.state !== 'ultimate' && this.camZoomTarget !== 1) this.camZoomTarget = 1;
        const groundY = this.map.getGroundY();
        const mapW = this.map.getWidth();
        this.groundY = groundY;

        if (this.entrance && this.modes.mode !== 'story') { this.entrance = null; this.player.entr = null; this.player.hidden = false; }
        if (this.portal && this.portal.state === 'entering') this._suckPlayer(); else if (this.entrance) this._updateEntrance(dt); else this.player.update(dt, this.input, groundY, mapW, this.audio, this.particles, this.floatText, this);
        if (this.player.auraT > 0) this.player.auraT -= dt;
        this.camera.follow(this.player.x + this.player.w / 2, this.player.y, mapW);
        this.camera.update(dt);
        if (!(this.entrance && this.entrance.phase !== 'charge')) this.enemyManager.update(wdt, this.player, groundY, mapW, this.particles, this.floatText, this.audio, this);   // quái đứng im cho tới khi Ricardo chạm đất
        this.combat.update(wdt, this);
        this.fx.update(wdt); this.particles.update(wdt); this.floatText.update(dt);
        if (pfx()) pfx().update(wdt);
        if (this.portal) this._updatePortal(dt);
        this.map.update(wdt);
        this.map.drawAmbient(this.ctx, this.camera, this.particles);

        // THE ETERNAL DANCE khi chết: tự kích hoạt sức mạnh tối thượng, CHỈ 1 LẦN mỗi lượt chơi
        if (this.player.defeated && !this.modes.reviveUsed && ['story', 'arcade', 'survival'].includes(this.modes.mode)) {
            this.modes.reviveUsed = true; this.eternalUsed = true;
            this.player.revive(); this.enemyManager.projectiles.length = 0;
            this.cutscene.play(STORY.eternal, () => this._eternalBlast());
            return;
        }
        // Game mode specific progression
        if (this.modes.mode === 'story') {
            if (this.player.defeated) {
                this._submitOnlineResult('gameover');
                this.modes.mode = 'gameover';
                this.audio.playDefeat();
            } else if (this.enemyManager.getAliveCount() === 0) {
                if (this.modes.currentZoneIndex === 3) {
                    // Boss gục: chờ hoạt ảnh chết một chút rồi chiếu phim kết
                    if (this.endTimer === null) this.endTimer = 1.4;
                    this.endTimer -= dt;
                    if (this.endTimer <= 0) { this.endTimer = null; this._playEnding(); }
                } else if (this.modes.currentWave < this.modes.maxWaves) {
                    this.modes.currentWave++;
                    this.spawnWave(this.modes.currentZoneIndex, this.modes.currentWave);
                    this.ui.announce(`WAVE ${this.modes.currentWave}`, 'QUÁI VẬT XUẤT HIỆN!', 1.8);
                } else if (!this.portal) {
                    this._openPortal();       // dọn sạch màn: mở CỔNG DỊCH CHUYỂN, bước vào mới sang màn kế
                }
            }
        } else if (this.modes.mode === 'arcade') {
            this.modes.arcadeTimer = Math.max(0, this.modes.arcadeTimer - dt);
            if (this.player.defeated) {
                this.modes.enemyRoundsWon++;
                if (this.modes.enemyRoundsWon >= 2) {
                    this._submitOnlineResult('gameover');
                    this.modes.mode = 'gameover';
                    this.audio.playDefeat();
                } else {
                    this.modes.arcadeRound++;
                    this.initArcadeRound();
                }
            } else if (this.enemyManager.getAliveCount() === 0) {
                this.modes.playerRoundsWon++;
                if (this.modes.playerRoundsWon >= 2) {
                    this._submitOnlineResult('victory');
                    this.modes.mode = 'victory';
                    this.audio.playVictory();
                } else {
                    this.modes.arcadeRound++;
                    this.initArcadeRound();
                }
            } else if (this.modes.arcadeTimer <= 0) {
                // Time Over
                if (this.player.hp > 0) this.modes.playerRoundsWon++;
                else this.modes.enemyRoundsWon++;
                this.modes.arcadeRound++;
                this.initArcadeRound();
            }
        } else if (this.modes.mode === 'survival') {
            if (this.player.defeated) {
                this._submitOnlineResult('gameover');
                this.modes.mode = 'gameover';
                this.audio.playDefeat();
            } else if (this.enemyManager.getAliveCount() === 0) {
                this.modes.survivalWave++;
                this.initSurvivalWave();
            }
        }
    }
    render() {
        this.ui.beginFrame();
        if (this.cutscene.active) this.cutscene.draw(this.ctx); else this._renderScene();
        if (this.ui.showControlsOverlay && !this.cutscene.active) this.ui.drawControlsModal(this.ctx);
        if (this.ui.showSettings) this.ui.drawSettings(this.ctx, this.audio);
        this.ui.drawToast(this.ctx);
        // con trỏ + âm thanh khi rê chuột qua nút
        const hv = this.ui._hoverNow; this.canvas.style.cursor = hv ? 'pointer' : 'default';
        if (hv && hv !== this.ui.hoverId) this.audio.playMenuSelect();
        this.ui.hoverId = hv; this.ui.mouse.moved = false;
        this.ui.drawCRT(this.ctx);
    }
    _renderScene() {
        this.ctx.clearRect(0, 0, W, H);

        if (this.modes.mode === 'difficulty') { this.ui.drawDifficultySelect(this.ctx, this.modes.difficultyIndex); return; }
        if (this.modes.mode === 'menu') {
            this.ui.drawMenu(this.ctx, this.modes.selectedMenuIndex, this.modes.menuOptions);
            return;
        }
        if (this.modes.mode === 'charselect') { this.ui.drawCharSelect(this.ctx); return; }

        // 1. Sky & Parallax Backgrounds
        this.map.drawSky(this.ctx);
        this.map.drawBackground(this.ctx, this.camera);

        // 2. Ground
        this.map.drawGround(this.ctx, this.camera);

        // 3-5. Thế giới (có thể phóng to khi ULTIMATE)
        const z = this.camZoom;
        if (z !== 1) {
            const zx = this.camera.screenX(this.player.x + this.player.w / 2), zy = this.camera.screenY(this.player.y + this.player.h * 0.5);
            this.ctx.save(); this.ctx.translate(zx, zy); this.ctx.scale(z, z); this.ctx.translate(-zx, -zy);
        }
        if (this.portal) { this.portal.drawGround(this.ctx, this.camera); this.portal.draw(this.ctx, this.camera); }
        this.enemyManager.draw(this.ctx, this.camera, this.map.getGroundY());
        for (const w of this.combat.waves) if (w.kind === 'ult') PXFX.drawShockWave(this.ctx, this.camera, w, this.ui.time);     // sóng ULTIMATE pixel
        if (this.entrance || this.player.auraT > 0 || this.player.state === 'ultimate') this._drawEntranceBack(this.ctx);
        this.player.draw(this.ctx, this.camera);
        this.fx.draw(this.ctx, this.camera);
        if (pfx()) pfx().draw(this.ctx, this.camera);
        this.particles.draw(this.ctx, this.camera);
        this.floatText.draw(this.ctx, this.camera);
        if (z !== 1) this.ctx.restore();
        if (this.flashA > 0) { this.ctx.fillStyle = `rgba(255,255,255,${Math.min(1, this.flashA)})`; this.ctx.fillRect(0, 0, W, H); }

        if (this.portal) PXFX.drawPortalArrow(this.ctx, this.portal, this.camera, this.ui.time);
        // 6. HUD
        const currentZone = this.map.getZone();
        const displayTimer = this.modes.mode === 'arcade' ? this.modes.arcadeTimer : 99;
        this.ui.drawHUD(this.ctx, this.player, this.enemyManager, currentZone, displayTimer, this.modes.arcadeRound, this.modes.mode, this.modes);

        // 7. Modals
        if (this.paused) {
            this.ui.drawPause(this.ctx);
        } else if (this.modes.mode === 'gameover') {
            this.ui.drawGameOver(this.ctx, this.player);
        } else if (this.modes.mode === 'victory') {
            this.ui.drawVictory(this.ctx, this.player);
        }
    }
    loop(timestamp) {
        const dt = Math.min(MAX_DT, (timestamp - this.lastTime) / 1000 || 0);
        this.lastTime = timestamp;

        try {
            this.update(dt);
            this.input.endFrame();
            this.render();
        } catch (err) {
            // Một exception không còn làm vòng lặp dừng hẳn (trước đây màn hình sẽ đứng vĩnh viễn)
            this._errCount = (this._errCount || 0) + 1;
            if (this._errCount <= 5) console.error('[game loop]', err);
            try { const c = this.ctx; c.setTransform(1, 0, 0, 1, 0, 0); c.globalAlpha = 1; c.globalCompositeOperation = 'source-over'; c.shadowBlur = 0; } catch (e2) { /* bỏ qua */ }
            if (this.cutscene && this.cutscene.active && this._errCount > 60) this.cutscene._finish();   // cảnh phim lỗi liên tục -> bỏ qua để game tiếp tục
        } finally {
            requestAnimationFrame(ts => this.loop(ts));
        }
    }
    start() {
        requestAnimationFrame(ts => {
            this.lastTime = ts;
            this.loop(ts);
        });
    }
}

// ============================================================
// BOOTSTRAP GAME
// ============================================================
window.addEventListener('DOMContentLoaded', () => {
    window.gameEngine = new GameEngine();
    window.gameEngine.start();
});

})();
